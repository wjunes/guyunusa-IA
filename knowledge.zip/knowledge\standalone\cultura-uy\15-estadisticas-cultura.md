# Estadísticas e Indicadores Culturales de Uruguay

## Descripción

Este archivo reúne los **principales indicadores estadísticos** de la actividad cultural en Uruguay. Los datos provienen del **MEC, el SODRE, el ICAU, el INE, la UNESCO** y estudios del sector. Las estadísticas culturales en Uruguay tienen desarrollo desigual: algunos sectores (cine, museos) tienen datos más sistemáticos que otros.

**Nota metodológica:** Las estadísticas culturales se actualizan con rezago variable. Para datos actualizados consultar: www.gub.uy/ministerio-educacion-cultura, www.icau.mec.gub.uy e informes del INE sobre Encuesta Continua de Hogares (módulos culturales).

## Infraestructura cultural

| Indicador | Dato aproximado |
|-----------|----------------|
| Centros MEC activos | ~200 en todo el país |
| Salas de teatro en Montevideo | ~80–100 (entre grandes y pequeñas) |
| Cines en Uruguay | ~30–40 salas (concentradas en Montevideo y Maldonado) |
| Museos nacionales y departamentales | ~80–100 |
| Bibliotecas públicas | Cientos (municipales, departamentales, escolares, universitarias) |
| Espacios culturales independientes | Cientos en Montevideo |

## Carnaval

| Indicador | Dato aproximado |
|-----------|----------------|
| Duración del Carnaval de Montevideo | ~40 días |
| Conjuntos inscritos en el concurso oficial | ~300–400 (entre todas las modalidades) |
| Tablados activos por temporada | ~100–150 en Montevideo |
| Espectadores por temporada (total tablados + teatro) | Cientos de miles |
| Artistas directos involucrados | Decenas de miles |
| Impacto económico estimado | Cientos de millones de pesos uruguayos |

## Cine y audiovisual

| Indicador | Dato aproximado |
|-----------|----------------|
| Largometrajes uruguayos producidos por año | ~8–15 |
| Cortometrajes y documentales por año | ~20–40 |
| Proyectos financiados por ICAU por año | ~50–80 |
| Espectadores en cines (total) | ~2–4 millones por año |
| Cuota de pantalla del cine nacional | Regulada por ICAU (porcentaje de semanas de exhibición) |
| Presupuesto promedio largometraje nacional | USD 300.000–800.000 (varía según coproducción) |

## Música

| Indicador | Dato aproximado |
|-----------|----------------|
| Artistas registrados en AGADU | Miles |
| Recaudación AGADU por año | Decenas de millones de pesos uruguayos |
| Conciertos y espectáculos musicales por año | Miles (incluyendo pequeños venues) |
| Asistentes anuales al Festival de Jazz de Montevideo | ~30.000–50.000 |
| Temporada de la OSSODRE | ~15–20 conciertos sinfónicos por temporada |

## Museos

| Indicador | Dato aproximado |
|-----------|----------------|
| Visitantes anuales al MNAV | ~80.000–120.000 |
| Visitantes anuales al Museo Histórico Nacional | ~50.000–80.000 |
| Día del Patrimonio (evento anual) | ~100.000 visitantes en Montevideo en dos días |

### Día del Patrimonio

El **Día del Patrimonio** es un evento anual organizado por la Comisión del Patrimonio y la Intendencia de Montevideo en el que edificios históricos y espacios culturales abren sus puertas gratuitamente al público. Convoca a más de **100.000 personas** en Montevideo en el transcurso de un fin de semana y tiene actividades en todo el país.

## Gasto público en cultura

| Indicador | Dato aproximado |
|-----------|----------------|
| Gasto público en cultura / PIB | ~0,3–0,5 % (varía por año y definición) |
| Presupuesto del SODRE | Decenas de millones de USD |
| Presupuesto de la DNC/MEC (incluyendo FEFCA) | Decenas de millones de pesos uruguayos |
| Gasto cultural de las Intendencias | Variable; Montevideo es la mayor ejecutora |

## Consumo cultural

Según las encuestas del INE y estudios del MEC:

| Actividad | Porcentaje de la población que la practica (aprox.) |
|-----------|---------------------------------------------------|
| Escucha música regularmente | >90 % |
| Ve televisión regularmente | ~85–90 % |
| Asiste al Carnaval al menos una vez por temporada | ~40–50 % de montevideanos |
| Lee libros (al menos uno por año) | ~40–50 % |
| Asiste al cine al menos una vez por año | ~30–40 % |
| Asiste a teatro al menos una vez por año | ~20–30 % |
| Visita museos al menos una vez por año | ~20–30 % |

## Prácticas artísticas

| Práctica | Dato |
|---------|------|
| Personas que tocan algún instrumento | ~10–15 % de la población |
| Personas que participan en actividades de carnaval | ~5–10 % en Montevideo |
| Escritores publicados por año | Cientos |

## Fuentes de datos

| Fuente | URL |
|--------|-----|
| MEC | www.gub.uy/ministerio-educacion-cultura |
| ICAU | www.icau.mec.gub.uy |
| SODRE | www.sodre.gub.uy |
| INE (Encuesta Continua de Hogares) | www.ine.gub.uy |
| UNESCO / Instituto de Estadísticas | uis.unesco.org |

## Palabras clave

estadísticas culturales Uruguay, indicadores cultura Uruguay, carnaval Montevideo estadísticas, cine uruguayo producción anual, AGADU recaudación Uruguay, museos visitantes Uruguay, gasto público cultura Uruguay, consumo cultural Uruguay, Día del Patrimonio Uruguay visitantes, Festival Jazz Montevideo asistentes, SODRE presupuesto Uruguay, cines Uruguay salas, teatros Uruguay salas, Centros MEC estadísticas, prácticas artísticas Uruguay población
