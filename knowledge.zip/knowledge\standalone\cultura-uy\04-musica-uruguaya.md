# Música Uruguaya

## Descripción

La **música uruguaya** es un campo extraordinariamente rico y diverso, que abarca desde las raíces afrorioplatenses del **candombe** y la tradición gauchesca de la **milonga**, hasta el **tango** rioplatense, la **murga** carnavalera, el **folclore**, el **rock** y la **música popular contemporánea**. Uruguay ha producido figuras de dimensión continental e internacional en múltiples géneros.

## Géneros y tradiciones musicales

### Candombe

El **candombe** es la expresión musical fundacional de la cultura afrouruguaya y la expresión de mayor identidad uruguaya. Sus características:

- Basado en el **toque de tambores** (chico, repique y piano)
- Práctica comunitaria en el espacio público: las **cuerdas de tambores** desfilan por los barrios
- Inscrito en la **Lista Representativa del PCI de la UNESCO en 2009**
- Presente en el Carnaval (comparsa-candombe) y en la vida cotidiana del Barrio Sur, Palermo y Cordón
- Ha influenciado profundamente toda la música popular uruguaya

**Figuras clave del candombe:** Rubén Rada (quien llevó el candombe a la música popular masiva), La Calenda, grupos de las cuerdas históricas del Barrio Sur.

### Tango rioplatense

El **tango** es un género musical y de danza compartido por Uruguay y Argentina, surgido a fines del siglo XIX en los arrabales de Montevideo y Buenos Aires. Uruguay reivindica su papel fundador:

- **Gerardo Matos Rodríguez (Montevideo, 1897–1948):** autor de **"La Cumparsita"** (1917), la canción de tango más famosa del mundo; compuesta originalmente como marcha estudiantil en Montevideo
- **Carlos Gardel:** figura máxima del tango; vínculo biográfico con Uruguay reivindicado
- Tango inscrito en la Lista Representativa del PCI de la UNESCO en 2009 (nominación conjunta Uruguay-Argentina)

### Murga

La **murga** es un género musical-teatral único del Carnaval de Montevideo, sin equivalente en el mundo. Cada conjunto de murga tiene 14–17 integrantes, un director musical (el "director de murga"), cantantes, percusionistas y actores.

**Estructura de una murga:**
- **Presentación:** canción de entrada del conjunto
- **Cuplés:** canciones humorísticas y satíricas sobre temas de la actualidad política y social
- **Retirada:** canción de despedida, generalmente emotiva
- **Percusión:** bombo, platillos y redoblante (la "batería de murga")

La murga tiene un **estilo vocal** característico: canto colectivo, a veces a capella o con acompañamiento mínimo, con gran énfasis en la potencia y expresividad vocal.

**Murgas históricas:** Araca la Cana, Los Patos Cabreros, Falta y Resto, La Reina de la Teja, Agarrate Catalina.

### Folclore y música gauchesca

La música folclórica uruguaya tiene raíces en las tradiciones gauchescas del campo:

| Género/Estilo | Descripción |
|--------------|-------------|
| **Milonga** | Ritmo binario; emparentada con el tango; cantada con guitarra; género por excelencia del folclore rioplatense |
| **Estilo** | Forma musical tradicional uruguaya y argentina; melodía libre con acompañamiento de guitarra |
| **Cifra** | Forma de canto improvisado, relacionada con la payada |
| **Payada** | Improvisación poética y musical entre dos cantores (payadores) |
| **Vidala / Vidalita** | Canto de origen andino adoptado en el folclore rioplatense |

**Figuras del folclore uruguayo:**
- **Osiris Rodríguez Castillos (1925–1996):** gran referente del folclore; el "poeta del pueblo"
- **Los Olimareños (Braulio López y José Luis Guerra):** dúo folclórico de enorme repercusión; exiliados durante la dictadura
- **Carlos Molina**
- **Tabaré Etcheverry**

### Música de protesta y canto popular (1960–1985)

El período 1960–1985 fue fértil en **música de compromiso político y social**, en sintonía con los movimientos de liberación latinoamericanos:

| Artista | Perfil |
|---------|--------|
| **Alfredo Zitarrosa (1936–1989)** | La voz más representativa del canto popular uruguayo; *Adagio en mi país*, *Milonga para una niña*, *Doña Soledad*; exiliado durante la dictadura |
| **Daniel Viglietti (1939–2017)** | Cantautor de compromiso político; *A desalambrar*; exiliado durante la dictadura |
| **Los Olimareños** | Dúo folclórico; exiliados |
| **Numa Moraes** | Cantautor folclórico |
| **Eduardo Mateo (1940–1990)** | Figura de culto; músico innovador; *Mateo solo bien se lame*; fusionó candombe, rock y soul |

**Alfredo Zitarrosa** es considerado por muchos la voz más representativa de la identidad musical uruguaya. Su voz grave, su repertorio de milongas, estilos y canciones de autor, y su compromiso político lo convierten en un símbolo cultural de primer orden.

### Rock uruguayo

El **rock uruguayo** tiene una historia de más de cinco décadas, con una escena local vigorosa:

| Artista / Banda | Período | Perfil |
|-----------------|---------|--------|
| **Los Shakers** (1963–1967) | 1960s | Primera banda de rock uruguayo de proyección internacional; los "Beatles uruguayos" |
| **El Kinto** (1967–1971) | 1960s | Banda pionera; Eduardo Mateo fue integrante |
| **Opa** | 1970s | Fusión jazz-rock-candombe; internacionalmente reconocida |
| **Los Traidores** | 1980s | Post-dictadura; rock urbano |
| **La Vela Puerca** | 1995–presente | Ska-punk-rock; una de las bandas más populares de Uruguay; repercusión regional |
| **El Cuarteto de Nos** | 1984–presente | Banda de humor y rock; larga trayectoria; *Raro*, *Bipolar*; reconocimiento regional |
| **Buceo Invisible** | 2000s | Indie rock uruguayo |
| **No Te Va Gustar** | 1994–presente | Ska-punk; una de las bandas uruguayas más exitosas en Argentina; múltiples premios |

## Música clásica y académica

Uruguay tiene una tradición de **música académica** sostenida por el SODRE (Orquesta Sinfónica, Ballet, ópera) y la **Escuela Universitaria de Música (EUM)** de la Udelar.

**Figuras de la música académica uruguaya:**
- **Eduardo Fabini (1882–1950):** compositor; *Campo* (poema sinfónico); figura fundacional de la música clásica nacional
- **Carlos Pedrell (1878–1941):** compositor de zarzuelas y óperas
- **Hugo Balzo (1900–1970):** pianista; la Sala Hugo Balzo del SODRE lleva su nombre

## Principales espacios de música en vivo

| Espacio | Ciudad | Tipo |
|---------|--------|------|
| **Auditorio Nacional del SODRE** | Montevideo | Música clásica, ópera, grandes espectáculos |
| **Teatro Solís** | Montevideo | Ópera, ballet, grandes artistas |
| **Teatro de Verano Ramón Collazo** | Montevideo | Carnaval; conciertos al aire libre |
| **Anfiteatro del Parque Rodó** | Montevideo | Conciertos al aire libre |
| **Sala Zitarrosa** (también SODRE) | Montevideo | Música popular, teatro |
| **Espacio Maturana** | Montevideo | Música popular |

## Palabras clave

música uruguaya, candombe Uruguay, tango Uruguay La Cumparsita, murga uruguaya, folclore uruguayo, Alfredo Zitarrosa Uruguay, Daniel Viglietti Uruguay, Los Olimareños Uruguay, Eduardo Mateo Uruguay, Rubén Rada candombe, Los Shakers rock Uruguay, La Vela Puerca Uruguay, El Cuarteto de Nos Uruguay, No Te Va Gustar Uruguay, Gerardo Matos Rodríguez Uruguay, milonga uruguaya, música de protesta Uruguay, Eduardo Fabini música clásica Uruguay, exilio músicos Uruguay dictadura
