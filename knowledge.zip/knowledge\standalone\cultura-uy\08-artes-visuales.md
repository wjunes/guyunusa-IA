# Artes Visuales en Uruguay

## Descripción

Las **artes visuales uruguayas** tienen una historia destacada en el panorama latinoamericano, con figuras de proyección internacional que van desde el impresionismo de **Pedro Figari** hasta el **Universalismo Constructivo** de **Joaquín Torres García** y las vanguardias del siglo XX. Uruguay ha producido artistas de relevancia mundial, y su escena artística contemporánea sigue siendo activa y diversa.

## Figuras históricas fundamentales

### Pedro Figari (1861–1938)

**Pedro Figari** es uno de los artistas plásticos uruguayos más reconocidos internacionalmente. Abogado, político y escritor además de pintor, Figari comenzó su obra pictórica tardíamente (a partir de los 50 años) y desarrolló un estilo personal e inconfundible.

| Dato | Información |
|------|-------------|
| Nacimiento | Montevideo, 1861 |
| Fallecimiento | Buenos Aires, 1938 |
| Estilo | Post-impresionismo; influencia fauvista |
| Temáticas | Candombe afrouruguayo; escenas de la vida criolla y gauchesca; la vida cotidiana colonial rioplatense |
| Obra destacada | Series de candombes, bailes de negros, pulperías, escenas de campo |
| Colección principal | Museo Nacional de Artes Visuales (MNAV), Montevideo |

Figari vivió gran parte de su madurez artística en Buenos Aires y París, pero su obra es profundamente rioplatense. Sus **candombes** —escenas de la vida afrorioplatense pintadas con paleta vibrante y pincelada expresiva— son sus piezas más reconocidas.

### Joaquín Torres García (1874–1949)

**Joaquín Torres García** es el artista plástico uruguayo de mayor proyección e influencia internacional. Fundador del **Universalismo Constructivo**, su obra es referencia del arte latinoamericano y mundial del siglo XX.

| Dato | Información |
|------|-------------|
| Nacimiento | Montevideo, 1874 |
| Fallecimiento | Montevideo, 1949 |
| Estilo / Movimiento | **Universalismo Constructivo**; arte abstracto con símbolos universales y precolombinos |
| Período europeo | Vivió en España, París y Nueva York (1891–1934) |
| Retorno a Uruguay | 1934: regresó a Montevideo y fundó el **Taller Torres García** |
| Obra maestra | *América Invertida* (1943): mapa de América del Sur con el sur en la parte superior; la frase "nuestro norte es el sur" |
| Museo | Museo Torres García (Sarandí 683, Ciudad Vieja, Montevideo) |

La frase **"Nuestro norte es el sur"** y el dibujo de *América Invertida* son iconos culturales latinoamericanos que trascienden el campo artístico.

El **Taller Torres García** fue una escuela y laboratorio de ideas que formó a varias generaciones de artistas uruguayos y latinoamericanos en el Universalismo Constructivo.

### Rafael Barradas (1890–1929)

**Rafael Barradas** fue un pintor y dibujante uruguayo que desarrolló su obra principalmente en España, donde fue figura central de las vanguardias artísticas de los años 1920.

| Dato | Información |
|------|-------------|
| Nacimiento | Montevideo, 1890 |
| Fallecimiento | Montevideo, 1929 |
| Estilo | Vibrationismo (movimiento creado por él); expresionismo |
| Contexto | Vanguardias españolas de los años 20; amistad con Federico García Lorca y Salvador Dalí |
| Retorno | Regresó a Uruguay enfermo en 1928; murió al año siguiente |

Barradas es considerado uno de los grandes artistas uruguayos del siglo XX, aunque murió joven y su obra tardó en ser reconocida en Uruguay.

## Generaciones del siglo XX

### El Círculo de Bellas Artes y la institucionalización (1900–1940)

La creación del **Círculo de Bellas Artes** (1905) fue el primer hito de la institucionalización artística uruguaya. Reunió a pintores, escultores y grabadores en torno a un proyecto educativo y expositivo.

Figuras del período:
- **Carlos González (1905–1993):** escultor; obras en el espacio público montevideano
- **José Cuneo (1887–1977):** paisajista; escenas lunares de gran expresividad; *Ranchos de luna*
- **Carmelo de Arzadun (1888–1968):** pintor de tradición académica y post-impresionista

### Generación del 45 en artes visuales

La **Generación del 45** también tuvo su correlato en las artes visuales, con artistas que renovaron el lenguaje plástico uruguayo incorporando las vanguardias internacionales.

Figuras:
- **Washington Barcala (1920–1993):** pintura abstracta
- **María Freire (1917–2015):** abstracción geométrica; larguísima trayectoria
- **José Gamarra (n. 1934):** obra que dialoga con la historia colonial latinoamericana; vive en Francia

### Arte conceptual y experimental (1960–1985)

El período generó artistas de experimentación conceptual, interrumpidos por la dictadura:

- **Luis Camnitzer (n. 1937, Hamburgo):** artista conceptual de origen alemán radicado en Uruguay; figura fundamental del arte conceptual latinoamericano

### Post-dictadura y arte contemporáneo

El retorno democrático generó una proliferación de artistas, espacios alternativos y nuevos lenguajes. La escena artística montevideana contemporánea incluye pintura, escultura, fotografía, instalación, arte digital y performance.

## Instituciones de artes visuales

| Institución | Tipo | Descripción |
|-------------|------|-------------|
| **Museo Nacional de Artes Visuales (MNAV)** | Público/MEC | Principal museo de arte del Uruguay |
| **Museo Torres García** | Fundación | Obra de Torres García y su escuela |
| **INBA** | Público/MEC | Escuela Nacional de Bellas Artes; fomento de las artes visuales |
| **Espacio de Arte Contemporáneo (EAC)** | Público/IM | Arte contemporáneo en edificio del ex-cárcel Miguelete |
| **Centro Cultural de España (CCE)** | Cultural bilateral | Exposiciones y actividades artísticas |
| **Galería Borghese** | Privada | Galería comercial de arte contemporáneo |
| **Subte de la Ciudad Vieja** | Público/IM | Espacio de arte en la estación de ómnibus subterránea |

## Escultura en el espacio público

Montevideo tiene una notable presencia de **escultura en el espacio público**: monumentos, plazas y ramblas albergan obras de artistas uruguayos y donaciones internacionales. La Rambla Sur y el Parque Rodó tienen obras de valor patrimonial.

## Fotografía

Uruguay tiene una escena fotográfica activa con fotoperiodistas de nivel internacional. El **Centro de Fotografía de Montevideo (CdF)** es el principal espacio de fotografía documental y artística de la ciudad.

## Palabras clave

artes visuales Uruguay, Pedro Figari Uruguay, Joaquín Torres García Uruguay, Universalismo Constructivo Uruguay, América Invertida Torres García, Rafael Barradas Uruguay, MNAV Museo Nacional Artes Visuales, Museo Torres García Montevideo, Taller Torres García, José Cuneo pintura uruguaya, Luis Camnitzer arte conceptual Uruguay, Espacio Arte Contemporáneo Montevideo, INBA Uruguay bellas artes, fotografía Uruguay CdF, escena artística contemporánea Uruguay, arte latinoamericano Uruguay
