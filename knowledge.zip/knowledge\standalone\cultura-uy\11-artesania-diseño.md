# Artesanía y Diseño Uruguayo

## Descripción

La **artesanía** y el **diseño** son componentes importantes de la cultura material uruguaya. La artesanía tradicional tiene raíces en las tradiciones gauchesca, indígena y criolla, mientras que el diseño uruguayo contemporáneo ha desarrollado una identidad propia reconocida en la región.

## Artesanía tradicional uruguaya

### Características generales

La artesanía uruguaya tradicional refleja la historia productiva y cultural del país, con predominio de materiales vinculados a la economía ganadera (cuero, lana) y a los recursos naturales locales (piedra, madera, cerámica).

### Principales tipos de artesanía

| Tipo | Descripción | Regiones |
|------|-------------|---------|
| **Artesanía en cuero** | Sogas, lazos, aperos de montar, cinturones, bolsos, carteras; técnicas de trenzado y repujado | Todo el país; especialmente interior ganadero |
| **Artesanía en lana** | Tejidos a palillo y crochet; tapices; alfombras; prendas de vestir | Todo el país; especialmente interior |
| **Artesanía en piedra** | Ámbar, ágata, amatista y otras piedras semipreciosas; tallado y joyería | Artigas (yacimientos de ágata y amatista) |
| **Cestería** | Cestas y objetos de mimbre, junco y totora | Interior rural |
| **Cerámica** | Alfarería tradicional; objetos decorativos y utilitarios | — |
| **Madera** | Tallas, objetos decorativos; mates y accesorios de mate | — |
| **Joyería y bisutería** | Plata, piedras locales; diseños con motivos uruguayos | Montevideo y costa |

### Artesanía afrouruguaya

La comunidad afrouruguaya tiene tradiciones artesanales propias, vinculadas al candombe y a las expresiones del Carnaval: confección de vestuario de comparsa, instrumentos (tambores), ornamentación.

### Artesanía y turismo

La artesanía uruguaya es uno de los principales atractivos para el turismo. En Montevideo, la **Feria de Tristán Narvaja** (domingo) y la **Feria de la Ciudad Vieja** son los principales mercados donde se comercializa artesanía junto a antigüedades y productos usados. En los balnearios, los mercados artesanales estivales son puntos de venta importantes.

### MIEM — Apoyo a la artesanía

El **Ministerio de Industria, Energía y Minería (MIEM)** y el **MEC** tienen programas de apoyo y certificación de artesanos. El FEFCA del MEC incluye líneas para artesanía.

## Piedras semipreciosas de Artigas

El departamento de **Artigas** (noroeste de Uruguay) es mundialmente reconocido por la producción de **ágata, amatista y cuarzo**, extraídos de los yacimientos geológicos de la región fronteriza con Brasil. Uruguay es uno de los principales exportadores de piedras semipreciosas de América del Sur.

Las piedras de Artigas se comercializan como materia prima (a lapidarios y joyeros nacionales e internacionales) y como artesanía terminada (objetos decorativos, joyería). La ciudad de Artigas tiene una importante actividad de talla y pulido de piedras.

## Diseño uruguayo

### Diseño gráfico y comunicación visual

Uruguay tiene una escena de **diseño gráfico** activa, con agencias y estudios de nivel regional. La **Escuela Universitaria de Diseño (EUD)** de la Udelar y la carrera de Diseño Industrial de la **Facultad de Arquitectura, Diseño y Urbanismo (FADU)** son los centros de formación principales.

### Diseño de indumentaria y moda

La industria de la **moda** en Uruguay está dominada por marcas nacionales que trabajan principalmente el mercado local y con exportaciones a la región. La **lana merino** uruguaya, de alta calidad, ha sido la base de una industria textil de exportación con marcas como:

- **Manos del Uruguay:** cooperativa de artesanas textiles; exporta lana artesanal de alta calidad a mercados internacionales desde los años 60
- **Campera:** empresa de indumentaria
- Marcas de diseño de autor

### Manos del Uruguay

**Manos del Uruguay** es una de las cooperativas artesanales más exitosas del Uruguay. Fundada en 1968, agrupa a tejedoras y artesanas de todo el país que producen lanas, tejidos y prendas de lana merino de alta calidad. Sus productos se exportan a Estados Unidos, Europa y Japón. Es un modelo de cooperativa de artesanía exitosa con proyección internacional.

### Diseño de muebles y decoración

Uruguay tiene un sector de **diseño de interiores y muebles** activo, especialmente vinculado al trabajo en maderas nativas y materiales locales.

### Diseño industrial

La carrera de **Diseño Industrial** de la FADU-Udelar forma diseñadores que trabajan en productos, packaging y sistemas industriales.

## Artesanía digital y nuevas formas

Con el avance de las tecnologías de fabricación (impresión 3D, laser cutting), una nueva generación de artesanos y diseñadores uruguayos trabaja en la intersección entre lo artesanal y lo digital.

## Palabras clave

artesanía uruguaya, diseño uruguayo, artesanía cuero Uruguay, artesanía lana Uruguay, piedras semipreciosas Artigas Uruguay, ágata amatista Uruguay, Manos del Uruguay cooperativa, Feria Tristán Narvaja Montevideo artesanía, diseño gráfico Uruguay, diseño industrial Uruguay FADU, moda Uruguay, lana merino Uruguay exportación, artesanía afrouruguaya, cestería Uruguay, cerámica artesanal Uruguay, FEFCA artesanía Uruguay
