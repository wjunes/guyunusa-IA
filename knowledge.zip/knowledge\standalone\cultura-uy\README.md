# Dominio cultura-uy — Base Nacional de Conocimiento Uruguay

## Descripción

El dominio `cultura-uy` documenta la **vida cultural de la República Oriental del Uruguay**: política cultural del Estado, instituciones, expresiones artísticas (literatura, música, teatro, danza, cine, artes visuales), el Carnaval de Montevideo, industrias creativas, festivales, artesanía y cooperación cultural internacional. Está diseñado para sistemas RAG y como base de conocimiento para investigadores, periodistas, docentes, funcionarios y sistemas de inteligencia artificial.

## Relación con otros dominios

- **`patrimonio-uy`:** el patrimonio cultural material e inmaterial tiene dominio propio; este dominio se enfoca en la producción cultural viva y las instituciones de fomento
- **`educacion-uy`:** las instituciones educativas de artes (INBA, CFE, INAE) se documentan también en `educacion-uy`

## Fuentes principales

- MEC / Dirección Nacional de Cultura: www.gub.uy/ministerio-educacion-cultura
- SODRE: www.sodre.gub.uy
- ICAU (Instituto del Cine y Audiovisual del Uruguay): www.icau.mec.gub.uy
- Montevideo Portal: www.montevideo.gub.uy
- DAECPU (Carnaval): www.daecpu.com.uy

## Archivos del dominio

| Archivo | Contenido |
|---------|-----------|
| `01-dnc-politica-cultural.md` | Dirección Nacional de Cultura, FEFCA, política cultural del Estado |
| `02-sodre.md` | SODRE: historia, TV pública (Canal 5), radios, ópera, ballet, orquesta |
| `03-literatura-uruguaya.md` | Literatura: figuras, movimientos, obras fundamentales |
| `04-musica-uruguaya.md` | Música: candombe, tango, murga, folclore, rock, pop, nuevas escenas |
| `05-carnaval-montevideo.md` | Carnaval de Montevideo: historia, modalidades, tablados, organización |
| `06-teatro-danza.md` | Teatro y danza: historia, compañías, espacios, INAE |
| `07-cine-uruguayo.md` | Cine uruguayo: historia, directores, películas, ICAU |
| `08-artes-visuales.md` | Torres García, Figari, Barradas, generaciones de artistas plásticos |
| `09-musica-popular-contemporanea.md` | Escena musical contemporánea: rock, pop, cumbia, electrónica |
| `10-festivales-eventos.md` | Festivales culturales nacionales e internacionales en Uruguay |
| `11-artesania-diseño.md` | Artesanía tradicional y diseño uruguayo |
| `12-cultura-interior.md` | Cultura departamental y descentralización cultural |
| `13-industrias-culturales.md` | Economía de la cultura e industrias creativas |
| `14-cooperacion-cultural.md` | Cooperación internacional en cultura |
| `15-estadisticas-cultura.md` | Indicadores y estadísticas culturales |
| `16-glosario.md` | Terminología del campo cultural uruguayo |

## Lo que este dominio NO incluye en profundidad

- Patrimonio cultural material e inmaterial (ver dominio `patrimonio-uy`)
- Deporte (ver dominio `deportes-uy`)
- Historia política (ver dominio `historia-uy`)
- Educación artística formal (ver dominio `educacion-uy`)

## Palabras clave

cultura Uruguay, DNC MEC Uruguay, SODRE Uruguay, literatura uruguaya, música uruguaya, Carnaval Montevideo, teatro uruguayo, cine uruguayo, artes visuales Uruguay, Torres García Uruguay, candombe Uruguay, tango Uruguay, FEFCA cultura Uruguay, festivales culturales Uruguay, industrias creativas Uruguay
