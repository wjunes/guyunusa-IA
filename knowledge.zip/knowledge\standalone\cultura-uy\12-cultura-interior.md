# Cultura en el Interior de Uruguay

## Descripción

La **vida cultural del interior** de Uruguay presenta características propias que la distinguen de la escena montevideana. Con tradiciones gauchescas, folclóricas y comunitarias profundas, y apoyada por las políticas de descentralización del MEC y las Intendencias, la cultura en el interior es un componente fundamental de la identidad nacional.

## Características de la cultura en el interior

### Identidad territorial

Cada región del Uruguay tiene expresiones culturales con identidad propia:

| Región | Expresiones culturales características |
|--------|--------------------------------------|
| **Litoral (Salto, Paysandú, Colonia)** | Cultura fluvial; influencia argentina del litoral; música de chamarrita |
| **Norte (Rivera, Artigas, Tacuarembó)** | Frontera con Brasil: cultura binacional; chamamé, música gaúcha, carnaval del noreste |
| **Este (Maldonado, Rocha, Treinta y Tres)** | Cultura costera; turismo; tradiciones lugareñas |
| **Centro (Durazno, Florida, Flores)** | Ganadería; tradición gauchesca; folklore |
| **Noreste (Cerro Largo, Rivera)** | Influencia gaúcha brasileña; doble cultura |

### La frontera con Brasil

Los departamentos del noreste (Rivera, Cerro Largo, Artigas) tienen una **cultura fronteriza** única, donde el español y el portugués se mezclan en el **portuñol** (o "fronterizo"), y las expresiones culturales de Uruguay y Brasil se superponen. El **carnaval de Rivera** tiene características similares al carnaval brasileño (diferente del montevideano).

## Infraestructura cultural del interior

### Centros MEC

La red de **Centros MEC** es el principal instrumento del Estado para acercar la cultura y la educación al interior del país. Hay más de **200 Centros MEC** distribuidos en todo el territorio, con énfasis en localidades pequeñas y medianas.

Servicios en Centros MEC:
- Acceso gratuito a internet y computadoras
- Exhibición de cine, teatro y música
- Talleres y cursos culturales
- Orientación educativa

### Teatros departamentales

Las 19 capitales departamentales tienen **teatros municipales o departamentales**, muchos de ellos de valor patrimonial. Algunos ejemplos:
- **Teatro Larrañaga (Salto):** importante teatro del interior con larga historia
- **Teatro Macció (San José):** edificio histórico; sede de eventos culturales
- **Teatro Artigas (Artigas):** sala departamental

### Museos departamentales

Cada departamento tiene museos de historia regional y algunos museos temáticos. Ver archivo `08-museos-nacionales.md` en `patrimonio-uy` para listado.

### Espacios alternativos

El interior tiene también espacios culturales comunitarios: casas de cultura, centros barriales, clubes sociales que organizan actividades artísticas y culturales.

## La tradición gauchesca

La **tradición gauchesca** es la expresión cultural más extendida e identificatoria del interior uruguayo. Comprende:

- La **jineteada y doma**: habilidades ecuestres tradicionales
- La **música folclórica**: milonga, estilo, cifra, payada
- La **indumentaria gaucha**: bombacha, bota, faja, chiripá, poncho
- Las **ferias y remates de ganado**: espacios de socialización rural
- Los **fogones y asados** como ritual social

### Movimiento Gaucho Organizado

La Asociación Rural del Uruguay y diversas agrupaciones criollas y gauchescas organizan eventos de habilidades criollas en todo el país. La **Federación Gaucha Uruguaya** agrupa a las agrupaciones departamentales.

### Fiesta de la Patria Gaucha (Tacuarembó)

La **Fiesta de la Patria Gaucha**, realizada en **Tacuarembó** en marzo, es el mayor festival de la cultura gauchesca de Uruguay. Atrae a miles de visitantes de Uruguay, Argentina y Brasil. Incluye jineteadas, destrezas criollas, espectáculos de música folclórica y mercado artesanal. Tacuarembó también reivindica ser el lugar de nacimiento de Carlos Gardel.

## Cultura fronteriza uruguayo-brasileña

### El Portuñol

El **portuñol** (también llamado "DPU" — Dialecto Portugués del Uruguay, o simplemente "fronterizo") es la variedad lingüística mezclada de español y portugués que hablan las comunidades de los departamentos fronterizos. No es un dialecto estigmatizado sino una forma de comunicación viva y reconocida.

### Manifestaciones culturales compartidas

En la frontera con Brasil, el carnaval, la música gaúcha, el chamamé y otras expresiones brasileiras se mezclan con las uruguayas generando expresiones culturales híbridas únicas.

## Política de descentralización cultural

### MEC y Centros MEC

La descentralización cultural es una prioridad explícita del MEC. Los Centros MEC, el FEFCA con líneas para el interior, y los programas de giras de espectáculos son instrumentos de esta política.

### Fondos Concursables de las Intendencias

Las Intendencias departamentales tienen fondos concursables para proyectos culturales locales. La participación del gobierno departamental en la vida cultural es significativa en el interior.

### UTEC y cultura universitaria en el interior

La **UTEC**, con 12 sedes en el interior, ha contribuido a generar vida universitaria y actividad cultural en ciudades que anteriormente no tenían presencia universitaria.

## Palabras clave

cultura interior Uruguay, descentralización cultural Uruguay, Centros MEC cultura interior, tradición gauchesca Uruguay, Fiesta Patria Gaucha Tacuarembó, carnaval Rivera Uruguay, cultura fronteriza Uruguay Brasil, portuñol Uruguay, teatros departamentales Uruguay, museos regionales Uruguay, jineteada Uruguay, folklore regional Uruguay, litoral uruguayo cultura, norte Uruguay cultura, Federación Gaucha Uruguay, identidad cultural departamental Uruguay
