# Teatro y Danza en Uruguay

## Descripción

El **teatro** y la **danza** en Uruguay tienen una tradición intensa y continua, con una escena independiente especialmente vigorosa en Montevideo. El teatro uruguayo fue uno de los espacios de resistencia cultural durante la dictadura y de efervescencia creativa tras el retorno democrático. La danza, impulsada por el **Ballet Nacional del SODRE** y una creciente escena contemporánea, también ocupa un lugar central en la vida cultural del país.

## Historia del teatro uruguayo

### Orígenes: Florencio Sánchez y el teatro rioplatense (1890–1920)

El teatro uruguayo moderno nació con **Florencio Sánchez (1875–1910)**, dramaturgo que fundó el teatro rioplatense con obras que retrataban la sociedad de principios del siglo XX: los conflictos entre lo rural y lo urbano, la inmigración, la familia.

| Obra | Tema |
|------|------|
| *M'hijo el dotor* (1903) | Conflicto generacional: padre gaucho, hijo letrado |
| *La gringa* (1904) | La inmigración italiana en la campaña uruguaya |
| *Barranca abajo* (1905) | La decadencia del gaucho; considerada su obra maestra |

### Teatro independiente (1940–1973)

El movimiento del **Teatro Independiente** fue determinante en la historia teatral uruguaya. Inspirado en las ideas de Stanislavski y en el teatro europeo de vanguardia, el movimiento se propuso crear un teatro artístico y comprometido, alejado del mercado comercial.

**El Galpón** (fundado en 1949) fue la institución teatral independiente más importante del Uruguay:
- Creó una escuela de formación actoral
- Desarrolló un repertorio clásico y contemporáneo de alta calidad
- Fue exiliada colectivamente a México durante la dictadura (1976)

### Dictadura: exilio, censura y resistencia (1973–1985)

La dictadura tuvo un impacto devastador sobre el teatro:
- **El Galpón** fue clausurado en 1976 y su elenco se exilió en México
- Numerosos dramaturgos, directores y actores fueron vetados, detenidos o exiliados
- La censura previa de los textos teatrales fue sistemática
- A pesar de todo, pequeñas salas y grupos sobrevivieron con obras crípticas o disfrazadas

### Retorno democrático: proliferación teatral (1985–presente)

Con la restauración democrática, el teatro uruguayo vivió un **renacimiento explosivo**:
- El Galpón regresó de México en 1984
- Proliferación de grupos y salas independientes
- Teatro de texto, teatro físico, teatro danza, performance
- Integración de las nuevas generaciones formadas en el exilio o durante la resistencia

## Teatro independiente y comercial

### El Galpón

**El Galpón** es la institución teatral independiente más importante de la historia uruguaya. Fundado en 1949, con sede en Montevideo, ha formado generaciones de actores y directores, y ha presentado un repertorio que abarca desde el teatro clásico hasta el contemporáneo.

El exilio en México (1976–1984) y el posterior retorno son parte fundamental de su historia.

### Comedia Nacional

La **Comedia Nacional** es el elenco teatral estatal de Uruguay, dependiente de la **Intendencia de Montevideo**. Funciona en el **Teatro Solís** y desarrolla una temporada anual con obras del repertorio clásico universal y contemporáneo.

### Teatro Circular

El **Teatro Circular** (fundado en 1954) es otra institución emblemática del teatro independiente montevideano, con una sala en el Parque Rodó que lleva décadas activa.

### Escena independiente contemporánea

Montevideo tiene una escena teatral independiente muy activa con decenas de salas pequeñas y medianas, grupos establecidos y colectivos emergentes. El **Festival Internacional de Teatro** de Montevideo es un evento relevante para la escena.

## Formación teatral

- **Escuela Municipal de Arte Dramático (EMAD):** formación actoral dependiente de la Intendencia de Montevideo
- **Cursos del INAE:** el Instituto Nacional de Artes Escénicas (MEC) apoya la formación en artes escénicas
- **Talleres y cursos privados:** abundante oferta de formación actoral y técnica
- **FADU (Udelar):** diseño escénico y arquitectura teatral

## Danza en Uruguay

### Ballet Nacional del SODRE (BNS)

El **Ballet Nacional del SODRE** es la compañía de danza clásica y contemporánea del Estado uruguayo. Fundado en 1931, es la compañía más antigua e importante del país.

| Dato | Información |
|------|-------------|
| Fundación | 1931 |
| Repertorio | Ballet clásico + danza contemporánea |
| Sede | Auditorio Nacional del SODRE |
| Actividades | Temporada anual; giras nacionales e internacionales |

### Danza contemporánea e independiente

Uruguay tiene una vigorosa escena de **danza contemporánea** independiente, con compañías y coreógrafos de proyección nacional e internacional. El INAE apoya la danza junto al teatro y el circo.

### INAE — Instituto Nacional de Artes Escénicas

El **INAE** (dependiente de la DNC/MEC) es el organismo de apoyo institucional a las artes escénicas en Uruguay, cubriendo teatro, danza y circo mediante subsidios, espacios y programas de difusión.

## Principales espacios escénicos

| Espacio | Ciudad | Capacidad / Perfil |
|---------|--------|-------------------|
| **Teatro Solís** | Montevideo | ~1.100 plazas; Comedia Nacional; ópera; grandes producciones |
| **Auditorio Nacional del SODRE** | Montevideo | Salas múltiples; ballet; ópera; música |
| **Teatro El Galpón** | Montevideo | Sala principal + salas menores |
| **Teatro Circular** | Montevideo | Sala circular; teatro independiente |
| **Teatro Circular de Comedias** | Montevideo | — |
| **La Candela** | Montevideo | Sala independiente |
| **Teatro Stella d'Italia** | Montevideo | Sala histórica |
| **Teatros departamentales** | Interior | Salas en capitales departamentales |

## Palabras clave

teatro uruguayo, Florencio Sánchez teatro Uruguay, El Galpón Uruguay, Comedia Nacional Uruguay, Teatro Solís Uruguay, danza Uruguay, Ballet Nacional SODRE Uruguay, teatro independiente Uruguay, exilio El Galpón México Uruguay dictadura, INAE artes escénicas Uruguay, EMAD Montevideo teatro, Carnaval teatro Uruguay, teatro político Uruguay, danza contemporánea Uruguay, Festival Internacional Teatro Uruguay, historia teatro rioplatense Uruguay
