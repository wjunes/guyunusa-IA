# Festivales y Eventos Culturales en Uruguay

## Descripción

Uruguay tiene un calendario cultural activo con **festivales y eventos** que cubren música, teatro, cine, literatura, artes visuales y cultura popular. Muchos de estos eventos tienen proyección internacional y atraen visitantes de toda América Latina. El Carnaval de Montevideo es el mayor evento cultural del país, pero existe una amplia oferta complementaria a lo largo del año.

## Eventos de referencia nacional

### Carnaval de Montevideo

| Dato | Información |
|------|-------------|
| Período | Fines de enero – principios de marzo |
| Duración | ~40 días (el más largo del mundo) |
| Organización | DAECPU + Intendencia de Montevideo |
| Sede principal | Teatro de Verano Ramón Collazo |
| Contenido | Murga, candombe-comparsa, parodistas, revistas, humoristas |

El mayor evento cultural de Uruguay y el carnaval más largo del mundo. Ver archivo `05-carnaval-montevideo.md` para detalles.

### Las Llamadas de Candombe

| Dato | Información |
|------|-------------|
| Período | Durante el Carnaval (febrero) |
| Ubicación | Barrio Sur y Palermo, Montevideo |
| Contenido | Desfile de cuerdas de tambores; el corazón del candombe |

Las **Llamadas** son el desfile central del candombe en el Carnaval. Cuerdas de tambores de distintos barrios desfilan por las calles del Barrio Sur y Palermo ante decenas de miles de espectadores. Es uno de los espectáculos más vibrantes y emocionantes de la cultura uruguaya.

### Desfile de Llamadas (fuera del Carnaval)

Además del Carnaval, hay desfiles de cuerdas de tambores en otras fechas del año en diferentes barrios de Montevideo.

## Festivales de música

### Montevideo Jazz

| Dato | Información |
|------|-------------|
| Género | Jazz |
| Período | Generalmente en octubre-noviembre |
| Contenido | Artistas locales e internacionales; conciertos gratuitos y pagos |

El **Festival de Jazz de Montevideo (Montevideo Jazz)** es uno de los festivales de jazz más importantes de América del Sur, con programación que combina artistas uruguayos y figuras internacionales.

### Festival Internacional de Folklore de Durazno

| Dato | Información |
|------|-------------|
| Departamento | Durazno |
| Período | Enero (durante el verano) |
| Contenido | Folclore uruguayo, rioplatense y latinoamericano |

El **Festival de Durazno** es el principal festival de música folclórica de Uruguay. Atrae a artistas de todo el país y de Argentina, Brasil y Chile. Se realiza al aire libre y tiene una asistencia masiva.

### Cactus Festival

Festival de rock, metal y géneros alternativos con artistas nacionales e internacionales. Realizado en Montevideo.

### Festival de Músicas del Mundo (FMM)

Festival que trae músicas de diferentes culturas del mundo a Uruguay.

## Festivales de teatro

### Festival Internacional de Teatro de Montevideo

El **Festival Internacional de Teatro de Montevideo** es el principal evento del sector teatral, con participación de compañías nacionales e internacionales. Organizado periódicamente por organismos culturales de la Intendencia.

## Festivales de cine

### Festival Cinematográfico Internacional del Uruguay

| Dato | Información |
|------|-------------|
| Organización | Cinemateca Uruguaya |
| Período | Generalmente en abril |
| Contenido | Cine de arte y autor; selecciones internacionales; retrospectivas |

El **Festival Cinematográfico Internacional del Uruguay**, organizado por la Cinemateca Uruguaya, es el principal festival de cine del país y uno de los más antiguos de América Latina.

### DocMontevideo

Festival dedicado al **documental**, con participación de realizadores uruguayos y latinoamericanos.

## Ferias del libro

### Feria del Libro de Montevideo

La **Feria del Libro de Montevideo** es el evento literario más importante del Uruguay. Se realiza en el **Parque Rodó** de Montevideo y convoca a editoriales, libreros, escritores y lectores de todo el país y de la región. Incluye presentaciones, charlas y firma de ejemplares.

## Eventos culturales de verano

El verano uruguayo (diciembre-marzo) concentra muchos eventos culturales, especialmente en Montevideo y en los balnearios:

| Evento | Descripción |
|--------|-------------|
| **Festival de Música de Punta del Este** | Conciertos en el balneario más conocido de Uruguay |
| **Carnaval de las Promesas** | Festival de Carnaval para niños |
| **Desfiles y eventos en los balnearios** | Actividades culturales en la costa |

## Eventos culturales del interior

| Evento | Departamento | Descripción |
|--------|-------------|-------------|
| **Festival de Folklore de Durazno** | Durazno | Folclore nacional e internacional |
| **Festival de Jazz de Salto** | Salto | Jazz en el interior |
| **Semana de la Cerveza Artesanal** | Rivera | Festival binacional con Brasil |
| **Festival de Teatro de Rivera** | Rivera | Teatro en la frontera con Brasil |
| **Fiesta de la Patria Gaucha** (Tacuarembó) | Tacuarembó | Celebración de la tradición gaucha; jineteada; música folclórica |
| **Festival de la Vendimia** (Canelones) | Canelones | Celebración de la cosecha vinícola |

### La Patria Gaucha (Tacuarembó)

La **Fiesta de la Patria Gaucha** en **Tacuarembó** es el principal festival de la cultura gauchesca en Uruguay. Cada año (en marzo), miles de visitantes de Uruguay, Argentina y Brasil asisten a jineteadas, domas, destrezas criollas y espectáculos de música folclórica. Tacuarembó es también conocida por reivindicar el nacimiento de **Carlos Gardel** en la localidad de Tacuarembó (controversia histórica no resuelta).

## Espacios culturales de referencia

| Espacio | Ciudad | Tipo |
|---------|--------|------|
| **Parque Rodó** | Montevideo | Parque con múltiples equipamientos culturales: MNAV, Planetario, Teatro de Verano |
| **Ciudad Vieja** | Montevideo | Concentración de galerías, cafés culturales, espacios alternativos |
| **Peatonal Sarandí** | Montevideo | Eje peatonal con actividades culturales y artísticas |
| **Espacio de Arte Contemporáneo (EAC)** | Montevideo | Arte contemporáneo |
| **Centro Cultural de España** | Montevideo | Programación cultural hispano-uruguaya |

## Palabras clave

festivales culturales Uruguay, Carnaval Montevideo evento cultural, Llamadas candombe Montevideo, Festival Jazz Montevideo, Festival Folklore Durazno Uruguay, Festival Cinematográfico Internacional Uruguay Cinemateca, Feria Libro Montevideo, Fiesta Patria Gaucha Tacuarembó Uruguay, teatro festival Uruguay, cine festival Uruguay, cultura verano Uruguay, festivales interior Uruguay, Parque Rodó Montevideo cultural, eventos culturales Uruguay calendario
