# Música Popular Contemporánea en Uruguay

## Descripción

La **escena musical contemporánea uruguaya** es diversa, activa y con creciente proyección regional e internacional. Desde el rock y el ska-punk hasta la electrónica, el trap, la cumbia, el reggaetón y los géneros de fusión, Uruguay produce artistas y bandas con audiencias en toda América Latina. La tradición del candombe, el tango y la murga permea y enriquece las expresiones contemporáneas.

## Rock y géneros alternativos

### Bandas históricas y clásicas

| Banda / Artista | Activa desde | Género | Datos |
|-----------------|-------------|--------|-------|
| **El Cuarteto de Nos** | 1984 | Rock / humor / pop | Una de las bandas más longevas de Uruguay; *Raro* (2009), *Bipolar* (2012); reconocimiento en Argentina y México |
| **La Vela Puerca** | 1995 | Ska-punk / rock | Gran repercusión en Argentina; *De Bichos y Flores*, *Deskarado* |
| **No Te Va Gustar** | 1994 | Ska-punk / rock | Una de las bandas uruguayas de mayor éxito en el exterior; múltiples premios; *El Calor del Pleno Verano* |
| **Buitres** | 1986 | Rock / punk | Pioneros del rock uruguayo post-dictadura |
| **Los Estómagos** | 1982 | Punk / rock | Banda pionera del punk uruguayo |
| **Fuck the Mainstream** | — | Post-punk | — |

### Escena indie y alternativa contemporánea

La escena indie y alternativa montevideana tiene grupos y artistas activos con proyección creciente:

- **Buceo Invisible:** indie rock; presencia en festivales latinoamericanos
- **Nómade:** electrónica y rock alternativo
- **Superstar:** pop-rock
- **Maldita Bidú:** — 
- **Arocena:** R&B y soul; Luana Belmonte (conocida como "Arocena"); artista femenina de gran proyección regional; fusión de soul, candombe y jazz

### Luana Belmonte / Arocena

**Arocena** (Luana Belmonte) es una de las artistas uruguayas con mayor proyección internacional en la escena contemporánea. Su música fusiona **soul, candombe, jazz y gospel** con letras en inglés y español. Ha actuado en festivales internacionales y tiene seguidores en toda América Latina, Europa y Estados Unidos.

## Reggaetón, trap y música urbana

Uruguay tiene una escena de **música urbana** creciente, con artistas que producen reggaetón, trap y géneros afines con audiencias locales y regionales. La escena urbana montevideana tiene productores, beatmakers y artistas que participan del mercado latinoamericano de la música digital.

## Cumbia y géneros populares

La **cumbia** tiene una larga presencia en Uruguay, tanto en su forma argentina (cumbia villera) como en variantes locales. Los bailes de cumbia son eventos masivos en todo el país.

**Yerba Brava** y grupos similares de cumbia argentina tienen gran popularidad en Uruguay; la producción local de cumbia también existe aunque en menor escala.

## Música electrónica

La escena de **música electrónica** montevideana tiene DJs, productores y sellos activos. El **Factor X** y otros festivales locales de electrónica han articulado esta escena. Algunos DJs uruguayos tienen presencia en circuitos internacionales.

## Fusión: candombe, jazz y géneros globales

Una de las características más interesantes de la música popular uruguaya contemporánea es la **fusión del candombe con otros géneros**:

| Artista | Fusión |
|---------|--------|
| **Rubén Rada** | Candombe + rock + soul; figura histórica que popularizó la fusión |
| **No Te Va Gustar** | Ska-punk con percusión de candombe |
| **Arocena** | Candombe + soul + jazz |
| **Federico Leloup** | Jazz + candombe + bossa nova |
| **Bajofondo** | Electrotango rioplatense (proyecto Uruguay-Argentina) |

## Escenas por géneros

### Jazz

Uruguay tiene una escena de **jazz** activa. El **Festival de Jazz de Montevideo** (Montevideo Jazz) reúne artistas locales e internacionales.

Figuras del jazz uruguayo:
- **Hugo Fattoruso (1943–2022):** pianista; miembro fundador de OPA; figura central del jazz y la fusión uruguaya durante décadas
- **Osvaldo Fattoruso (1946–2016):** baterista; hermano de Hugo; OPA
- **Nicolás Fattoruso:** continuador de la tradición familiar en jazz y música electrónica

### Hip hop y rap

El hip hop uruguayo tiene una comunidad activa desde los años 90. Grupos como **Djs Mentes Criminales** y otros colectivos han desarrollado una escena local. El rap en español rioplatense tiene características propias en Uruguay.

## Espacios y circuito musical

| Espacio | Ciudad | Tipo |
|---------|--------|------|
| **Auditorio Nacional del SODRE** | Montevideo | Grandes espectáculos |
| **Teatro de Verano Ramón Collazo** | Montevideo | Carnaval; conciertos masivos al aire libre |
| **Sala Zitarrosa** | Montevideo | Mediana capacidad; música popular |
| **Espacio Maturana** | Montevideo | Mediana capacidad |
| **Palacio Peñarol** | Montevideo | Grandes conciertos |
| **Estadio Centenario** | Montevideo | Megaconciertos |
| **Bares y clubs nocturnos** | Montevideo | Circuito de música en vivo pequeña escala |
| **Pubs y salas del interior** | Interior | Circuito regional |

## Industria musical y plataformas

El ecosistema musical uruguayo incluye:
- **Sellos discográficos independientes:** varias productoras y sellos locales
- **Streaming:** los artistas uruguayos distribuyen en Spotify, YouTube y plataformas globales
- **AGADU (Asociación General de Autores del Uruguay):** organismo de gestión colectiva de derechos de autor en música y otras artes; recauda y distribuye regalías
- **SUGRA:** sociedad de gestión de derechos de los artistas intérpretes

## AGADU

La **AGADU** (Asociación General de Autores del Uruguay) es la entidad de gestión colectiva de derechos de autor para músicos, escritores y otros creadores uruguayos. Recauda derechos de autor por el uso de obras en radio, televisión, espectáculos y plataformas digitales, y los distribuye entre los autores.

## Palabras clave

música popular contemporánea Uruguay, El Cuarteto de Nos Uruguay, La Vela Puerca Uruguay, No Te Va Gustar Uruguay, Arocena Luana Belmonte Uruguay, Rubén Rada candombe Uruguay, rock uruguayo, ska punk Uruguay, jazz Uruguay Hugo Fattoruso, Bajofondo tango electrónico Uruguay, cumbia Uruguay, reggaetón Uruguay, música electrónica Uruguay, AGADU Uruguay derechos autor, escena musical montevideana, fusión candombe géneros Uruguay, festivales música Uruguay
