# Literatura Uruguaya

## Descripción

La **literatura uruguaya** tiene una historia rica y diversa que va desde las crónicas coloniales hasta una producción contemporánea vigorosa. Conocida internacionalmente por figuras como **José Enrique Rodó**, **Horacio Quiroga**, **Juan Carlos Onetti**, **Mario Benedetti** y **Eduardo Galeano**, la literatura uruguaya ha tenido una influencia desproporcionada a su tamaño, especialmente en el ensayo, el cuento y la narrativa latinoamericana del siglo XX.

## Períodos y movimientos literarios

### Literatura colonial y de independencia (siglo XVIII – 1850)

La producción literaria del período colonial fue escasa. Los primeros textos relevantes son:
- **Bartolomé Hidalgo (1788–1822):** considerado el padre de la literatura gauchesca; sus *Cielitos* y *Diálogos* son los primeros textos literarios autóctonos del Río de la Plata con identidad propia
- Documentos históricos y periodísticos del período artiguista

### Romanticismo y generación del 900 (1850–1900)

- **Juan Zorrilla de San Martín (1855–1931):** autor del poema épico *Tabaré* (1888), considerada la obra maestra del romanticismo uruguayo; también escribió *La Leyenda Patria*
- Florece la prensa literaria y el ensayo político

### Generación del 900 (1900–1920)

La **Generación del 900** es el período de mayor brillo intelectual en la historia literaria uruguaya, coincidente con el apogeo del batllismo.

| Autor | Dates | Obra destacada |
|-------|-------|---------------|
| **José Enrique Rodó** | 1871–1917 | *Ariel* (1900): ensayo filosófico de enorme influencia en América Latina; define la identidad latinoamericana frente al materialismo anglosajón |
| **Horacio Quiroga** | 1878–1937 | Maestro del cuento fantástico y de horror; *Cuentos de la selva*, *El almohadón de plumas*, *A la deriva*; referencia del cuento latinoamericano |
| **Florencio Sánchez** | 1875–1910 | Dramaturgo; *M'hijo el dotor*, *La gringa*, *Barranca abajo*; fundador del teatro rioplatense moderno |
| **Delmira Agustini** | 1886–1914 | Poetisa modernista; *El libro blanco*, *Cantos de la mañana*; figura del modernismo latinoamericano femenino |
| **Julio Herrera y Reissig** | 1875–1910 | Poeta modernista; *Las pascuas del tiempo*; influencia en el simbolismo latinoamericano |
| **María Eugenia Vaz Ferreira** | 1875–1924 | Poetisa; *La isla de los cánticos* |

### José Enrique Rodó y el Ariel

**José Enrique Rodó** es el escritor uruguayo de mayor influencia intelectual en América Latina. Su ensayo ***Ariel*** (1900) fue leído por generaciones de jóvenes latinoamericanos como un llamado a defender los valores espirituales de la civilización latina frente al materialismo utilitarista representado por los Estados Unidos (simbolizado por Calibán). El "arielismo" fue un movimiento cultural e ideológico de amplias consecuencias en el continente.

### Vanguardias y narrativa del siglo XX (1920–1960)

| Autor | Dates | Obra destacada |
|-------|-------|---------------|
| **Juana de Ibarbourou** | 1892–1979 | Poetisa; *Las lenguas de diamante*; llamada "Juana de América"; Premio Nacional de Literatura |
| **Felisberto Hernández** | 1902–1964 | Cuentista visionario; precursor del realismo mágico; *Las hortensias*, *El caballo perdido*; influencia sobre Cortázar y García Márquez |
| **Juan Carlos Onetti** | 1909–1994 | Novelista; **Premio Cervantes 1980**; creador de la ciudad ficticia de **Santa María**; *El pozo*, *La vida breve*, *El astillero*, *Juntacadáveres*; figura central de la narrativa latinoamericana |

### Juan Carlos Onetti

**Juan Carlos Onetti** es el novelista uruguayo más reconocido internacionalmente. Su obra, de tono existencialista y pesimista, creó el universo de **Santa María**, ciudad ficticia del interior rioplatense donde se desarrollan sus principales novelas. El **Premio Cervantes (1980)** — el más importante de la literatura en español — lo consagró definitivamente. Vivió gran parte de su vida en exilio voluntario en España, donde murió en 1994.

### Generación del 45 y boom latinoamericano (1945–1975)

La **Generación del 45** fue un movimiento intelectual y literario que renovó la literatura y el pensamiento uruguayo:

| Autor | Dates | Obra destacada |
|-------|-------|---------------|
| **Mario Benedetti** | 1920–2009 | El escritor uruguayo más popular del siglo XX; *La tregua*, *Gracias por el fuego*, *El cumpleaños de Juan Ángel*, *Primavera con una esquina rota*; poeta: *Inventario*; exiliado durante la dictadura |
| **Eduardo Galeano** | 1940–2015 | Periodista y escritor; *Las venas abiertas de América Latina* (1971), *Memoria del fuego*; voz de la izquierda latinoamericana; exiliado durante la dictadura |
| **Idea Vilariño** | 1920–2009 | Poetisa; poemas de amor y existencia; *Nocturnos*, *Poemas de amor* |
| **Carlos Martínez Moreno** | 1917–1986 | Novelista; *El paredón*; sobre la Revolución Cubana |
| **Ángel Rama** | 1926–1983 | Crítico literario; *La ciudad letrada*; figura fundamental de la crítica literaria latinoamericana |

### Mario Benedetti

**Mario Benedetti** es el escritor uruguayo de mayor difusión popular en el mundo hispanohablante. Sus poemas —especialmente los de amor y los de compromiso político— han sido leídos, cantados y recitados por millones de personas. *La tregua* (1960), su novela más conocida, fue traducida a más de veinte idiomas. Exiliado durante la dictadura en Cuba, México y España, regresó a Uruguay en 1985.

### Literatura contemporánea (desde 1985)

Tras el retorno democrático, la literatura uruguaya experimentó una renovación generacional:

| Autor | Obra / Perfil |
|-------|--------------|
| **Tomás de Mattos** | *La fragata de las máscaras*; narrativa histórica |
| **Rafael Courtoisie** | Poesía y narrativa experimental |
| **Hugo Burel** | Narrativa policial y urbana |
| **Andrea Blanqué** | Narrativa; literatura de mujer |
| **Fernanda Trías** | *La azotea*, *Mugre rosa*; narrativa contemporánea; Premio Sor Juana Inés de la Cruz 2021 |
| **Claudia Amengual** | Narrativa y teatro |

**Fernanda Trías** es la figura más destacada de la narrativa uruguaya contemporánea de proyección internacional; su novela *Mugre rosa* (2020) obtuvo el Premio Sor Juana Inés de la Cruz en la Feria Internacional del Libro de Guadalajara.

## Instituciones literarias

| Institución | Descripción |
|-------------|-------------|
| **Biblioteca Nacional** | Depósito legal; catálogo de la producción editorial uruguaya |
| **Academia Nacional de Letras** | Organismo de estudio y difusión de la lengua y literatura |
| **FEFCA (DNC/MEC)** | Fondos de apoyo a la creación literaria |
| **Feria del Libro de Montevideo** | Evento anual de referencia para el sector editorial |
| **Librería de Ávila** | Librería histórica de Montevideo (Ciudad Vieja) |

## Palabras clave

literatura uruguaya, escritores uruguayos, José Enrique Rodó Ariel Uruguay, Horacio Quiroga cuentos Uruguay, Juan Carlos Onetti Premio Cervantes Uruguay, Mario Benedetti Uruguay, Eduardo Galeano Uruguay, Juana de Ibarbourou Uruguay, Delmira Agustini Uruguay, Felisberto Hernández Uruguay, Bartolomé Hidalgo gauchesca Uruguay, Juan Zorrilla San Martín Tabaré Uruguay, Generación del 900 Uruguay, Generación del 45 Uruguay, Fernanda Trías Uruguay Premio Sor Juana, exilio literario Uruguay dictadura, narrativa rioplatense Uruguay
