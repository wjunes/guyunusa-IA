# Inventario BCN-UY

Versión: 24.0.0
Fecha: 2026-07-26
Estado: en desarrollo activo

---

## Resumen

| Métrica | Valor |
|---------|-------|
| **Total bases de conocimiento activas** | **38** |
| — Dominios BCN-UY estructurados | 19 |
| — Bases standalone (RAG puro) | 19 |
| **Total documentos (todas las bases)** | **~757** |
| Documentos de contenido (BCN-UY) | ~377 |
| Documentos standalone | 380 |
| Instituciones (BCN-UY) | 48 |
| Empresas (EMP) | 12 |
| Conceptos (CON) | 17 |
| Personas TEC | 2 |
| Personas SAL | 3 |
| Personas GAS | 2 |
| Personas DRH | 2 |
| Personas MAM | 2 |
| Personas TEL | 2 |
| Plantillas | 8 |
| Documentos de sistema | 3 |
| Dominios pendientes | 0 |

### Bases standalone activas (RAG puro — BM25 + embeddings)

| Base | Archivos |
|------|----------|
| basquet-uy | 22 |
| arquitectura-uy | 22 |
| ciencias-uy | 27 |
| naturaleza-uy | 30 |
| departamentos-uy | 21 |
| energia-uy | 30 |
| pueblos-originarios-uy | 25 |
| agro-uy | 25 |
| geografia-uy | 23 |
| arqueologia-uy | 21 |
| oceanografia-uy | 23 |
| clima-meteorologia-uy | 27 |
| educacion-uy | 22 |
| patrimonio-uy | 15 |
| cultura-uy | 17 |
| educacion-superior-uy | 16 |
| educacion-tecnica-uy | 13 |
| bibliotecas-uy | 11 |
| archivos-uy | 10 |
| **Total** | **380** |

### Tipos de documento disponibles
- **Empresa (EMP):** documentos sobre empresas (TEC). Prefijo EMP.
- **Concepto (CON):** documentos conceptuales (TEC, SAL). Prefijo CON.
- **Tema (TEM), Persona (PER), Institución (INS), Lugar (LUG), Evento (EVT), Obra (OBR), Movimiento (MOV), Normativa (NOR):** tipos estándar de la BCN-UY.

---

## Estructura de directorios

El repositorio tiene **dos árboles de conocimiento con pipelines separados**:

- `knowledge/` — BCN-UY estructurado: IDs tipados, plantillas, subdirectorios `instituciones/` y `personas/`. Pipeline con validación de esquema y extracción de metadatos.
- `standalone/` — RAG puro: Markdown plano, sin IDs, sin YAML frontmatter, `## Palabras clave` al final de cada archivo. Pipeline de chunking directo a vector store + BM25.

```
/
├── knowledge/          ← BCN-UY estructurado
└── standalone/         ← RAG puro (BM25 + embeddings)
    ├── basquet-uy/
    ├── arquitectura-uy/
    ├── ciencias-uy/
    ├── naturaleza-uy/
    ├── departamentos-uy/
    ├── energia-uy/
    ├── pueblos-originarios-uy/
    ├── agro-uy/
    ├── geografia-uy/
    ├── arqueologia-uy/
    ├── oceanografia-uy/
    ├── clima-meteorologia-uy/
    ├── educacion-uy/
    ├── patrimonio-uy/
    ├── cultura-uy/
    ├── educacion-superior-uy/
    ├── educacion-tecnica-uy/
    ├── bibliotecas-uy/
    └── archivos-uy/

knowledge/
├── docs/
│   ├── README.md
│   ├── ids.md
│   └── inventario.md
├── tecnologia/
│   ├── panorama_sector_tecnologico.md
│   ├── historia_informatica_uruguay.md
│   ├── evolucion_industria_software.md
│   ├── ecosistema_startups.md
│   ├── exportacion_software.md
│   ├── gobierno_digital.md
│   ├── inteligencia_artificial_uruguay.md
│   ├── formacion_tecnologica.md
│   ├── marco_legal_incentivos_software.md
│   ├── ciberseguridad_uruguay.md
│   ├── investigacion_innovacion_tech.md
│   ├── tecnologias_emergentes.md
│   ├── software_saas_uruguay.md
│   ├── transformacion_digital_concepto.md
│   ├── ia_concepto.md
│   ├── gobierno_electronico_concepto.md
│   ├── empresas/
│   │   ├── genexus_artech.md
│   │   ├── dlocal.md
│   │   ├── pedidosya.md
│   │   ├── bantotal.md
│   │   ├── quanam.md
│   │   ├── tryolabs.md
│   │   ├── infocorp.md
│   │   ├── pyxis.md
│   │   ├── abstracta.md
│   │   ├── arkano_software.md
│   │   ├── netlabs.md
│   │   └── scanntech.md
│   ├── instituciones/
│   │   ├── agesic.md
│   │   ├── anii.md
│   │   ├── cuti.md
│   │   ├── miem.md
│   │   ├── latu.md
│   │   └── plan_ceibal_tecnologia.md
│   └── personas/
│       ├── nicolas_jodal.md
│       └── sebastian_kanovich.md
├── medio-ambiente/
│   ├── panorama_medio_ambiente.md
│   ├── energia_renovable.md
│   ├── recursos_hidricos.md
│   ├── biodiversidad.md
│   ├── areas_protegidas.md
│   ├── cambio_climatico.md
│   ├── contaminacion_residuos.md
│   ├── industria_forestal_ambiente.md
│   ├── agroquimicos_soja.md
│   ├── costa_marina.md
│   ├── humedales.md
│   ├── politica_ambiental.md
│   ├── ciudades_ambiente.md
│   ├── educacion_ambiental.md
│   ├── transicion_energetica_concepto.md
│   ├── huella_carbono_uruguay.md
│   ├── instituciones/
│   │   ├── ministerio_ambiente.md
│   │   ├── dinama.md
│   │   └── snap.md
│   └── personas/
│       ├── daniel_vidart.md
│       └── ramon_mendez.md
├── telecomunicaciones/
│   ├── panorama_telecomunicaciones.md
│   ├── antel_historia.md
│   ├── internet_conectividad.md
│   ├── telefonia_movil.md
│   ├── radio_uruguay.md
│   ├── television_uruguay.md
│   ├── television_digital.md
│   ├── medios_publicos.md
│   ├── prensa_escrita.md
│   ├── medios_digitales.md
│   ├── medios_interior.md
│   ├── marco_regulatorio.md
│   ├── brecha_digital.md
│   ├── libertad_prensa.md
│   ├── pluralismo_concentracion.md
│   ├── convergencia_digital.md
│   ├── instituciones/
│   │   ├── antel.md
│   │   ├── ursec.md
│   │   └── tv_nacional.md
│   └── personas/
│       ├── carlos_quijano.md
│       └── german_araujo.md
├── derechos-humanos/
│   ├── panorama_derechos_humanos.md
│   ├── historia_derechos_humanos.md
│   ├── dictadura_derechos_humanos.md
│   ├── memoria_verdad_justicia.md
│   ├── derechos_civiles_politicos.md
│   ├── derechos_economicos_sociales_culturales.md
│   ├── derechos_infancia_adolescencia.md
│   ├── derechos_mujer_genero.md
│   ├── diversidad_sexual_identidad_genero.md
│   ├── derechos_pueblos_indigenas.md
│   ├── afrodescendientes_uruguay.md
│   ├── migracion_derechos.md
│   ├── sistema_carcelario.md
│   ├── marco_institucional_ddhh.md
│   ├── ley_caducidad_impunidad.md
│   ├── reparacion_victimas.md
│   ├── instituciones/
│   │   ├── inddhh.md
│   │   ├── secretaria_ddhh_pasado_reciente.md
│   │   └── inmujeres.md
│   └── personas/
│       ├── elena_quinteros.md
│       └── luisa_cuesta.md
├── gastronomia/
│   ├── panorama_gastronomia_uruguaya.md
│   ├── asado_uruguayo.md
│   ├── chivito.md
│   ├── mate_gastronomia.md
│   ├── dulce_de_leche.md
│   ├── vinos_tannat.md
│   ├── pasta_gastronomia.md
│   ├── gastronomia_campo.md
│   ├── pescados_mariscos.md
│   ├── panaderia_reposteria.md
│   ├── ferias_mercados.md
│   ├── gastronomia_contemporanea_montevideo.md
│   ├── productos_lacteos.md
│   ├── bebidas_tradicionales.md
│   ├── terroir_uruguayo.md
│   ├── patrimonio_gastronomico.md
│   ├── instituciones/
│   │   ├── mercado_puerto.md
│   │   ├── conaprole.md
│   │   └── inavi.md
│   └── personas/
│       ├── lucia_soria.md
│       └── roberto_bueno.md
├── salud/
│   ├── panorama_sistema_salud.md
│   ├── historia_salud_publica.md
│   ├── reforma_salud_2007.md
│   ├── organizacion_snis.md
│   ├── atencion_primaria.md
│   ├── atencion_secundaria_terciaria.md
│   ├── vacunacion.md
│   ├── salud_materno_infantil.md
│   ├── salud_mental.md
│   ├── salud_sexual_reproductiva.md
│   ├── control_cancer.md
│   ├── enfermedades_no_transmisibles.md
│   ├── enfermedades_transmisibles.md
│   ├── salud_publica_epidemiologia.md
│   ├── derechos_usuarios_salud.md
│   ├── salud_digital.md
│   ├── emergencias_sanitarias.md
│   ├── profesionales_salud.md
│   ├── mutualismo_iamc.md
│   ├── cuidados_paliativos_trasplantes.md
│   ├── cobertura_universal_salud.md
│   ├── medicina_preventiva_concepto.md
│   ├── epidemiologia_concepto.md
│   ├── instituciones/
│   │   ├── msp.md
│   │   ├── asse.md
│   │   ├── junasa.md
│   │   ├── fonasa.md
│   │   ├── facultad_medicina.md
│   │   └── escuela_enfermeria.md
│   └── personas/
│       ├── manuel_quintela.md
│       ├── roberto_caldeyro_barcia.md
│       └── julio_cesar_estol.md
├── templates/
│   ├── template_persona.md
│   ├── template_tema.md
│   ├── template_movimiento.md
│   ├── template_institucion.md
│   ├── template_lugar.md
│   ├── template_evento.md
│   ├── template_obra.md
│   └── template_normativa.md
├── instituciones/
│   ├── daecpu.md
│   ├── sodre.md
│   ├── teatro_galpon.md
│   ├── comedia_nacional.md
│   ├── parlamento.md
│   ├── corte_electoral.md
│   ├── auf.md
│   ├── anep.md
│   ├── codicen.md
│   ├── dgeip.md
│   ├── dges.md
│   ├── utu.md
│   ├── mec.md
│   ├── udelar.md
│   ├── utec.md
│   ├── ineed.md
│   ├── bcu.md
│   ├── mef.md
│   ├── ine.md
│   ├── bps.md
│   ├── dgi.md
│   ├── uruguay_xxi.md
│   ├── ande.md
│   └── cnd.md
├── economia/
│   ├── historia_economica.md
│   ├── modelo_agroexportador.md
│   ├── industrializacion.md
│   ├── crisis_1982.md
│   ├── crisis_2002.md
│   ├── recuperacion_crecimiento.md
│   ├── produccion_agropecuaria.md
│   ├── ganaderia.md
│   ├── agricultura.md
│   ├── industria_forestal.md
│   ├── industria_alimentaria.md
│   ├── pesca.md
│   ├── energia.md
│   ├── logistica.md
│   ├── servicios_financieros.md
│   ├── turismo_economia.md
│   ├── industria_software.md
│   ├── economia_conocimiento.md
│   ├── desarrollo_sostenible.md
│   ├── comercio_exterior.md
│   ├── mercosur.md
│   ├── zonas_francas.md
│   ├── inversion_extranjera.md
│   ├── politica_fiscal.md
│   ├── politica_monetaria.md
│   ├── sistema_bancario.md
│   └── conceptos_macroeconomicos.md
└── cultura/
    ├── carnaval/
    │   ├── historia.md
    │   ├── murgas/murgas.md
    │   ├── comparsas/comparsas.md
    │   ├── humoristas/humoristas.md
    │   ├── parodistas/parodistas.md
    │   ├── revistas/revistas.md
    │   └── teatro-verano/teatro_verano.md
    ├── candombe/
    │   ├── historia.md
    │   ├── llamadas.md
    │   ├── tambores.md
    │   ├── personajes.md
    │   ├── comparsas/comparsas.md
    │   ├── lagrima_rios.md
    │   └── rosa_luna.md
    ├── musica/
    │   ├── canto_popular.md
    │   ├── rock.md
    │   ├── tango.md
    │   ├── jazz.md
    │   ├── folclore.md
    │   ├── milonga.md
    │   ├── candombe_beat.md
    │   ├── tropical.md
    │   ├── pop.md
    │   ├── academica.md
    │   └── ramon_collazo.md
    ├── literatura/
    │   ├── literatura.md
    │   ├── narrativa.md
    │   ├── poesia.md
    │   ├── ensayo.md
    │   ├── benedetti.md
    │   ├── onetti.md
    │   ├── galeano.md
    │   ├── idea_vilarino.md
    │   ├── delmira_agustini.md
    │   ├── horacio_quiroga.md
    │   ├── juana_de_ibarbourou.md
    │   ├── felisberto_hernandez.md
    │   └── jose_enrique_rodo.md
    ├── teatro/
    │   ├── teatro.md
    │   ├── teatro_independiente.md
    │   ├── teatro_solis.md
    │   ├── atahualpa_del_cioppo.md
    │   ├── china_zorrilla.md
    │   ├── cristina_moran.md
    │   ├── cuque_sclavo.md
    │   ├── taco_larreta.md
    │   ├── alberto_candeau.md
    │   ├── nelly_goitino.md
    │   ├── jorge_bolani.md
    │   ├── florencio_sanchez.md
    │   └── mariana_percovich.md
    ├── plastica/
    │   ├── artes_plasticas.md
    │   ├── torres_garcia.md
    │   ├── pedro_figari.md
    │   ├── paez_vilaro.md
    │   ├── jose_cuneo.md
    │   ├── juan_manuel_blanes.md
    │   ├── museo_torres_garcia.md
    │   └── casapueblo.md
    ├── historia/
    │   ├── historia.md
    │   ├── independencia.md
    │   ├── batllismo.md
    │   ├── dictadura.md
    │   ├── democracia.md
    │   ├── artigas.md
    │   ├── batlle_ordonez.md
    │   ├── lavalleja.md
    │   ├── rivera.md
    │   ├── grito_asencio.md
    │   └── declaracion_independencia.md
    ├── politica/
    │   ├── sistema_politico.md
    │   ├── partido_colorado.md
    │   ├── partido_nacional.md
    │   ├── frente_amplio.md
    │   ├── jose_pedro_varela.md
    │   ├── jose_mujica.md
    │   └── tabare_vazquez.md
    ├── identidad/
    │   ├── identidad.md
    │   ├── mate.md
    │   ├── gastronomia.md
    │   ├── simbolos_nacionales.md
    │   ├── ser_uruguayo.md
    │   └── pueblo_charrua.md
    ├── turismo/
    │   ├── turismo.md
    │   ├── turismo_naturaleza.md
    │   ├── turismo_playa.md
    │   ├── punta_del_este.md
    │   ├── colonia_del_sacramento.md
    │   ├── cabo_polonio.md
    │   ├── quebrada_cuervos.md
    │   ├── valle_lunarejo.md
    │   ├── parque_santa_teresa.md
    │   └── cerro_catedral.md
    ├── deportes/
    │   ├── deportes.md
    │   ├── futbol_uruguayo.md
    │   ├── la_celeste.md
    │   ├── estadio_centenario.md
    │   ├── mundial_1930.md
    │   ├── maracanazo.md
    │   ├── obdulio_varela.md
    │   ├── enzo_francescoli.md
    │   ├── diego_forlan.md
    │   ├── ladislao_mazurkiewicz.md
    │   ├── luis_suarez.md
    │   └── edinson_cavani.md
    └── educacion/
        ├── sistema_educativo.md
        ├── historia_educacion.md
        ├── educacion_inicial_primaria.md
        ├── educacion_media.md
        ├── educacion_tecnico_profesional.md
        ├── educacion_terciaria.md
        ├── plan_ceibal.md
        ├── educacion_permanente.md
        ├── varela_educador.md
        ├── carlos_vaz_ferreira.md
        ├── reina_reyes.md
        ├── jesualdo_sosa.md
        ├── clemente_estable.md
        └── miguel_soler_roca.md
```

---

## Documentos por dominio

### Salud

#### Documentos temáticos SAL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_SAL_0001 | salud/panorama_sistema_salud.md | Panorama del sistema de salud uruguayo | Tema | verificado |
| TEM_SAL_0002 | salud/historia_salud_publica.md | Historia de la salud pública en Uruguay | Tema | verificado |
| TEM_SAL_0003 | salud/reforma_salud_2007.md | Reforma del sistema de salud (2007) y creación del SNIS | Tema | verificado |
| TEM_SAL_0004 | salud/organizacion_snis.md | Organización y funcionamiento del SNIS | Tema | verificado |
| TEM_SAL_0005 | salud/atencion_primaria.md | Atención primaria de salud en Uruguay | Tema | verificado |
| TEM_SAL_0006 | salud/atencion_secundaria_terciaria.md | Atención secundaria y terciaria en Uruguay | Tema | verificado |
| TEM_SAL_0007 | salud/vacunacion.md | Programa Nacional de Vacunación de Uruguay | Tema | verificado |
| TEM_SAL_0008 | salud/salud_materno_infantil.md | Salud materno-infantil en Uruguay | Tema | verificado |
| TEM_SAL_0009 | salud/salud_mental.md | Salud mental en Uruguay | Tema | verificado |
| TEM_SAL_0010 | salud/salud_sexual_reproductiva.md | Salud sexual y reproductiva en Uruguay | Tema | verificado |
| TEM_SAL_0011 | salud/control_cancer.md | Control del cáncer en Uruguay | Tema | verificado |
| TEM_SAL_0012 | salud/enfermedades_no_transmisibles.md | Enfermedades no transmisibles en Uruguay | Tema | verificado |
| TEM_SAL_0013 | salud/enfermedades_transmisibles.md | Enfermedades transmisibles — VIH/SIDA, tuberculosis e ITS | Tema | verificado |
| TEM_SAL_0014 | salud/salud_publica_epidemiologia.md | Salud pública y vigilancia epidemiológica en Uruguay | Tema | verificado |
| TEM_SAL_0015 | salud/derechos_usuarios_salud.md | Derechos y deberes de los usuarios de salud en Uruguay | Tema | verificado |
| TEM_SAL_0016 | salud/salud_digital.md | Salud digital — historia clínica electrónica y telemedicina | Tema | verificado |
| TEM_SAL_0017 | salud/emergencias_sanitarias.md | Emergencias sanitarias y gestión de crisis — COVID-19 | Tema | verificado |
| TEM_SAL_0018 | salud/profesionales_salud.md | Formación y ejercicio profesional en salud en Uruguay | Tema | verificado |
| TEM_SAL_0019 | salud/mutualismo_iamc.md | El mutualismo y las IAMC en Uruguay | Tema | verificado |
| TEM_SAL_0020 | salud/cuidados_paliativos_trasplantes.md | Cuidados paliativos y trasplante de órganos en Uruguay | Tema | verificado |

#### Instituciones SAL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_SAL_0001 | salud/instituciones/msp.md | Ministerio de Salud Pública (MSP) | Institución | verificado |
| INS_SAL_0002 | salud/instituciones/asse.md | Administración de los Servicios de Salud del Estado (ASSE) | Institución | verificado |
| INS_SAL_0003 | salud/instituciones/junasa.md | Junta Nacional de Salud (JUNASA) | Institución | verificado |
| INS_SAL_0004 | salud/instituciones/fonasa.md | Fondo Nacional de Salud (FONASA) | Institución | verificado |
| INS_SAL_0005 | salud/instituciones/facultad_medicina.md | Facultad de Medicina (Universidad de la República) | Institución | verificado |
| INS_SAL_0006 | salud/instituciones/escuela_enfermeria.md | Escuela Universitaria de Enfermería (EUE) — Udelar | Institución | verificado |

#### Personas SAL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_SAL_0001 | salud/personas/manuel_quintela.md | Manuel Quintela | Persona | verificado_con_reservas |
| PER_SAL_0002 | salud/personas/roberto_caldeyro_barcia.md | Roberto Caldeyro Barcia | Persona | verificado |
| PER_SAL_0003 | salud/personas/julio_cesar_estol.md | Julio César Estol | Persona | verificado_con_reservas |

#### Conceptos SAL (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_SAL_0001 | salud/cobertura_universal_salud.md | Cobertura universal de salud en Uruguay | Concepto | verificado |
| CON_SAL_0002 | salud/medicina_preventiva_concepto.md | Medicina preventiva y promoción de la salud en Uruguay | Concepto | verificado |
| CON_SAL_0003 | salud/epidemiologia_concepto.md | Epidemiología — concepto y aplicación en Uruguay | Concepto | verificado |

---

### Instituciones

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_CAR_0001 | instituciones/daecpu.md | DAECPU | Institución | borrador |
| INS_MUS_0001 | instituciones/sodre.md | SODRE | Institución | borrador |
| INS_TEA_0001 | instituciones/teatro_galpon.md | Teatro El Galpón | Institución | borrador |
| INS_TEA_0002 | instituciones/comedia_nacional.md | Comedia Nacional | Institución | borrador |
| INS_POL_0001 | instituciones/parlamento.md | Poder Legislativo — Parlamento | Institución | borrador |
| INS_POL_0002 | instituciones/corte_electoral.md | Corte Electoral | Institución | borrador |
| INS_DEP_0001 | instituciones/auf.md | Asociación Uruguaya de Fútbol (AUF) | Institución | borrador |
| INS_EDU_0001 | instituciones/anep.md | Administración Nacional de Educación Pública (ANEP) | Institución | borrador |
| INS_EDU_0002 | instituciones/codicen.md | Consejo Directivo Central (CODICEN) | Institución | borrador |
| INS_EDU_0003 | instituciones/dgeip.md | Dirección General de Educación Inicial y Primaria (DGEIP) | Institución | borrador |
| INS_EDU_0004 | instituciones/dges.md | Dirección General de Educación Secundaria (DGES) | Institución | borrador |
| INS_EDU_0005 | instituciones/utu.md | Consejo de Educación Técnico-Profesional — UTU | Institución | borrador |
| INS_EDU_0006 | instituciones/mec.md | Ministerio de Educación y Cultura (MEC) | Institución | borrador |
| INS_EDU_0007 | instituciones/udelar.md | Universidad de la República (Udelar) | Institución | borrador |
| INS_EDU_0008 | instituciones/utec.md | Universidad Tecnológica del Uruguay (UTEC) | Institución | borrador |
| INS_EDU_0009 | instituciones/ineed.md | Instituto Nacional de Evaluación Educativa (INEEd) | Institución | borrador |
| INS_ECO_0001 | instituciones/bcu.md | Banco Central del Uruguay (BCU) | Institución | verificado |
| INS_ECO_0002 | instituciones/mef.md | Ministerio de Economía y Finanzas (MEF) | Institución | verificado |
| INS_ECO_0003 | instituciones/ine.md | Instituto Nacional de Estadística (INE) | Institución | verificado |
| INS_ECO_0004 | instituciones/bps.md | Banco de Previsión Social (BPS) | Institución | verificado |
| INS_ECO_0005 | instituciones/dgi.md | Dirección General Impositiva (DGI) | Institución | verificado |
| INS_ECO_0006 | instituciones/uruguay_xxi.md | Uruguay XXI — Agencia de Promoción de Inversiones y Exportaciones | Institución | verificado |
| INS_ECO_0007 | instituciones/ande.md | Agencia Nacional de Desarrollo (ANDE) | Institución | verificado |
| INS_ECO_0008 | instituciones/cnd.md | Corporación Nacional para el Desarrollo (CND) | Institución | verificado |

---

### Medio Ambiente

#### Documentos temáticos MAM

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_MAM_0001 | medio-ambiente/panorama_medio_ambiente.md | Panorama del medio ambiente en Uruguay | Tema | verificado |
| TEM_MAM_0002 | medio-ambiente/energia_renovable.md | Transición energética y energías renovables en Uruguay | Tema | verificado |
| TEM_MAM_0003 | medio-ambiente/recursos_hidricos.md | Recursos hídricos en Uruguay — agua, cuencas y Acuífero Guaraní | Tema | verificado |
| TEM_MAM_0004 | medio-ambiente/biodiversidad.md | Biodiversidad en Uruguay — ecosistemas, flora y fauna | Tema | verificado |
| TEM_MAM_0005 | medio-ambiente/areas_protegidas.md | Sistema Nacional de Áreas Protegidas (SNAP) de Uruguay | Tema | verificado |
| TEM_MAM_0006 | medio-ambiente/cambio_climatico.md | Cambio climático y Uruguay — impactos y compromisos | Tema | verificado |
| TEM_MAM_0007 | medio-ambiente/contaminacion_residuos.md | Contaminación y gestión de residuos en Uruguay | Tema | verificado |
| TEM_MAM_0008 | medio-ambiente/industria_forestal_ambiente.md | La industria forestal y celulosa desde la perspectiva ambiental | Tema | verificado_con_reservas |
| TEM_MAM_0009 | medio-ambiente/agroquimicos_soja.md | Agroquímicos, soja y medio ambiente en Uruguay | Tema | verificado_con_reservas |
| TEM_MAM_0010 | medio-ambiente/costa_marina.md | Recursos costeros y marinos en Uruguay | Tema | verificado |
| TEM_MAM_0011 | medio-ambiente/humedales.md | Humedales en Uruguay — ecosistemas, conservación y amenazas | Tema | verificado |
| TEM_MAM_0012 | medio-ambiente/politica_ambiental.md | Política ambiental en Uruguay — marco legal e institucional | Tema | verificado |
| TEM_MAM_0013 | medio-ambiente/ciudades_ambiente.md | Ciudades y medio ambiente urbano en Uruguay | Tema | verificado |
| TEM_MAM_0014 | medio-ambiente/educacion_ambiental.md | Educación ambiental en Uruguay | Tema | verificado |

#### Instituciones MAM

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_MAM_0001 | medio-ambiente/instituciones/ministerio_ambiente.md | Ministerio de Ambiente de Uruguay | Institución | verificado |
| INS_MAM_0002 | medio-ambiente/instituciones/dinama.md | DINAMA — Dirección Nacional de Medio Ambiente | Institución | verificado |
| INS_MAM_0003 | medio-ambiente/instituciones/snap.md | SNAP — Sistema Nacional de Áreas Protegidas de Uruguay | Institución | verificado |

#### Personas MAM

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_MAM_0001 | medio-ambiente/personas/daniel_vidart.md | Daniel Vidart | Persona | verificado_con_reservas |
| PER_MAM_0002 | medio-ambiente/personas/ramon_mendez.md | Ramón Méndez Galain | Persona | verificado_con_reservas |

#### Conceptos MAM (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_MAM_0001 | medio-ambiente/transicion_energetica_concepto.md | Transición energética — concepto y caso uruguayo | Concepto | verificado |
| CON_MAM_0002 | medio-ambiente/huella_carbono_uruguay.md | Huella de carbono y compromisos climáticos de Uruguay | Concepto | verificado |

---

### Derechos Humanos

#### Documentos temáticos DRH

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_DRH_0001 | derechos-humanos/panorama_derechos_humanos.md | Panorama de los derechos humanos en Uruguay | Tema | verificado |
| TEM_DRH_0002 | derechos-humanos/historia_derechos_humanos.md | Historia de los derechos humanos en Uruguay | Tema | verificado |
| TEM_DRH_0003 | derechos-humanos/dictadura_derechos_humanos.md | La dictadura cívico-militar y las violaciones a los DDHH (1973-1985) | Tema | verificado |
| TEM_DRH_0004 | derechos-humanos/memoria_verdad_justicia.md | Memoria, verdad y justicia en Uruguay | Tema | verificado |
| TEM_DRH_0005 | derechos-humanos/derechos_civiles_politicos.md | Derechos civiles y políticos en Uruguay | Tema | verificado |
| TEM_DRH_0006 | derechos-humanos/derechos_economicos_sociales_culturales.md | Derechos económicos, sociales y culturales en Uruguay | Tema | verificado |
| TEM_DRH_0007 | derechos-humanos/derechos_infancia_adolescencia.md | Derechos de la infancia y la adolescencia en Uruguay | Tema | verificado |
| TEM_DRH_0008 | derechos-humanos/derechos_mujer_genero.md | Derechos de la mujer y perspectiva de género en Uruguay | Tema | verificado |
| TEM_DRH_0009 | derechos-humanos/diversidad_sexual_identidad_genero.md | Diversidad sexual e identidad de género en Uruguay | Tema | verificado |
| TEM_DRH_0010 | derechos-humanos/derechos_pueblos_indigenas.md | Derechos de los pueblos indígenas en Uruguay — el pueblo charrúa | Tema | verificado_con_reservas |
| TEM_DRH_0011 | derechos-humanos/afrodescendientes_uruguay.md | Afrodescendientes y derechos humanos en Uruguay | Tema | verificado |
| TEM_DRH_0012 | derechos-humanos/migracion_derechos.md | Migración y derechos humanos en Uruguay | Tema | verificado |
| TEM_DRH_0013 | derechos-humanos/sistema_carcelario.md | Sistema carcelario y derechos en Uruguay | Tema | verificado |
| TEM_DRH_0014 | derechos-humanos/marco_institucional_ddhh.md | Marco institucional de DDHH en Uruguay | Tema | verificado |

#### Instituciones DRH

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_DRH_0001 | derechos-humanos/instituciones/inddhh.md | Institución Nacional de Derechos Humanos y Defensoría del Pueblo (INDDHH) | Institución | verificado |
| INS_DRH_0002 | derechos-humanos/instituciones/secretaria_ddhh_pasado_reciente.md | Secretaría de DDHH para el Pasado Reciente | Institución | verificado |
| INS_DRH_0003 | derechos-humanos/instituciones/inmujeres.md | Instituto Nacional de las Mujeres (Inmujeres) | Institución | verificado |

#### Personas DRH

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_DRH_0001 | derechos-humanos/personas/elena_quinteros.md | Elena Quinteros Almeida | Persona | verificado |
| PER_DRH_0002 | derechos-humanos/personas/luisa_cuesta.md | Luisa Cuesta | Persona | verificado_con_reservas |

#### Conceptos DRH (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_DRH_0001 | derechos-humanos/ley_caducidad_impunidad.md | Ley de Caducidad e impunidad en Uruguay | Concepto | verificado |
| CON_DRH_0002 | derechos-humanos/reparacion_victimas.md | Reparación a las víctimas de la dictadura en Uruguay | Concepto | verificado |

---

### Telecomunicaciones y Medios

#### Documentos temáticos TEL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_TEL_0001 | telecomunicaciones/panorama_telecomunicaciones.md | Panorama de las telecomunicaciones y medios en Uruguay | Tema | verificado |
| TEM_TEL_0002 | telecomunicaciones/antel_historia.md | ANTEL y la historia de las telecomunicaciones en Uruguay | Tema | verificado |
| TEM_TEL_0003 | telecomunicaciones/internet_conectividad.md | Internet, banda ancha y conectividad en Uruguay | Tema | verificado |
| TEM_TEL_0004 | telecomunicaciones/telefonia_movil.md | Telefonía móvil en Uruguay | Tema | verificado |
| TEM_TEL_0005 | telecomunicaciones/radio_uruguay.md | La radio en Uruguay — historia e impacto cultural | Tema | verificado |
| TEM_TEL_0006 | telecomunicaciones/television_uruguay.md | La televisión en Uruguay — historia y estructura del sistema | Tema | verificado |
| TEM_TEL_0007 | telecomunicaciones/television_digital.md | Televisión digital terrestre (TDT) en Uruguay | Tema | verificado |
| TEM_TEL_0008 | telecomunicaciones/medios_publicos.md | Medios públicos en Uruguay — SODRE y TV Nacional | Tema | verificado |
| TEM_TEL_0009 | telecomunicaciones/prensa_escrita.md | La prensa escrita en Uruguay — historia y presente | Tema | verificado |
| TEM_TEL_0010 | telecomunicaciones/medios_digitales.md | Medios digitales y periodismo online en Uruguay | Tema | verificado |
| TEM_TEL_0011 | telecomunicaciones/medios_interior.md | Medios de comunicación del interior de Uruguay | Tema | verificado |
| TEM_TEL_0012 | telecomunicaciones/marco_regulatorio.md | Marco regulatorio de telecomunicaciones y medios en Uruguay | Tema | verificado |
| TEM_TEL_0013 | telecomunicaciones/brecha_digital.md | Brecha digital en Uruguay | Tema | verificado |
| TEM_TEL_0014 | telecomunicaciones/libertad_prensa.md | Libertad de prensa y expresión en Uruguay | Tema | verificado |

#### Instituciones TEL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_TEL_0001 | telecomunicaciones/instituciones/antel.md | ANTEL — Administración Nacional de Telecomunicaciones | Institución | verificado |
| INS_TEL_0002 | telecomunicaciones/instituciones/ursec.md | URSEC — Unidad Reguladora de Servicios de Comunicaciones | Institución | verificado |
| INS_TEL_0003 | telecomunicaciones/instituciones/tv_nacional.md | TV Nacional Uruguay — Canal 5 | Institución | verificado |

#### Personas TEL

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_TEL_0001 | telecomunicaciones/personas/carlos_quijano.md | Carlos Quijano | Persona | verificado_con_reservas |
| PER_TEL_0002 | telecomunicaciones/personas/german_araujo.md | Germán Araújo | Persona | verificado_con_reservas |

#### Conceptos TEL (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_TEL_0001 | telecomunicaciones/pluralismo_concentracion.md | Pluralismo y concentración de medios en Uruguay | Concepto | verificado |
| CON_TEL_0002 | telecomunicaciones/convergencia_digital.md | Convergencia digital y transformación de los medios en Uruguay | Concepto | verificado |

---

### Gastronomía

#### Documentos temáticos GAS

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_GAS_0001 | gastronomia/panorama_gastronomia_uruguaya.md | Panorama de la gastronomía uruguaya | Tema | verificado |
| TEM_GAS_0002 | gastronomia/asado_uruguayo.md | El asado uruguayo | Tema | verificado |
| TEM_GAS_0003 | gastronomia/chivito.md | El chivito — el sándwich uruguayo | Tema | verificado |
| TEM_GAS_0004 | gastronomia/mate_gastronomia.md | El mate — cultura y práctica gastronómica en Uruguay | Tema | verificado |
| TEM_GAS_0005 | gastronomia/dulce_de_leche.md | El dulce de leche uruguayo | Tema | verificado |
| TEM_GAS_0006 | gastronomia/vinos_tannat.md | Vinos uruguayos y el Tannat | Tema | verificado |
| TEM_GAS_0007 | gastronomia/pasta_gastronomia.md | La pasta en Uruguay — herencia italiana y tradición propia | Tema | verificado |
| TEM_GAS_0008 | gastronomia/gastronomia_campo.md | Cocina de campo y tradición gaucha en Uruguay | Tema | verificado |
| TEM_GAS_0009 | gastronomia/pescados_mariscos.md | Pescados y mariscos en la gastronomía uruguaya | Tema | verificado |
| TEM_GAS_0010 | gastronomia/panaderia_reposteria.md | Panadería, repostería y facturas en Uruguay | Tema | verificado |
| TEM_GAS_0011 | gastronomia/ferias_mercados.md | Ferias y mercados gastronómicos de Uruguay | Tema | verificado |
| TEM_GAS_0012 | gastronomia/gastronomia_contemporanea_montevideo.md | La escena gastronómica contemporánea en Uruguay | Tema | verificado |
| TEM_GAS_0013 | gastronomia/productos_lacteos.md | Productos lácteos uruguayos — quesos, manteca y Conaprole | Tema | verificado |
| TEM_GAS_0014 | gastronomia/bebidas_tradicionales.md | Bebidas tradicionales uruguayas — grappa, medio y medio, clericó y caña | Tema | verificado |

#### Instituciones GAS

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_GAS_0001 | gastronomia/instituciones/mercado_puerto.md | Mercado del Puerto de Montevideo | Institución | verificado |
| INS_GAS_0002 | gastronomia/instituciones/conaprole.md | Conaprole — Cooperativa Nacional de Productores de Leche | Institución | verificado |
| INS_GAS_0003 | gastronomia/instituciones/inavi.md | INAVI — Instituto Nacional de Vitivinicultura | Institución | verificado |

#### Personas GAS

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_GAS_0001 | gastronomia/personas/lucia_soria.md | Lucía Soria | Persona | verificado_con_reservas |
| PER_GAS_0002 | gastronomia/personas/roberto_bueno.md | Roberto Bueno | Persona | verificado_con_reservas |

#### Conceptos GAS (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_GAS_0001 | gastronomia/terroir_uruguayo.md | Terroir uruguayo — suelo, clima e identidad agroalimentaria | Concepto | verificado |
| CON_GAS_0002 | gastronomia/patrimonio_gastronomico.md | Patrimonio gastronómico e identidad culinaria en Uruguay | Concepto | verificado |

---

### Carnaval

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_CAR_0001 | cultura/carnaval/historia.md | Historia del Carnaval Uruguayo | Tema | borrador |
| TEM_CAR_0002 | cultura/carnaval/murgas/murgas.md | Murgas | Tema | borrador |
| TEM_CAR_0003 | cultura/carnaval/comparsas/comparsas.md | Comparsas | Tema | borrador |
| TEM_CAR_0004 | cultura/carnaval/humoristas/humoristas.md | Humoristas | Tema | borrador |
| TEM_CAR_0005 | cultura/carnaval/parodistas/parodistas.md | Parodistas | Tema | borrador |
| TEM_CAR_0006 | cultura/carnaval/revistas/revistas.md | Revistas | Tema | borrador |
| LUG_CAR_0001 | cultura/carnaval/teatro-verano/teatro_verano.md | Teatro de Verano | Lugar | borrador |

---

### Candombe

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_CAN_0001 | cultura/candombe/historia.md | Historia del Candombe Uruguayo | Tema | borrador |
| TEM_CAN_0002 | cultura/candombe/llamadas.md | Las Llamadas | Tema | borrador |
| TEM_CAN_0003 | cultura/candombe/tambores.md | Los Tambores del Candombe | Tema | borrador |
| TEM_CAN_0004 | cultura/candombe/personajes.md | Personajes del Candombe | Tema | borrador |
| TEM_CAN_0005 | cultura/candombe/comparsas/comparsas.md | Comparsas de Candombe | Tema | borrador |
| PER_CAN_0001 | cultura/candombe/lagrima_rios.md | Lágrima Ríos | Persona | borrador |
| PER_CAN_0002 | cultura/candombe/rosa_luna.md | Rosa Luna | Persona | borrador |

---

### Música

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_MUS_0001 | cultura/musica/canto_popular.md | Canto Popular Uruguayo | Tema | borrador |
| TEM_MUS_0002 | cultura/musica/rock.md | Rock Uruguayo | Tema | borrador |
| TEM_MUS_0003 | cultura/musica/tango.md | Tango Uruguayo | Tema | borrador |
| TEM_MUS_0004 | cultura/musica/jazz.md | Jazz Uruguayo | Tema | borrador |
| TEM_MUS_0005 | cultura/musica/folclore.md | Folclore Uruguayo | Tema | borrador |
| TEM_MUS_0006 | cultura/musica/milonga.md | Milonga Uruguaya | Tema | borrador |
| TEM_MUS_0007 | cultura/musica/candombe_beat.md | Candombe Beat | Tema | borrador |
| TEM_MUS_0008 | cultura/musica/tropical.md | Música Tropical Uruguaya | Tema | borrador |
| TEM_MUS_0009 | cultura/musica/pop.md | Pop Uruguayo | Tema | borrador |
| TEM_MUS_0010 | cultura/musica/academica.md | Música Académica Uruguaya | Tema | borrador |
| PER_MUS_0001 | cultura/musica/ramon_collazo.md | Ramón Collazo | Persona | borrador |

---

### Literatura

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_LIT_0001 | cultura/literatura/literatura.md | Literatura Uruguaya (panorama) | Tema | borrador |
| TEM_LIT_0002 | cultura/literatura/narrativa.md | Narrativa Uruguaya | Tema | borrador |
| TEM_LIT_0003 | cultura/literatura/poesia.md | Poesía Uruguaya | Tema | borrador |
| TEM_LIT_0004 | cultura/literatura/ensayo.md | Ensayo Uruguayo | Tema | borrador |
| PER_LIT_0001 | cultura/literatura/benedetti.md | Mario Benedetti | Persona | borrador |
| PER_LIT_0002 | cultura/literatura/onetti.md | Juan Carlos Onetti | Persona | borrador |
| PER_LIT_0003 | cultura/literatura/galeano.md | Eduardo Galeano | Persona | borrador |
| PER_LIT_0004 | cultura/literatura/idea_vilarino.md | Idea Vilariño | Persona | borrador |
| PER_LIT_0005 | cultura/literatura/delmira_agustini.md | Delmira Agustini | Persona | borrador |
| PER_LIT_0006 | cultura/literatura/horacio_quiroga.md | Horacio Quiroga | Persona | borrador |
| PER_LIT_0007 | cultura/literatura/juana_de_ibarbourou.md | Juana de Ibarbourou | Persona | borrador |
| PER_LIT_0008 | cultura/literatura/felisberto_hernandez.md | Felisberto Hernández | Persona | borrador |
| PER_LIT_0009 | cultura/literatura/jose_enrique_rodo.md | José Enrique Rodó | Persona | borrador |

---

### Teatro

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_TEA_0001 | cultura/teatro/teatro.md | Teatro Uruguayo (panorama) | Tema | borrador |
| TEM_TEA_0002 | cultura/teatro/teatro_independiente.md | Teatro Independiente Uruguayo | Tema | borrador |
| LUG_TEA_0001 | cultura/teatro/teatro_solis.md | Teatro Solís | Lugar | borrador |
| PER_TEA_0001 | cultura/teatro/atahualpa_del_cioppo.md | Atahualpa del Cioppo | Persona | borrador |
| PER_TEA_0002 | cultura/teatro/china_zorrilla.md | China Zorrilla | Persona | borrador |
| PER_TEA_0003 | cultura/teatro/cristina_moran.md | Cristina Morán | Persona | borrador |
| PER_TEA_0004 | cultura/teatro/cuque_sclavo.md | Cuque Sclavo | Persona | borrador |
| PER_TEA_0005 | cultura/teatro/taco_larreta.md | Taco Larreta | Persona | borrador |
| PER_TEA_0006 | cultura/teatro/alberto_candeau.md | Alberto Candeau | Persona | borrador |
| PER_TEA_0007 | cultura/teatro/nelly_goitino.md | Nelly Goitiño | Persona | borrador |
| PER_TEA_0008 | cultura/teatro/jorge_bolani.md | Jorge Bolani | Persona | borrador |
| PER_TEA_0009 | cultura/teatro/florencio_sanchez.md | Florencio Sánchez | Persona | borrador |
| PER_TEA_0010 | cultura/teatro/mariana_percovich.md | Mariana Percovich | Persona | borrador |

---

### Artes Plásticas

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_PLA_0001 | cultura/plastica/artes_plasticas.md | Artes Plásticas Uruguayas (panorama) | Tema | borrador |
| PER_PLA_0001 | cultura/plastica/torres_garcia.md | Joaquín Torres García | Persona | borrador |
| PER_PLA_0002 | cultura/plastica/pedro_figari.md | Pedro Figari | Persona | borrador |
| PER_PLA_0003 | cultura/plastica/paez_vilaro.md | Carlos Páez Vilaró | Persona | borrador |
| PER_PLA_0004 | cultura/plastica/jose_cuneo.md | José Cúneo | Persona | borrador |
| PER_PLA_0005 | cultura/plastica/juan_manuel_blanes.md | Juan Manuel Blanes | Persona | borrador |
| LUG_PLA_0001 | cultura/plastica/museo_torres_garcia.md | Museo Torres García | Lugar | borrador |
| LUG_PLA_0002 | cultura/plastica/casapueblo.md | Casapueblo | Lugar | borrador |

---

### Historia

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_HIS_0001 | cultura/historia/historia.md | Historia del Uruguay (panorama) | Tema | borrador |
| TEM_HIS_0002 | cultura/historia/independencia.md | Independencia y formación del Estado | Tema | borrador |
| TEM_HIS_0003 | cultura/historia/batllismo.md | El Uruguay batllista (1903-1958) | Tema | borrador |
| TEM_HIS_0004 | cultura/historia/dictadura.md | La dictadura cívico-militar (1973-1985) | Tema | borrador |
| TEM_HIS_0005 | cultura/historia/democracia.md | El retorno a la democracia (1985+) | Tema | borrador |
| PER_HIS_0001 | cultura/historia/artigas.md | José Gervasio Artigas | Persona | borrador |
| PER_HIS_0002 | cultura/historia/batlle_ordonez.md | José Batlle y Ordóñez | Persona | borrador |
| PER_HIS_0003 | cultura/historia/lavalleja.md | Juan Antonio Lavalleja | Persona | borrador |
| PER_HIS_0004 | cultura/historia/rivera.md | Fructuoso Rivera | Persona | verificado_con_reservas |
| EVT_HIS_0001 | cultura/historia/grito_asencio.md | El Grito de Asencio (1811) | Evento | borrador |
| EVT_HIS_0002 | cultura/historia/declaracion_independencia.md | Declaración de Independencia (1825) | Evento | borrador |

---

### Política

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_POL_0001 | cultura/politica/sistema_politico.md | Sistema político uruguayo | Tema | borrador |
| TEM_POL_0002 | cultura/politica/partido_colorado.md | Partido Colorado | Tema | borrador |
| TEM_POL_0003 | cultura/politica/partido_nacional.md | Partido Nacional (Blancos) | Tema | borrador |
| TEM_POL_0004 | cultura/politica/frente_amplio.md | Frente Amplio | Tema | borrador |
| PER_POL_0001 | cultura/politica/jose_pedro_varela.md | José Pedro Varela | Persona | borrador |
| PER_POL_0002 | cultura/politica/jose_mujica.md | José Mujica | Persona | borrador |
| PER_POL_0003 | cultura/politica/tabare_vazquez.md | Tabaré Vázquez | Persona | borrador |

*Instituciones de este dominio → ver tabla Instituciones: INS_POL_0001, INS_POL_0002*

---

### Identidad

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_IDN_0001 | cultura/identidad/identidad.md | Identidad uruguaya — panorama | Tema | borrador |
| TEM_IDN_0002 | cultura/identidad/mate.md | El mate | Tema | borrador |
| TEM_IDN_0003 | cultura/identidad/gastronomia.md | Gastronomía uruguaya | Tema | borrador |
| TEM_IDN_0004 | cultura/identidad/simbolos_nacionales.md | Símbolos nacionales | Tema | borrador |
| TEM_IDN_0005 | cultura/identidad/ser_uruguayo.md | Rasgos del ser uruguayo | Tema | borrador |
| TEM_IDN_0006 | cultura/identidad/pueblo_charrua.md | El pueblo charrúa | Tema | borrador |

---

### Turismo

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_TUR_0001 | cultura/turismo/turismo.md | Turismo en Uruguay — panorama | Tema | borrador |
| TEM_TUR_0002 | cultura/turismo/turismo_naturaleza.md | Turismo rural, natural y de senderismo | Tema | borrador |
| TEM_TUR_0003 | cultura/turismo/turismo_playa.md | Turismo de sol y playa | Tema | borrador |
| LUG_TUR_0001 | cultura/turismo/punta_del_este.md | Punta del Este | Lugar | borrador |
| LUG_TUR_0002 | cultura/turismo/colonia_del_sacramento.md | Colonia del Sacramento | Lugar | borrador |
| LUG_TUR_0003 | cultura/turismo/cabo_polonio.md | Cabo Polonio | Lugar | borrador |
| LUG_TUR_0004 | cultura/turismo/quebrada_cuervos.md | Quebrada de los Cuervos | Lugar | borrador |
| LUG_TUR_0005 | cultura/turismo/valle_lunarejo.md | Valle del Lunarejo | Lugar | borrador |
| LUG_TUR_0006 | cultura/turismo/parque_santa_teresa.md | Parque Santa Teresa | Lugar | borrador |
| LUG_TUR_0007 | cultura/turismo/cerro_catedral.md | Cerro Catedral y Sierra de las Ánimas | Lugar | borrador |

---

### Deportes

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_DEP_0001 | cultura/deportes/deportes.md | Deportes en Uruguay — panorama | Tema | borrador |
| TEM_DEP_0002 | cultura/deportes/futbol_uruguayo.md | El fútbol uruguayo | Tema | borrador |
| TEM_DEP_0003 | cultura/deportes/la_celeste.md | La Celeste — selección nacional de fútbol | Tema | borrador |
| LUG_DEP_0001 | cultura/deportes/estadio_centenario.md | Estadio Centenario | Lugar | borrador |
| EVT_DEP_0001 | cultura/deportes/mundial_1930.md | Copa del Mundo 1930 | Evento | borrador |
| EVT_DEP_0002 | cultura/deportes/maracanazo.md | El Maracanazo (1950) | Evento | borrador |
| PER_DEP_0001 | cultura/deportes/obdulio_varela.md | Obdulio Varela | Persona | borrador |
| PER_DEP_0002 | cultura/deportes/enzo_francescoli.md | Enzo Francescoli | Persona | borrador |
| PER_DEP_0003 | cultura/deportes/diego_forlan.md | Diego Forlán | Persona | borrador |
| PER_DEP_0004 | cultura/deportes/ladislao_mazurkiewicz.md | Ladislao Mazurkiewicz | Persona | borrador |
| PER_DEP_0005 | cultura/deportes/luis_suarez.md | Luis Suárez | Persona | borrador |
| PER_DEP_0006 | cultura/deportes/edinson_cavani.md | Edinson Cavani | Persona | borrador |

*Institución de este dominio → ver tabla Instituciones: INS_DEP_0001*

---

### Educación

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_EDU_0001 | cultura/educacion/sistema_educativo.md | Sistema educativo uruguayo — panorama | Tema | borrador |
| TEM_EDU_0002 | cultura/educacion/historia_educacion.md | Historia de la educación uruguaya | Tema | borrador |
| TEM_EDU_0003 | cultura/educacion/educacion_inicial_primaria.md | Educación inicial y primaria | Tema | borrador |
| TEM_EDU_0004 | cultura/educacion/educacion_media.md | Educación media | Tema | borrador |
| TEM_EDU_0005 | cultura/educacion/educacion_tecnico_profesional.md | Educación técnico-profesional | Tema | borrador |
| TEM_EDU_0006 | cultura/educacion/educacion_terciaria.md | Educación terciaria y universitaria | Tema | borrador |
| TEM_EDU_0007 | cultura/educacion/plan_ceibal.md | Plan Ceibal | Tema | borrador |
| TEM_EDU_0008 | cultura/educacion/educacion_permanente.md | Educación permanente y formación continua | Tema | borrador |
| PER_EDU_0001 | cultura/educacion/varela_educador.md | José Pedro Varela — legado pedagógico | Persona | borrador |
| PER_EDU_0002 | cultura/educacion/carlos_vaz_ferreira.md | Carlos Vaz Ferreira | Persona | borrador |
| PER_EDU_0003 | cultura/educacion/reina_reyes.md | Reina Reyes | Persona | verificado_con_reservas |
| PER_EDU_0004 | cultura/educacion/jesualdo_sosa.md | Jesualdo Sosa | Persona | verificado_con_reservas |
| PER_EDU_0005 | cultura/educacion/clemente_estable.md | Clemente Estable | Persona | borrador |
| PER_EDU_0006 | cultura/educacion/miguel_soler_roca.md | Miguel Soler Roca | Persona | verificado_con_reservas |

*Instituciones de este dominio → ver tabla Instituciones: INS_EDU_0001 al INS_EDU_0009*

---

### Economía

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_ECO_0001 | economia/historia_economica.md | Historia económica de Uruguay — panorama | Tema | verificado |
| TEM_ECO_0002 | economia/modelo_agroexportador.md | Modelo agroexportador (1870-1930) | Tema | verificado |
| TEM_ECO_0003 | economia/industrializacion.md | Industrialización y reformas económicas del siglo XX | Tema | verificado |
| TEM_ECO_0004 | economia/crisis_1982.md | Crisis económica de 1982 | Tema | verificado |
| TEM_ECO_0005 | economia/crisis_2002.md | Crisis económica de 2002 | Tema | verificado |
| TEM_ECO_0006 | economia/recuperacion_crecimiento.md | Recuperación y crecimiento (2003-presente) | Tema | verificado |
| TEM_ECO_0007 | economia/produccion_agropecuaria.md | Producción agropecuaria uruguaya — panorama | Tema | verificado |
| TEM_ECO_0008 | economia/ganaderia.md | Ganadería bovina y ovina en Uruguay | Tema | verificado |
| TEM_ECO_0009 | economia/agricultura.md | Agricultura uruguaya — cultivos y producción vegetal | Tema | verificado |
| TEM_ECO_0010 | economia/industria_forestal.md | Industria forestal y celulosa en Uruguay | Tema | verificado |
| TEM_ECO_0011 | economia/industria_alimentaria.md | Industria alimentaria y láctea en Uruguay | Tema | verificado |
| TEM_ECO_0012 | economia/pesca.md | Pesca y acuicultura en Uruguay | Tema | verificado_con_reservas |

| TEM_ECO_0013 | economia/energia.md | Energía en Uruguay — transición a las renovables | Tema | verificado |
| TEM_ECO_0014 | economia/logistica.md | Logística y transporte en Uruguay — hub regional | Tema | verificado |
| TEM_ECO_0015 | economia/servicios_financieros.md | Servicios financieros en Uruguay — plaza financiera regional | Tema | verificado |
| TEM_ECO_0016 | economia/turismo_economia.md | Turismo en Uruguay — economía y destinos | Tema | verificado |
| TEM_ECO_0017 | economia/industria_software.md | Industria del software y servicios tecnológicos en Uruguay | Tema | verificado |
| TEM_ECO_0018 | economia/economia_conocimiento.md | Economía del conocimiento en Uruguay | Tema | verificado |
| TEM_ECO_0019 | economia/desarrollo_sostenible.md | Desarrollo sostenible en Uruguay — economía verde y agenda 2030 | Tema | verificado |
| TEM_ECO_0020 | economia/comercio_exterior.md | Comercio exterior de Uruguay — exportaciones e importaciones | Tema | verificado |
| TEM_ECO_0021 | economia/mercosur.md | MERCOSUR — Uruguay en el bloque regional | Tema | verificado |
| TEM_ECO_0022 | economia/zonas_francas.md | Zonas francas en Uruguay | Tema | verificado |
| TEM_ECO_0023 | economia/inversion_extranjera.md | Inversión extranjera directa en Uruguay | Tema | verificado |
| TEM_ECO_0024 | economia/politica_fiscal.md | Política fiscal de Uruguay — ingresos, gasto y deuda pública | Tema | verificado |
| TEM_ECO_0025 | economia/politica_monetaria.md | Política monetaria en Uruguay — inflación y tipo de cambio | Tema | verificado |
| TEM_ECO_0026 | economia/sistema_bancario.md | Sistema bancario uruguayo — estructura y regulación | Tema | verificado |
| TEM_ECO_0027 | economia/conceptos_macroeconomicos.md | Conceptos macroeconómicos clave para entender la economía uruguaya | Tema | verificado |

*Instituciones de este dominio → ver tabla Instituciones: INS_ECO_0001 al INS_ECO_0008*

---

### Tecnología

#### Documentos temáticos

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| TEM_TEC_0001 | tecnologia/panorama_sector_tecnologico.md | Panorama del sector tecnológico uruguayo | Tema | verificado |
| TEM_TEC_0002 | tecnologia/historia_informatica_uruguay.md | Historia de la informática en Uruguay (1960-2010) | Tema | verificado |
| TEM_TEC_0003 | tecnologia/evolucion_industria_software.md | Evolución de la industria del software uruguaya (1988-presente) | Tema | verificado |
| TEM_TEC_0004 | tecnologia/ecosistema_startups.md | Ecosistema de startups y capital emprendedor en Uruguay | Tema | verificado |
| TEM_TEC_0005 | tecnologia/exportacion_software.md | Exportación de software y servicios tecnológicos de Uruguay | Tema | verificado |
| TEM_TEC_0006 | tecnologia/gobierno_digital.md | Gobierno digital en Uruguay — transformación del Estado | Tema | verificado |
| TEM_TEC_0007 | tecnologia/inteligencia_artificial_uruguay.md | Inteligencia Artificial en Uruguay — estrategia, aplicaciones y ética | Tema | verificado_con_reservas |
| TEM_TEC_0008 | tecnologia/formacion_tecnologica.md | Formación tecnológica en Uruguay — universidades, carreras y bootcamps | Tema | verificado |
| TEM_TEC_0009 | tecnologia/marco_legal_incentivos_software.md | Marco legal e incentivos fiscales para el software en Uruguay | Tema | verificado |
| TEM_TEC_0010 | tecnologia/ciberseguridad_uruguay.md | Ciberseguridad en Uruguay — CERTuy y política de seguridad digital | Tema | verificado_con_reservas |
| TEM_TEC_0011 | tecnologia/investigacion_innovacion_tech.md | Investigación e innovación tecnológica en Uruguay | Tema | verificado_con_reservas |
| TEM_TEC_0012 | tecnologia/tecnologias_emergentes.md | Tecnologías emergentes en Uruguay — blockchain, IoT, cloud y más | Tema | verificado_con_reservas |

#### Empresas (tipo: Empresa / prefijo EMP)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| EMP_TEC_0001 | tecnologia/empresas/genexus_artech.md | Artech / GeneXus | Empresa | verificado |
| EMP_TEC_0002 | tecnologia/empresas/dlocal.md | dLocal | Empresa | verificado |
| EMP_TEC_0003 | tecnologia/empresas/pedidosya.md | PedidosYa | Empresa | verificado_con_reservas |
| EMP_TEC_0004 | tecnologia/empresas/bantotal.md | Bantotal | Empresa | verificado_con_reservas |
| EMP_TEC_0005 | tecnologia/empresas/quanam.md | Quanam | Empresa | verificado_con_reservas |
| EMP_TEC_0006 | tecnologia/empresas/tryolabs.md | Tryolabs | Empresa | verificado |
| EMP_TEC_0007 | tecnologia/empresas/infocorp.md | Infocorp | Empresa | verificado_con_reservas |
| EMP_TEC_0008 | tecnologia/empresas/pyxis.md | Pyxis | Empresa | verificado_con_reservas |
| EMP_TEC_0009 | tecnologia/empresas/abstracta.md | Abstracta | Empresa | verificado |
| EMP_TEC_0010 | tecnologia/empresas/arkano_software.md | Arkano Software | Empresa | verificado_con_reservas |
| EMP_TEC_0011 | tecnologia/empresas/netlabs.md | Netlabs | Empresa | verificado_con_reservas |
| EMP_TEC_0012 | tecnologia/empresas/scanntech.md | Scanntech | Empresa | verificado_con_reservas |

#### Instituciones TEC

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| INS_TEC_0001 | tecnologia/instituciones/agesic.md | AGESIC — Agencia de Gobierno Electrónico | Institución | verificado |
| INS_TEC_0002 | tecnologia/instituciones/anii.md | ANII — Agencia Nacional de Investigación e Innovación | Institución | verificado |
| INS_TEC_0003 | tecnologia/instituciones/cuti.md | CUTI — Cámara Uruguaya de Tecnologías de la Información | Institución | verificado |
| INS_TEC_0004 | tecnologia/instituciones/miem.md | MIEM — Ministerio de Industria, Energía y Minería (perspectiva TEC) | Institución | verificado |
| INS_TEC_0005 | tecnologia/instituciones/latu.md | LATU — Laboratorio Tecnológico del Uruguay | Institución | verificado |
| INS_TEC_0006 | tecnologia/instituciones/plan_ceibal_tecnologia.md | Plan Ceibal — perspectiva tecnológica e innovación | Institución | verificado |

#### Personas TEC

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| PER_TEC_0001 | tecnologia/personas/nicolas_jodal.md | Nicolás Jodal | Persona | verificado |
| PER_TEC_0002 | tecnologia/personas/sebastian_kanovich.md | Sebastián Kanovich | Persona | verificado_con_reservas |

#### Conceptos TEC (tipo: Concepto / prefijo CON)

| ID | Archivo | Título | Tipo | Estado |
|----|---------|--------|------|--------|
| CON_TEC_0001 | tecnologia/software_saas_uruguay.md | Software y SaaS en el contexto uruguayo | Concepto | verificado |
| CON_TEC_0002 | tecnologia/transformacion_digital_concepto.md | Transformación digital en el contexto uruguayo | Concepto | verificado |
| CON_TEC_0003 | tecnologia/ia_concepto.md | Inteligencia Artificial — definición y contexto uruguayo | Concepto | verificado_con_reservas |
| CON_TEC_0004 | tecnologia/gobierno_electronico_concepto.md | Gobierno electrónico — concepto y dimensiones en Uruguay | Concepto | verificado |

---

## Plantillas disponibles

| Archivo | Tipo de documento |
|---------|------------------|
| templates/template_persona.md | Persona |
| templates/template_tema.md | Tema |
| templates/template_movimiento.md | Movimiento |
| templates/template_institucion.md | Institución |
| templates/template_lugar.md | Lugar |
| templates/template_evento.md | Evento |
| templates/template_obra.md | Obra |
| templates/template_normativa.md | Normativa |

---

## Documentos con verificación pendiente

| ID | Archivo | Campo a verificar |
|----|---------|------------------|
| PER_HIS_0004 | cultura/historia/rivera.md | lugar_nacimiento (Yapeyú vs Durazno — debate historiográfico) |
| PER_POL_0002 | cultura/politica/jose_mujica.md | fecha_fallecimiento (13/05/2024 — posterior al período de entrenamiento) |
| TEM_IDN_0006 | cultura/identidad/pueblo_charrua.md | significado de "Guyunusa" en lengua charrúa |
| PER_EDU_0003 | cultura/educacion/reina_reyes.md | fechas exactas de nacimiento y fallecimiento |
| PER_EDU_0004 | cultura/educacion/jesualdo_sosa.md | fecha y lugar exactos de fallecimiento |
| PER_EDU_0006 | cultura/educacion/miguel_soler_roca.md | fecha y lugar de fallecimiento (2016, Ginebra) |
| TEM_ECO_0012 | economia/pesca.md | cifras exactas de producción y exportaciones pesqueras (verificar con DINARA) |

---

## Documentos adicionales sugeridos (backlog)

### Música (personas)
- Eduardo Mateo (PER_MUS_0002)
- Rubén Rada (PER_MUS_0003)
- Alfredo Zitarrosa (PER_MUS_0004)
- Daniel Viglietti (PER_MUS_0005)
- Los Olimareños (PER_MUS_0006)
- Jorge Drexler (PER_MUS_0007)
- Hugo Fattoruso (PER_MUS_0008)

### Literatura (personas)
- Carlos Real de Azúa
- Emir Rodríguez Monegal
- Amanda Berenguer
- Circe Maia

### Historia (temas)
- La Guerra Grande (1839-1851)
- La crisis de 2002
- El movimiento sindical uruguayo

### Deportes (personas/temas)
- Óscar Tabárez (PER_DEP_0007)
- El rugby uruguayo (Los Teros)

### Educación (personas adicionales)
- Francisco Bauzá
- Alfredo Traversoni

### Instituciones pendientes
- Biblioteca Nacional del Uruguay
- Academia Nacional de Letras del Uruguay
- Museo Nacional de Artes Visuales (MNAV)
- INAU (Instituto del Niño y Adolescente del Uruguay)

---

## Dominios Standalone

Los dominios standalone son bases de conocimiento temáticas integradas bajo `knowledge/` junto al árbol principal BCN-UY. No usan YAML frontmatter ni el sistema de IDs `TIPO_AREA_NNNN`. Cada archivo es autocontenido, optimizado para RAG con BM25 + embeddings, y termina con una sección `## Palabras clave`. Los datos inciertos se marcan con `[VERIFICAR]`.

### basquet-uy (Básquetbol Uruguayo)

**Directorio:** `knowledge/basquet-uy/`
**Total archivos:** 22 (README + 21 documentos)
**Última actualización:** 2026-07-22

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio e índice |
| `01-historia-del-basquet-uruguayo.md` | Historia desde YMCA c.1912 hasta el presente |
| `02-federacion-uruguaya-de-basketball.md` | FUBB: estructura, competencias, afiliaciones |
| `03-seleccion-uruguaya.md` | Selección mayor masculina, participaciones internacionales |
| `04-conquistas-internacionales.md` | Medalla bronce Helsinki 1952, Sudamericanos, Panamericanos |
| `05-jugadores-historicos.md` | Fichas de jugadores históricos; Esteban Batista (NBA) |
| `06-entrenadores-destacados.md` | Entrenadores, certificaciones FIBA |
| `07-dirigentes-historicos.md` | Presidentes FUBB, árbitros, categorías FIBA |
| `08-clubes-historicos.md` | Goes, Trouville, Hebraica y Macabi, Malvín, Aguada, Cordón, Nacional |
| `09-liga-uruguaya.md` | Liga Uruguaya de Básquetbol: formato, historia, campeones |
| `10-campeonato-federal.md` | Campeonato Federal para el interior del país |
| `11-gimnasios-historicos.md` | Antel Arena, gimnasios de clubes, estándares FIBA |
| `12-clasicos.md` | Rivalidades históricas entre clubes |
| `13-basquet-femenino.md` | Liga Femenina, selección femenina, CONBASUR |
| `14-formativas.md` | Básquetbol juvenil, categorías, desarrollo |
| `15-uruguayos-en-el-exterior.md` | Esteban Batista NBA, ligas europeas, NBB Argentina, NCAA |
| `16-estadisticas-historicas.md` | Tablas estadísticas (con [VERIFICAR]) |
| `17-linea-de-tiempo.md` | Cronología desde 1891 hasta los 2020s |
| `18-glosario.md` | Posiciones, acciones, conceptos tácticos, reglas FIBA |
| `19-anecdotas-historicas.md` | Helsinki 1952, era dorada, impacto NBA en Uruguay |
| `20-bibliografia.md` | FUBB, FIBA, CONBASUR, COI, COU, prensa uruguaya |
| `21-faq.md` | 20+ preguntas frecuentes sobre básquetbol uruguayo |

---

### arquitectura-uy (Arquitectura Uruguaya)

**Directorio:** `knowledge/arquitectura-uy/`
**Total archivos:** 22 (README + 21 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio e índice completo |
| `01-historia-de-la-arquitectura-uruguaya.md` | Panorama histórico: 7 períodos desde lo colonial hasta el presente |
| `02-herencia-colonial.md` | Colonia del Sacramento (Portugal 1680), Montevideo (España 1724), materiales coloniales |
| `03-arquitectura-republicana.md` | Siglo XIX, neoclasicismo, Carlo Zucchi, Teatro Solís |
| `04-facultad-de-arquitectura.md` | FADU UdelaR: historia, carreras, influencia en la arquitectura nacional |
| `05-arquitectos-destacados.md` | Fichas: Vilamajó, Dieste, Fresnedo Siri, Scasso, Cravotto, Surraco, Sichero, Payssé Reyes, Aroztegui, Serralta, García Pardo, Viñoly |
| `06-obras-emblematicas.md` | Palacio Salvo, Legislativo, Centenario, FADU, Clínicas, Cristo Obrero, Mercado Puerto, Teatro Solís, Palacio Taranco, Castillo Pittamiglio, Aeropuerto Carrasco |
| `07-patrimonio-arquitectonico.md` | MHN, UNESCO, Ley 14.040, Comisión del Patrimonio, sitios declarados |
| `08-monumentos-historicos.md` | Lista de MHN; proceso de declaración; patrimonio en riesgo |
| `09-urbanismo.md` | Urbanismo uruguayo: cuadrícula colonial, Rambla, Cravotto, Ley 18.308 |
| `10-estilos-arquitectonicos.md` | Colonial, Neoclásico, Eclecticismo, Art Déco, Racionalismo, Cerámica Armada, Brutalismo, Contemporáneo |
| `11-materiales-y-tecnicas.md` | Adobe, ladrillo cocido, piedra, cal, hormigón armado, cerámica armada |
| `12-arquitectura-religiosa.md` | Catedral Metropolitana, Iglesia Cristo Obrero, capillas rurales, templos no católicos |
| `13-arquitectura-industrial.md` | Frigorífico Anglo Fray Bentos (UNESCO 2015), ferrocarril, puerto, Dieste industrial |
| `14-arquitectura-rural.md` | Estancias, ranchos, galpones, capillas rurales, colonias de inmigrantes |
| `15-arquitectura-moderna.md` | Movimiento Moderno en Uruguay 1930–1970: Vilamajó, Fresnedo Siri, Hospital Clínicas |
| `16-arquitectura-contemporanea.md` | Arquitectura uruguaya 1970–presente: dictadura, retorno democrático, Viñoly, sustentabilidad |
| `17-restauracion-y-conservacion.md` | Teatro Solís (restauración 2004), Colonia Sacramento, Ley 14.040, criterios Carta de Venecia |
| `18-linea-de-tiempo.md` | Cronología 1680–2023: Colonia, Montevideo, Teatro Solís, Dieste, Viñoly |
| `19-glosario.md` | Términos arquitectónicos y urbanísticos (A–Z) |
| `20-bibliografia.md` | CPCN, FADU, SAU, AGN, Biblioteca Nacional, UNESCO, Archdaily |
| `21-faq.md` | 20+ preguntas frecuentes sobre arquitectura uruguaya |

---

### ciencias-uy (Ciencia en Uruguay)

**Directorio:** `knowledge/ciencias-uy/`
**Total archivos:** 27 (README + 26 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio e índice de los 26 archivos |
| `01-historia-de-la-ciencia-en-uruguay.md` | Naturalistas (Azara, Bonpland, Darwin), UdelaR 1849, Clemente Estable 1927, dictadura, PEDECIBA 1986, Facultad de Ciencias 1990, ANII 2005 |
| `02-facultad-de-ciencias.md` | Historia: Humanidades y Ciencias 1945, intervención 1973, Facultad de Ciencias 1990, campus Iguá 4225, carreras, posgrados, PEDECIBA |
| `03-desarrollo-cientifico.md` | SNI (niveles, estadísticas), instrumentos ANII, evolución de la producción, fortalezas y desafíos del sistema |
| `04-principales-instituciones.md` | PEDECIBA, IIBCE (Clemente Estable 1927), Institut Pasteur Montevideo (2006), INIA (1989), LATU (1965), ANII (2005), MNHN (1837) |
| `05-centros-de-investigacion.md` | CURE, Centro Ceibal, CIN, IMERL, INCO, IIE, DINARA, SOHMA, Observatorio Los Molinos, INUMET |
| `06-cientificos-destacados.md` | Fichas: Clemente Estable, José Luis Massera, Rafael Radi, Gonzalo Moratorio, Henry Engler, Rodolfo Tálice, Ricardo Ehrlich, Ida Holz, Roberto Markarian |
| `07-mujeres-en-la-ciencia.md` | Paulina Luisi (primera médica 1909), María Viñas, Ida Holz, brecha de género en SNI por nivel y disciplina, políticas de género UdelaR y ANII |
| `08-inventos-uruguayos.md` | Test COVID-19 (Moratorio 2020), PIB Alzheimer (Engler), SNIG trazabilidad bovina (2004), Plan Ceibal (2007, primer país), gestión red eléctrica, patentes (DNPI) |
| `09-innovacion-y-tecnologia.md` | AGESIC, sector software (CUTI, exportaciones), biotecnología, energías renovables (>90%), Zonamerica, PCTP Pando, UTEC (2012), spin-offs |
| `10-participacion-internacional.md` | CERN (ATLAS/CMS, Higgs 2012), UNESCO, Antártica, CLACSO, REDALYC/SciELO, bilaterales (Argentina, Brasil, Francia, España) |
| `11-programa-antartico-uruguayo.md` | Base Artigas (22/12/1984, isla Rey Jorge), PAU, IAU (MRE), Parte Consultiva 1985, áreas de investigación, RCTA/SCAR/COMNAP |
| `12-ciencias-naturales.md` | Azara, Darwin (Beagle 1832–1833), MNHN 1837, fauna, botánica (2.500 sp.), geología (Escudo Uruguayo, ágatas Artigas), oceanografía |
| `13-biologia.md` | Historia (Estable 1927, PEDECIBA 1986, Facultad Ciencias 1990), subdisciplinas, biología molecular, genómica, neurobiología (IIBCE), estrés oxidativo (Radi), enfermedades negleccionadas (Chagas), biotecnología |
| `14-medicina.md` | Facultad Medicina (1876), Paulina Luisi 1909, Hospital Clínicas (Surraco), oncología, cardiología, neurología (Engler), COVID (Moratorio), salud mental (Ley 19.529/2017), SNIS (Ley 18.211/2007), tabaco (primer país 2006) |
| `15-quimica.md` | Facultad Química (1929), PEDECIBA-Química, carreras (Química, Ing. Química, Farmacia, Bioquímica, Tecnología Alimentos), investigación (orgánica, analítica, bioquímica/Radi), PCTP Pando, ANCAP, industria |
| `16-fisica.md` | PEDECIBA-Física (1986), Instituto de Física, áreas (teórica, materia condensada, partículas, astrofísica), CERN (ATLAS/CMS/Higgs 2012), CIN, física aplicada |
| `17-matematica.md` | Rafael Laguardia (1906–1980), José Luis Massera (Teorema Massera 1949, preso 1975–1984), PEDECIBA-Matemática, IMERL, Centro Matemática (Fcien), sistemas dinámicos, probabilidad, Olimpíada Matemática, Roberto Markarian |
| `18-astronomia.md` | Observatorio Los Molinos (Canelones), Departamento Astronomía (Facultad Ciencias), Licenciatura en Astronomía, astrofísica, mecánica celeste, cosmología, IAU, cielo austral |
| `19-ciencias-ambientales.md` | MVOTMA/DINAMA, DINARA, INIA, SOHMA, INUMET, CURE, ecología praderas, calidad agua (cianobacterias), cambio climático, biodiversidad marina, SNAP, desafíos ambientales |
| `20-paleontologia.md` | Megafauna pleistocena (gliptodontes, toxodontes, mastodontes, Megatherium, Smilodon), Darwin y Toxodon platensis, MNHN (1837), formaciones geológicas (Dolores, Libertad, Fray Bentos, Asencio), hallazgos de dinosaurios |
| `21-inteligencia-artificial.md` | Historia computación: Ida Holz, internet 1991, PEDECIBA-Informática 1986, INCO (FING), Plan Ceibal (2007, primer país OLPC), Centro Ceibal, industria software (CUTI, exportaciones ~1.000M USD), AGESIC, estrategia nacional IA |
| `22-premios-y-reconocimientos.md` | Rafael Radi (NAS, TWAS), Moratorio (TWAS), Massera (solidaridad internacional), Premio Nacional de Ciencias (MEC), SNI (ANII), L'Oréal-UNESCO, Ida Holz (ISOC), Academia Nacional de Ciencias Uruguay, Plan Ceibal (UNESCO), tabaco (OMS) |
| `23-linea-de-tiempo.md` | Cronología 1832–2026: Darwin, MNHN 1837, UdelaR 1849, Estable 1927, Massera 1949, dictadura 1973, PEDECIBA 1986, Facultad Ciencias 1990, internet 1991, SNIG 2004, ANII 2005, Institut Pasteur 2006, tabaco 2006, Ceibal 2007, bosón Higgs 2012, renovables 2015, COVID test 2020 |
| `24-glosario.md` | A–U: AGESIC, ANII, Antártica/BCAA, astrofísica, bioquímica, bosón de Higgs, CERN, CIN, CURE, DINAMA, DINARA, estrés oxidativo, Facultad de Ciencias, IIBCE, IMERL, INCO, INIA, Institut Pasteur, LATU, LHC, Massera Teorema, MNHN, OLPC, PAU, PEDECIBA, peroxinitrito, PIB (Alzheimer), Plan Ceibal, RAG, SECIU, SNI, SNIS, SNAP, SNIG, SOHMA, Toxodon, TWAS, UdelaR, UTEC |
| `25-bibliografia.md` | UdelaR/PEDECIBA/ANII/IIBCE/Institut Pasteur/INIA/LATU/Ceibal/AGESIC/MVOTMA/INUMET/MNHN/PAU; COLIBRÍ, SciELO, REDALYC; publicaciones clave (Massera 1949, Radi PubMed, Fariña et al. Megafauna 2013, Darwin Beagle); fuentes para ítems [VERIFICAR] |
| `26-faq.md` | 20+ preguntas: cuándo comenzó la investigación, impacto dictadura, qué es PEDECIBA, UdelaR, Institut Pasteur, ANII, IIBCE, quiénes son Estable/Massera/Radi/Moratorio/Luisi/Holz, inventos uruguayos, Plan Ceibal, fósiles, programa antártico, CERN, financiamiento, SNI |

---

### naturaleza-uy (Naturaleza del Uruguay)

**Directorio:** `knowledge/naturaleza-uy/`
**Total archivos:** 30 (README + 29 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, índice de los 29 archivos, normas editoriales |
| `01-historia-natural-del-uruguay.md` | Félix de Azara, Aimé Bonpland, Darwin (Beagle 1832–33), MNHN 1837, Arechavaleta *Flora Uruguaya*, Carlos Berg, Clemente Estable/IIBCE (1927), Facultad de Ciencias (1990), cronología 1516–2010 |
| `02-biodiversidad.md` | Cifras (~2800–3000 plantas vasculares, ~460–480 aves, ~110–120 mamíferos, ~65–70 reptiles, ~45–50 anfibios), posición biogeográfica, endemismo, palma butiá (*Butia odorata*), amenazas, Estrategia Nacional Biodiversidad |
| `03-biomas.md` | Pastizales del Río de la Plata (NT0710 WWF, ~70–80% Uruguay), Mata Atlántica norte y noreste (~5%), Monte Espinoso/Espinal (~10%), tabla comparativa de biomas, Alianza del Pastizal |
| `04-ecorregiones.md` | WWF NT0710 Pastizales Húmedos Uruguay (Critically Endangered), Bosques Inundables Río Uruguay, Bosques Atlánticos Alto Paraná NT0102, Pastizales del Este; TNC: cuchillas como ecotonos internos |
| `05-flora-nativa.md` | Fichas: Ceibo (*Erythrina crista-galli*, flor nacional), Tala, Coronilla, Espinillo, Sauce criollo, Algarrobo (NT), Ombú, Palma Butiá (VU, palmares Rocha más extensos del mundo); gramíneas nativas; flora de humedales; medicinales |
| `06-fauna-nativa.md` | Panorama tabular por grupo, fauna amenazada (venado NT, franciscana VU, águila coronada EN, lobo de crin NT, tortuga boba VU), Isla de Lobos como hábitat global importante, zoogeografía neotropical |
| `07-aves.md` | 460–480 spp.; tablas: aves de pradera (ñandú Rhea americana NT, hornero), acuáticas (cisne cuello negro, chajá, espátula rosada), rapaces (águila coronada EN), costeras/marinas (pingüino Magallanes NT); migratorias boreales y australes; sitios de avistamiento |
| `08-mamiferos.md` | Fichas: Carpincho, Coipú, Venado de campo (NT), Ciervo de los pantanos (VU), Lobito de río (NT), Gato montés, Zorro gris, Aguará guazú (NT); mamíferos marinos: Lobo marino un pelo, Franciscana (VU), Ballena franca austral; quirópteros |
| `09-reptiles.md` | Lagarto overo, lagartijas, gecko; serpientes: Bothrops alternatus (víbora de la cruz, más peligrosa Uruguay), Crotalus durissus terrificus; tortugas marinas: Caretta caretta VU, Chelonia mydas EN, Dermochelys coriacea VU; dulceacuícolas; yacaré norte |
| `10-anfibios.md` | Anuros: Boana pulchella, Rhinella arenarum, Leptodactylus latrans, Physalaemus, Elachistocleis; Gymnophiona: Chthonerpeton indistinctum (única cecilia Uruguay); amenazas: chytridiomicosis, rana toro invasora |
| `11-peces.md` | Fichas: Dorado (NT), Surubí (VU), Pejerrey, Boga, Tararira, Bagre amarillo; Sistema Plata vs. Vertiente Atlántica; marinos: Corvina blanca, Merluza, Cazón VU, Gatuzo VU; DINARA |
| `12-invertebrados.md` | Mariposas (monarca, Vanessa, Caligo); escarabajos, luciérnagas; hormigas cortadoras; libélulas (bioindicadores); arañas: Loxosceles laeta (peligrosa, loxoscelismo), Latrodectus; mejillón dorado invasor; moluscos; crustáceos |
| `13-polinizadores.md` | Abejas nativas Meliponini (Plebeia, Tetragonisca, Schwarziana); Apis mellifera (apicultura, exportación a UE); picaflores; mariposas; moscas (SYRPHIDAE); amenazas (neonicotinoides, Varroa, Vespula germanica invasora) |
| `14-ecosistemas.md` | Pradera natural (60–70%), monte nativo, bosque ribereño, quebrada, palmar butiá, humedales (5–7%, Ramsar), ríos, costas; tabla servicios ecosistémicos |
| `15-bosques-y-montes.md` | Monte ribereño (sauce, sarandí, ceibo); monte serrano (Quebrada de los Cuervos, Valle del Lunarejo); monte costero (tala/coronilla); palmar butiá (VU, mayor concentración mundial); tabla 13 sp. arbóreas nativas; Ley 15.939/1987 |
| `16-humedales.md` | Sitios Ramsar (Bañados del Este 1984 ~250.000 ha; Esteros de Farrapos 2004 ~15.000 ha); flora y fauna de humedales; amenazas; otros humedales (Merín, Castillos, Santa Lucía, Garzón); funciones ecológicas |
| `17-rios-lagunas-y-arroyos.md` | Sistema Plata vs. Vertiente Atlántica; Río Uruguay, Río Negro (3 embalses), Río Santa Lucía (Montevideo/cianobacterias), Río Cuareim; lagunas: Merín, del Sauce, Castillos, Negra; Acuífero Guaraní; gestión DINAGUA/OSE |
| `18-costa-atlantica-y-rio-de-la-plata.md` | 660 km costa; estuario Plata (~320 km); Isla de Flores (SNAP); costa atlántica ~200 km (playas, dunas Cabo Polonio, costas rocosas, Isla de Lobos); pingüino Magallanes NT; ballena franca austral; amenazas costeras |
| `19-areas-protegidas.md` | SNAP (Ley 17.234/2000, DINABISE); fichas: Cabo Polonio, Laguna de Rocha, Esteros de Farrapos, Valle del Lunarejo, Quebrada de los Cuervos, Santa Teresa, Laguna Garzón, Isla de Flores, Isla de Lobos, Laguna Negra; resumen SNAP (~2–3% territorio) |
| `20-geologia.md` | Escudo Cristalino Uruguayo (2.000+ Ma; Complejo Granito-Gnéisico, Cinturón Dom Feliciano); Cuenca Norte (Fm. Tacuarembó, dinosaurios; basaltos Arapey/Serra Geral 135–132 Ma); Cuaternario litoral; geomorfología (Cerro Catedral 514 m); ágatas y amatistas Artigas; granito; paleontología |
| `21-recursos-naturales.md` | Agua (Art. 47 Constitución 2004, OSE, cianobacterias); suelos (brunizems, vertisoles, planosoles; erosión); pesca artesanal e industrial (DINARA); recursos forestales (Ley 15.939; eucalipto/pino; UPM); renovables (>90% electricidad; Salto Grande 3840 MW); minerales |
| `22-especies-amenazadas.md` | Tabla UICN (LC→EX); mamíferos (franciscana VU, venado NT, ciervo pantanos VU, aguará guazú NT); aves (águila coronada EN, loica pampeana EN, ñandú NT); reptiles (tortugas marinas VU/EN); peces (surubí VU, cazón VU); flora (butiá VU); extintas localmente (puma, tapir); causas de amenaza |
| `23-especies-invasoras.md` | Plantas: acacia negra, ligustro (alto impacto), gleditsia, camalote; animales acuáticos: mejillón dorado (*Limnoperna fortunei*, tapona cañerías), rana toro, carpa; terrestres: liebre europea, avispa chaqueta amarilla (*Vespula germanica*); vías de introducción; marco legal |
| `24-conservacion-ambiental.md` | Marco legal (Ley 15.939, Ley 17.234, Art. 47 Const., Ley 18.308); instituciones (MA, DINABISE, DINARA, MGAP-RENARE); SNAP; Ramsar; compromisos internacionales (CDB, CITES, Kunming-Montreal 30×30); restauración ecológica; Alianza del Pastizal; ONGs (Karumbé, Aves Uruguay, Vida Silvestre) |
| `25-instituciones.md` | Ministerio de Ambiente (DINABISE, DINAGUA, DINA, DNCCC); DINARA; MGAP-RENARE; INIA; INUMET; OSE; IIBCE (1927); Facultad de Ciencias UdelaR (1990); MNHN (1837); PEDECIBA; CURE; ONGs (Karumbé, Aves Uruguay/SUCN, Vida Silvestre, REDES-AT); organismos internacionales (UICN, Ramsar, CDB, GEF) |
| `26-linea-de-tiempo.md` | Cronología 1516–2026: Solís, Azara (1760–1801), Darwin 1832–33, MNHN 1837, Arechavaleta, IIBCE 1927, Ramsar 1984, PEDECIBA 1986, Ley 15.939, Facultad Ciencias 1990, CDB 1993, SNAP Ley 17.234 (2000), Art. 47 (2004), renovables 2015, Ministerio Ambiente 2020, Kunming-Montreal 2022 |
| `27-glosario.md` | A–VU: acuífero, Alianza del Pastizal, anfibio, CDB, cecilia, chytridiomicosis, CITES, ecorregión, endémico, Escudo Cristalino, DINABISE, DINARA, DINAGUA, franciscana, herbario, IIBCE, INIA, INUMET, Karumbé, LC/NT/VU/EN/CR/EX, Ley 15.939, Ley 17.234, MNHN, palmar butiá, pastizal, PEDECIBA, Ramsar, SNAP, servicio ecosistémico, UICN |
| `28-bibliografia.md` | Ministerio de Ambiente (DINABISE, SNAP, DINAGUA); DINARA; INIA; INUMET; OSE; MNHN; Facultad de Ciencias (COLIBRÍ); IIBCE; bases internacionales (IUCN Red List, GBIF, Ramsar, CITES, CDB); publicaciones (Arechavaleta *Flora Uruguaya*, Azara, Darwin *Beagle*, Achaval y Olmos, Arballo y Cravino, Brazeiro *Eco-regiones*, Fariña *Megafauna*); SciELO, REDALYC, iNaturalist |
| `29-faq.md` | 20+ preguntas: cuántas especies de aves/plantas/mamíferos tiene Uruguay, endemismo, animal más peligroso, ecosistema más extenso, bañados, longitud costera, puma extinto, por qué hay lobos marinos, ballenas en Uruguay, pingüinos, serpiente más común, qué es el SNAP, áreas protegidas más famosas, sitios Ramsar, mayor amenaza biodiversidad, acciones de conservación, extintas en Uruguay, cambio climático, agua derecho constitucional, electricidad renovable |

---

### departamentos-uy (Departamentos del Uruguay)

**Directorio:** `knowledge/departamentos-uy/`
**Total archivos:** 21 (README + 20 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, normas editoriales, estructura de cada archivo departamental |
| `00-uruguay-territorial.md` | Organización político-administrativa de Uruguay: 19 departamentos, historia de la división (decreto artiguista 1816, evolución 1816–1901), municipios (Ley 18.567/2009), regiones, Congreso de Intendentes, cronología 1776–2010 |
| `01-artigas.md` | Capital: Artigas (fundada 21/09/1852); creado 1884; frontera con Brasil (Quaraí/RS); Río Cuareim; ágatas y amatistas (principal productor mundial); arroz; Bella Unión (caña de azúcar); Aeropuerto SUAG |
| `02-canelones.md` | Segundo departamento más poblado (~570.000 hab.); rodea Montevideo; horticultura; viticultura (Tannat, Juanicó); Aeropuerto Internacional de Carrasco (MVD); Observatorio Los Molinos; OSE Planta Aguas Corrientes |
| `03-cerro-largo.md` | Capital Melo (fundada 1795); NE limítrofe con Brasil (Melo-Aceguá); Laguna Merín binacional; Cuchilla Grande; Cerro Largo FC; CUM (UdelaR); arroz (cuenca Tacuarí) |
| `04-colonia.md` | Colonia del Sacramento (UNESCO 1995, Barrio Histórico); fundada 20/01/1680 por Portugal; valdenses 1856; Nueva Helvecia (suizo-alemana 1862); ferrys a Buenos Aires; Portón de Campo, Faro, Cabildo |
| `05-durazno.md` | Centro geográfico de Uruguay; Represa Rincón del Bonete (1945, primera gran represa); Baygorria (1960); Palmar (1982); Festival de Folclore de Durazno; Río Negro; Río Yi |
| `06-flores.md` | Departamento más nuevo (creado 16/10/1901); segundo más pequeño; capital Trinidad (fundada 1805); nombre: Gral. Venancio Flores; ~25.050 hab. (menos poblado); Río Yi; Río Negro norte |
| `07-florida.md` | Declaración de Independencia de Uruguay (25/08/1825, Sala de Representantes); capital fundada 24/06/1809; creado 03/07/1837; Río Santa Lucía nace aquí; Casa de la Independencia museo |
| `08-lavalleja.md` | Antes "Minas"; renombrado Lavalleja 1927; capital Minas (21/10/1783); Juan Antonio Lavalleja (33 Orientales, 19/04/1825); Cerro Catedral (~514 m, punto más alto Uruguay); Peregrinación al Verdún; canteras de granito; agua Nativa |
| `09-maldonado.md` | Capital fundada 04/10/1755; Punta del Este (turismo internacional); Isla de Lobos (SNAP, ~200.000 lobos marinos); Casapueblo (Carlos Páez Vilaró); "Mano en la arena" (Irarrázabal 1982); Aeropuerto PDP; CURE (UdelaR); Laguna del Sauce (agua potable) |
| `10-montevideo.md` | Capital y único departamento-ciudad; ~530 km² (más pequeño); ~1.350.000 hab. (~40% nacional); ~65-70% PIB nacional; Rambla 22 km; Estadio Centenario (Mundial 1930); Candombe UNESCO 2009; Carnaval más largo del mundo; Peñarol, Nacional; Teatro Solís; Palacio Salvo; UdelaR; Puerto |
| `11-paysandu.md` | Capital Paysandú; ~13.922 km²; frontera Argentina (Colón/Entre Ríos); Puente Internacional Paysandú-Colón; Sitio de Paysandú (1864–65, Leandro Gómez); citricultura; Hospital Escuela del Litoral; CeRP del Litoral; Termas del Guaviyú; Julio Sosa ("el Varón del Tango") |
| `12-rio-negro.md` | Capital Fray Bentos; Frigorífico Anglo (Patrimonio Industrial UNESCO 2015); Planta UPM (ex Botnia, controversia Argentina–Uruguay 2003–2010, fallo CIJ 2010); Puente Gral. San Martín (Fray Bentos–Puerto Unzué); Represa de Palmar (1982); Esteros de Farrapos (Ramsar 2004, SNAP); colonia San Javier (inmigrantes rusos, 1913) |
| `13-rivera.md` | Capital Rivera; frontera con Brasil (conurbación binacional Rivera–Santana do Livramento); Plaza Internacional sin barreras físicas; Portuñol/DPU; Zona Franca de Rivera; Fructuoso Rivera (primer presidente Uruguay); Minas de Corrales (oro); forestación |
| `14-rocha.md` | Capital Rocha; costa atlántica más extensa y menos urbanizada (~170–200 km); Bañados del Este (Ramsar 1984, primer sitio Ramsar Uruguay); Cabo Polonio (SNAP, dunas, lobos marinos, faro, aldea sin red eléctrica); Palmar de Butiá (*Butia odorata* VU, mayor concentración mundial); Laguna de Rocha (SNAP); Punta del Diablo; Fortaleza de San Miguel (1734); CURE (UdelaR) |
| `15-salto.md` | Capital Salto (segunda ciudad interior); Represa de Salto Grande (CTM binacional Uruguay–Argentina, ~1.890 MW, 1979–1981); Embalse de Salto Grande (~783 km²); Termas del Daymán (mayor complejo termal Uruguay, Acuífero Guaraní); citricultura; Puente Internacional Salto–Concordia; Luis Suárez (24/01/1987, máximo goleador selección uruguaya) |
| `16-san-jose.md` | Capital San José de Mayo (fundada 19/03/1783 por Joaquín del Pino); frontera sur (Río de la Plata); Río Santa Lucía (abastece >60% población uruguaya); cuenca lechera sur (CONAPROLE); horticultura periurbana; Ciudad del Plata (expansión metropolitana); balnearios Kiyú, Playa Pascual |
| `17-soriano.md` | Capital Mercedes; Playa de la Agraciada: desembarco de los **33 Orientales** (19/04/1825, Juan Antonio Lavalleja y Manuel Oribe); 19 de abril = Día de los Patriotas Orientales (feriado nacional); rambla sobre el Río Negro; ganadería; lechería; arroz; Nuevo Berlín (colonos alemanes) |
| `18-tacuarembo.md` | Capital Tacuarembó (Villa San Fructuoso); departamento **más extenso de Uruguay** (~15.438 km²); Festival de Folclore de Tacuarembó (mayor festival gaucho, febrero); controversia nacimiento **Carlos Gardel** (Tacuarembó vs. Toulouse, Francia); Valle del Lunarejo (Mata Atlántica de quebrada); forestación eucaliptos; ganadería; Acuífero Guaraní |
| `19-treinta-y-tres.md` | Capital Treinta y Tres (nombre evoca los **33 Orientales**); único departamento con nombre numérico en Uruguay; Río Olimar (gentilicio: olimareño); **principal zona arrocera del Uruguay** (cuenca del Olimar/Laguna Merín); Quebrada de los Cuervos (SNAP, Mata Atlántica de quebrada, tucán *Ramphastos toco*); Bañados del Este (Ramsar 1984); El Olimareño (José Luis Guerra, cantautor) |

---

### pueblos-originarios-uy (Pueblos Originarios de Uruguay)

**Directorio:** `knowledge/pueblos-originarios-uy/`
**Total archivos:** 25 (README + 24 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, normas editoriales (distingue evidencia arqueológica / documentación histórica / hipótesis académicas / debates historiográficos), índice de los 24 archivos, fuentes prioritarias |
| `01-poblamiento-del-territorio.md` | Paleoambiente Uruguay ~12.000–13.000 a.C.; megafauna (mastodontes, gliptodontes, toxodontes, Smilodon, Hippidion); sitio Arroyo del Vizcaíno (Sauce, Canelones; Fariña et al.); período paleoindio (~11.000–10.000 a.C.); puntas "cola de pescado"; Período Arcaico (~9.000–3.000 a.C.; concheros; fauna menor); Período Formativo (cerritos ~4.000–3.000 a.C.) |
| `02-contexto-prehispanico.md` | Panorama prehispánico: tabla de diversidad (6 pueblos, territorios, modos de vida); mapa conceptual distribución territorial; características de los grupos cazadores-recolectores (organización social, economía, tecnología, vivienda); constructores de cerritos como tradición cultural separada; guaraníes como caso diferenciado; relaciones interétnicas (alianzas, conflictos, intercambios); limitaciones metodológicas (fuentes europeas, etnónimos imprecisos) |
| `03-charruas.md` | Ficha comprensiva charrúas: territorio (centro, litoral occidental, sur del Uruguay; N Entre Ríos; S Rio Grande do Sul); organización social (bandas 20–60 personas, familia extensa, parentesco bilateral, cacicazgo situacional); economía (caza: venado, carpincho, ñandú, coipú; pesca; recolección: butiá, miel); vivienda (toldos de ramas y cueros); armas (boleadoras, arco y flecha, lanzas, mazas); vestimenta (cueros, pintura corporal, tatuajes, perforaciones); lengua (aislada, ~100–200 palabras); espiritualidad (animismo, shamanismo, ritos funerarios: destrucción de bienes, amputación de dedos); contacto europeo (muerte Solís 1516, adopción caballo siglo XVII, Salsipuedes 1831, París 1833–34, repatriación Vaimaca Pirú 2002); caciques históricos (Zapicán, Abayubá, Polidoro) |
| `04-chanas.md` | Chanás: territorio (delta del Paraná, litoral bajo del Uruguay, SO del actual Uruguay); vida ribereña semi-sedentaria; economía centrada en pesca; navegantes hábiles con canoas; asentamientos más estables; productores de cerámica; concheros; lengua extinta; relaciones con chaná-timbúes, charrúas, guaraníes; primer contacto europeo (Ulrich Schmidl 1535); mestizaje/asimilación temprana siglos XVII–XVIII |
| `05-guenoas-y-minuanes.md` | Guenoas y Minuanes: debate historiográfico (mismo pueblo vs. grupos distintos pero emparentados; investigación de Eduardo Acosta y Lara); territorio (NE Uruguay, N litoral río Uruguay, S Rio Grande do Sul, NE Argentina); bandas nómadas; fuentes jesuíticas documentales; adopción temprana del caballo (siglo XVII); alianza con charrúas; tensión con guaraníes de las misiones; declive por reducción demográfica, fusión con charrúas y mestizaje |
| `06-yaros.md` | Yaros: NE Uruguay (cuencas Tacuarembó, Cuareim); grupo menos documentado; cazadores-recolectores; conflictos con charrúas; mencionados en Ruy Díaz de Guzmán, documentos jesuíticos, Eduardo Acosta y Lara; desaparición temprana de las fuentes históricas; debate sobre si etnia distinta o subgrupo de charrúas/minuanes |
| `07-bohanes.md` | Bohanes (boanes): centro-norte Uruguay (Río Negro, Río Yi); grupo menos documentado; cazadores-recolectores; organización en bandas inferida; fusión temprana con charrúas y población mestiza en siglo XVIII; ilustra limitaciones del conocimiento sobre grupos menores |
| `08-guaranies-en-uruguay.md` | Guaraníes en Uruguay: presencia prehispánica en NE; familia lingüística tupí-guaraní; semi-sedentarios con agricultura de roza (mandioca, maíz, porotos, zapallo, batata); organización aldeana (tekohá); clanes patrilineales; mburuvichá cacique + payé chamán; cosmovision "tierra sin mal" (Yvy Marã Ei); misiones jesuíticas (Siete Pueblos del Uruguay); organización interna misional (cabildo guaraní, producción colectiva); ataques bandeirantes; consecuencias expulsión jesuitas 1767; legado toponímico guaraní; palabras guaraní en español uruguayo |
| `09-organizacion-social.md` | Organización social comparativa: dos modelos (bandas nómadas vs. sedentarios/semi-sedentarios); composición de la banda (20–100 personas); dinámica de fisión-fusión; cacicazgo situacional (cualidades personales, no hereditario); estructura de liderazgo guaraní (mburuvichá + payé); sistemas de parentesco (bilateral nómadas; patrilineal guaraníes); poliginia (especialmente caciques); roles de género; ancianos como custodios del saber; rituales (grandes encuentros estacionales, ritos funerarios, ritos de guerra); organización territorial (territorios de uso, superposición, basado en recursos, sin propiedad formal); tabla comparativa charrúas/nómadas vs. chanás vs. guaraníes |
| `10-cultura-material.md` | Industria lítica: materias primas (cuarcita abundante, basalto, sílex, cuarzo, arenisca); tipos de instrumentos (puntas de proyectil, raspadores, raederas, perforadores, cuchillos, bolas boleadora, morteros); técnicas de talla (percusión directa, presión, bipolar); boleadoras en detalle (bola perdida, 2 bolas, 3 bolas); cerámica (colombina/mano; cocción a fuego abierto; decoración incisa/plástica; formas globulares/subglobulares; tradición Viñas-Calpica; tradición costera; corrugada/ungulada guaraní); tabla de armas; trabajo en cuero y textil; objetos óseos y en asta; adornos (cuentas, colgantes, pigmentos ocre/carbón, tembetá, plumas); canoas (chanás) |
| `11-vida-cotidiana.md` | Vida cotidiana: tabla dieta cazadores-recolectores (venado, carpincho, ñandú, coipú, peces, moluscos, frutos, miel, raíces); preparación de alimentos (asado, hervido en cuero/cerámica, secado y ahumado); dieta guaraní (mandioca, maíz; chicha, cauín); tabla técnicas de caza (boleadoras, arco/flecha, acorralamiento, emboscada, caza ecuestre desde siglo XVII); impacto adopción caballo; tabla técnicas de pesca (arpón, arco/flecha, redes, trampas, boleadoras de pesca); vivienda (toldo ramas + cueros cosidos, portátil, 5–15 personas); ciclo de movilidad estacional (actividades primavera/verano/otoño/invierno); medicina tradicional (chamanes, medicina vegetal, vulnerabilidad ante epidemias); ritos funerarios (destrucción de bienes, amputación de dedo, inhumación en posición flexionada); grandes encuentros estacionales; ritos de guerra |
| `12-lenguas.md` | Lenguas: tabla panorámica (6 pueblos, lenguas, clasificaciones, estado actual); lengua charrúa (~100–200 palabras conservadas; registrada con 4 sobrevivientes en París 1833; estudiada por Ana Mourelle de Lema, Rodolfo Lenz; no clasificada/aislada); tabla de vocabulario muestra (yaguané, inacán, gualichó, etc.); lengua chaná (fragmentos mínimos); guenoa-minuán (mínimo, posiblemente emparentado con charrúa); guaraní (familia tupí-guaraní; viva en Paraguay; lengua oficial; legado toponímico extenso); tabla de palabras guaraní en español uruguayo (ombú, jaguar, ñandú, carpincho, piraña, maíz, mandioca, tapioca, tucán, coipú, aguará); investigadores (Ana Mourelle de Lema, Rodolfo Lenz, Branislava Susnik, Eduardo Acosta y Lara, Academia Nacional de Letras) |
| `13-arqueologia.md` | Arqueología: historia por períodos (coleccionistas siglo XIX; Figueira principios siglo XX; Vidart mediados siglo XX; 1970–90 introducción C14; 1990–2010 trabajo sistemático de cerritos López Mazz; 2010-presente arqueología interdisciplinaria y de contrato); tabla de investigadores (Figueira, Vidart, Curbelo, López Mazz, Moreno, Fariña, Gianotti, Pi Ugarte); tipos de sitios (sitios de superficie/talleres; concheros; cerritos; enterramientos; arte rupestre); tabla de sitios principales (Arroyo del Vizcaíno, Cerro del Tigre, Los Indios, Las Marías, Paso del Puerto, Cerro Pintado, Punta Ballena); métodos de fechado absoluto (C14, TL/OSL, isótopos estables); museos (MNA, MNHN, Departamental Canelones, Museo del Indio y Gaucho Tacuarembó); tendencias de investigación actuales (ADN antiguo, paleoambiente, isótopos Sr/O, arqueología del paisaje, arqueología comunitaria) |
| `14-cerritos-de-indios.md` | Cerritos: distribución geográfica (este Uruguay: Rocha, Treinta y Tres, Cerro Largo, Lavalleja; norte; cuenca Río Negro; S Brasil; NE Argentina; miles estimados, muchos destruidos); características físicas (dimensiones: pequeños 0,5–1,5 m × 10–30 m a grandes 3–5 m × 80–150 m; composición: capas de tierra/sedimento + restos orgánicos + material arqueológico); cronología (~4.000–3.000 a.C. al siglo XV d.C.); debate funciones (habitación, enterramiento, marcadores territoriales, ritual, gestión del paisaje — multifuncional probable); debate constructores (no identificados definitivamente; probablemente distintos de los charrúas históricos; arqueología contemporánea apunta a tradición cultural diferente; debate no cerrado); organización espacial (complejos de 2–20+ montículos; tamaños jerárquicos; posicionamiento vinculado al agua; estudios espaciales Alicia Gianotti); paleoambiente (tierras bajas, inundación estacional, abundantes recursos de bañado); tabla de hallazgos (líticos, cerámica Viñas-Calpica, restos faunísticos, enterramientos, restos botánicos, ornamentos); investigación actual (ADN antiguo, isótopos estables, LiDAR, arqueología comunitaria); protección legal (Ley 14.040; CPCN; problema persistente de destrucción) |
| `15-contacto-con-los-europeos.md` | Primer contacto 1516 (Juan Díaz de Solís, debate sobre quiénes lo mataron); expediciones europeas (Gaboto 1526–27, García de Moguer 1527, Mendoza 1535); cronistas (Schmidl 1535, Ramírez 1528, Díaz de Guzmán ~1612); introducción de ganado y caballo por Hernandarias 1611 (transformación de la vida indígena); adopción del caballo por charrúas (mediados siglo XVII); epidemias (viruela, sarampión, catástrofe demográfica); alianzas y conflictos según grupo y coyuntura; transformación de la estructura étnica por contacto |
| `16-misiones-y-colonia.md` | Misiones jesuíticas: Siete Pueblos del Uruguay (hoje Rio Grande do Sul); fundación 1624–1706; organización interna (cabildo guaraní, economía colectiva, cultura misional); ataques bandeirantes 1628–1641; Batalla de Mbororé 1641; expulsión jesuitas 1767 (Carlos III); desintegración del sistema misional; dispersión guaraní; encomiendas (limitadas por resistencia charrúa); estancias coloniales y conflicto por el ganado; disputa hispano-portuguesa por la Banda Oriental (Nova Colônia 1680, Montevideo 1724–26, Tratado de Madrid 1750, Guerra Guaranítica 1754–56, Tratado San Ildefonso 1777) |
| `17-salsipuedes.md` | Matanza de Salsipuedes: 11 de abril de 1831; presidente Fructuoso Rivera (ordenó); coronel Bernabé Rivera (ejecutó); trampa en cuchilla de Salsipuedes (Paysandú); segunda acción Queguay 26 mayo 1831 (muerte cacique Polidoro); cuatro charrúas en París 1833–34 (Vaimaca Pirú, Guyunusa, Tacuabé, Senaqué; François de Curel; Jardin des Plantes; Alcide d'Orbigny; vocabulario); muerte de Vaimaca Pirú 14 julio 1833; repatriación 2002; consecuencias (desintegración del grupo charrúa); debates (genocidio vs. etnocidio, motivaciones de Rivera, continuidad charrúa); reconocimiento (Plaza de los Charrúas, monumento Belloni 1938, Ley 2009 Día 11 de abril) |
| `18-descendientes-e-identidad.md` | Mestizaje y invisibilización; narrativa "Uruguay europeo sin indios"; investigaciones genéticas Mónica Sans (UdelaR) — haplogrupos mitocondriales indígenas (A, B, C, D) en 30–40% líneas maternas de la población uruguaya, especialmente interior (Rivera, Tacuarembó, Artigas); organizaciones de descendientes (CONACHA, ADENCH, Basquadé Inchalá); reivindicaciones (reconocimiento legal, patrimonio, educación intercultural, reconocimiento Salsipuedes como genocidio/etnocidio); marco legal (Convenio 169 OIT no ratificado; Declaración ONU 2007 — Uruguay votó a favor; Ley 11 de abril 2009; Censo 2011 pregunta ascendencia); debate continuidad vs. reinvención identitaria; herencia guaraní en frontera con Brasil |
| `19-patrimonio-indigena.md` | Ley 14.040/1971 (patrimonio histórico y arqueológico); CPCN (Comisión del Patrimonio Cultural de la Nación); museos: MNA, MNHN, Museo del Indio y Gaucho (Tacuarembó), museos departamentales; sitios arqueológicos principales (cerritos Laguna Merín, Arroyo del Vizcaíno, arte rupestre Chamangá/Flores); colecciones en el exterior (Musée de l'Homme, París); patrimonio inmaterial (toponimia, vocabulario, prácticas rurales); amenazas (agricultura intensiva, forestación, infraestructura, huaquería); investigadores y gestión del patrimonio (Departamento de Arqueología FHCE-UdelaR: López Mazz, Curbelo, Gianotti; CPCN; museos nacionales) |
| `20-toponimia-indigena.md` | Lenguas fuente de la toponimia (guaraní dominante, charrúa marginal, chaná escaso, español colonial); tabla de departamentos con origen indígena (Tacuarembó, Paysandú); tabla de ríos y arroyos (Uruguay, Cuareim, Yí, Queguay, Arapey, Yaguarón, Dacyman, Cebollatí, Tacuarí, Olimar, Arapey); localidades guaraníes; etimología de "Uruguay" (urú-guay: río de los pájaros/urutaú; otras interpretaciones); vocabulario guaraní en español uruguayo (ombú, ñandú, carpincho, coipú, piranha, jaguar, tapir, tucán, mandioca, tapioca, maraca, chicha, yerba mate); investigadores (Mourelle de Lema, Academia Nacional de Letras, Pi Ugarte, Acosta y Lara) |
| `21-linea-de-tiempo.md` | Cronología pueblos originarios Uruguay ~13.000 a.C. – 2026: período paleoindio; cerritos (~4.000 a.C.); expansión guaraní; muerte Solís 1516; expediciones europeas; Hernandarias ganado 1611; adopción caballo charrúas siglo XVII; misiones 1624–1706; bandeirantes; Mbororé 1641; expulsión jesuitas 1767; guerras de independencia y charrúas; Salsipuedes 11 abril 1831; Queguay mayo 1831; cuatro charrúas París 1833; muerte Vaimaca Pirú 14 julio 1833; monumento Belloni 1938; investigaciones Vidart, López Mazz; organizaciones de descendientes 1990s; genética Sans 1990s; repatriación Vaimaca Pirú 2002; Declaración ONU 2007; Ley 11 de abril 2009; Censo 2011 |
| `22-glosario.md` | Términos arqueológicos, antropológicos, históricos y lingüísticos: ADN antiguo, amerindio, arcaico (período), Banda Oriental, bandeirante, boleadoras, cacique/cacicazgo, cerrito de indios, chaná, charrúa, colombina, conchero, CONACHA, Convenio 169 OIT, CPCN, C14, encomienda, etnónimo, etnocidio, formativo, fusión étnica, haplogrupo mitocondrial, hunter-gatherer, isótopos estables, lítica, mestizaje, minuanes, misión jesuítica, MNA, MNHN, nómada, bohan, chaná-timbú, guenoa, guaraní, payé, yaro, Acosta y Lara, Curel, Fariña, Gianotti, López Mazz, Mourelle de Lema, Bernabé Rivera, Fructuoso Rivera, Sans, Vaimaca Pirú, Vidart |
| `23-bibliografia.md` | Fuentes primarias (Schmidl ~1567, Díaz de Guzmán ~1612, D'Orbigny 1839–43); historia indígena/etnohistoria (Acosta y Lara 1989/1998, Vidart 1996, Susnik 1975, Pi Ugarte); arqueología (López Mazz 1992, Gianotti 2000, Curbelo 1999, Fariña et al. 2014, Bracco 2006); lingüística (Mourelle de Lema 1991, Lenz 1894, Cadogan 1959); genética (Sans et al. 1997/2000/2006); patrimonio/legal (Ley 14.040, Ley 11 abril 2009, Convenio 169 OIT, Declaración ONU 2007); obras históricas generales (Barran-Nahum, Frega); revistas (Revista de Arqueología Americana, Latin American Antiquity, Revista Uruguaya de Antropología y Etnografía); instituciones online (FHCE-UdelaR, MNA, CPCN, IMPO) |
| `24-faq.md` | 20+ preguntas: qué pueblos habitaron el Uruguay, cuándo llegaron los primeros humanos, qué son los cerritos de indios, si los charrúas construyeron los cerritos, cómo era la vida charrúa, cuándo adoptaron el caballo, qué lengua hablaban, quién fue Solís y qué tiene que ver con los charrúas, qué fueron las misiones jesuíticas, qué fue la Guerra Guaranítica, qué fue Salsipuedes, quiénes fueron los cuatro charrúas en París, qué pasó con los restos de Vaimaca Pirú, si fue un genocidio, si hay charrúas hoy, qué organizaciones de descendientes existen, qué dice la ley sobre pueblos indígenas en Uruguay, de dónde viene la mayoría de los nombres de ríos y lugares, qué árbol símbolo viene del guaraní, si el mate tiene origen indígena |

---

### energia-uy (Energía en Uruguay)

**Directorio:** `knowledge/energia-uy/`
**Total archivos:** 30 (README + 29 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, normas editoriales, índice de los 29 archivos, fuentes prioritarias |
| `01-historia-de-la-energia-en-uruguay.md` | Gas de alumbrado 1853; primera electricidad 1886; UTE Ley 3.996/26-12-1912 (Batlle y Ordóñez); ANCAP Ley 8.764/15-10-1931; Refinería La Teja 1937; represas Río Negro (Bonete 1945, Baygorria 1960, Palmar 1982); Salto Grande 1979–81 (binacional); crisis oil 1973/1979; gas argentino 1998–2004; Política Energética 2005–2030; boom eólico 2011–16; GNLM 2016; >97% renovable 2017; H2U 2021; sequía 2022–23 |
| `02-matriz-energetica.md` | Conceptos de matriz energética primaria y eléctrica; evolución 1945–2026; composición aproximada 2023 (hídrica ~25–40%, eólica ~30–35%, biomasa ~8–12%, solar ~5–10%, térmica ~5–15%); energía primaria (~40% petróleo, ~25% biomasa); Balance Energético Nacional (BEN); comparativa regional; tarifas; ventajas y desafíos |
| `03-ute.md` | UTE: Ley 3.996/26-12-1912; historia 1912–2026; estructura (generación, transmisión, distribución, comercialización); centrales hídrica (Bonete, Baygorria, Palmar); parques eólicos propios (Valentines ~70 MW, Palmatir ~50 MW); respaldo térmico (Central Batlle); interconexiones internacionales (Argentina 500 kV/220 kV, Brasil 230 kV); ~1,4 M clientes; ~99,6% cobertura hogares; AMI; Ley 16.832/1997 |
| `04-ancap.md` | ANCAP: Ley 8.764/15-10-1931; monopolio refinación/importación; Refinería La Teja 1937 (~50.000 bbl/día); biocombustibles; ALUR (Bella Unión, bioetanol); GNLM 2016; crisis 2002–2004; lubricantes y asfalto; ~2.500–3.000 empleados |
| `05-miem-y-dne.md` | MIEM: rectoría política energética; Políticas 2005–2030 y 2050; H2U; relaciones internacionales (IEA, IRENA, OLADE, BID, Banco Mundial). DNE: BEN, planificación, eficiencia, licitaciones renovables, estrategia H₂, OLADE/IRENA |
| `06-adme.md` | ADME: Ley 16.832/1997; despacho eléctrico por orden de mérito (hidro→eólica→biomasa→solar→importaciones→térmica); mercado spot (PCP); liquidación de transacciones; interconexiones internacionales (Salto Grande ~2.000 MW, Colonia-Costanera ~500 MW, Rivera-Livramento ~70 MW); estadísticas mensuales |
| `07-ursea.md` | URSEA: Ley 17.598/13-12-2002; control calidad combustibles; calidad servicio eléctrico (SAIDI/SAIFI); asesoría tarifaria; habilitaciones (estaciones de servicio, GLP, gas natural, electricistas); regulación parcial servicios de agua |
| `08-energia-hidroelectrica.md` | Hídrica: cascada Río Negro (Bonete ~160 MW 1945, Baygorria ~108 MW 1960, Palmar ~333 MW 1982); Salto Grande (~945 MW para Uruguay, CTM binacional, 1979–81); total ~1.546 MW; variabilidad por sequías; impactos ecológicos; no se proyectan nuevas grandes represas |
| `09-energia-eolica.md` | Eólica: recurso 6–9 m/s; 0→1.500+ MW en <década (2009–2016); licitaciones competitivas + PPA 20 años; 30–35% generación anual; turbinas Vestas, Gamesa, Enercon, Siemens Gamesa (1,5–3,3 MW); parques en Rocha, Maldonado, Lavalleja, Tacuarembó, Treinta y Tres; UTE (Valentines, Palmatir); desafíos de repotenciación |
| `10-energia-solar.md` | Solar: GHI 1.600–1.800 kWh/m²/año; primera licitación FV 2013–2014; 350–600 MW instalados; 5–10% generación; net metering desde ~2013; solar térmica (termos solares); caída de costos (~3–4 USD/Wp 2010 → ~0,6–1,0 USD/Wp 2023) |
| `11-biomasa.md` | Biomasa: residuos forestales (cogeneración UPM Fray Bentos ~150 MW, UPM 2 Conchillas ~270 MW), bagasse (ALUR ~20–30 MW), cáscara de arroz, aserrín, biogás (relleno sanitario Felipe Cardoso, biodigestores lecheros), leña (3–4 Mm³/año); ~8–12% electricidad, ~20–25% energía primaria |
| `12-biocombustibles.md` | Biocombustibles: Ley 18.195/14-11-2007; biodiesel (FAME soja/girasol/grasa animal, B5 obligatorio, ANCAP); bioetanol (caña ALUR Bella Unión + sorgo dulce, E5/E10 naftas); beneficios y debates (competencia con alimentos, costo, balance GEI) |
| `13-gas-natural.md` | Gas natural: Uruguay sin reservas propias; importación argentina desde 1998 (Gasoducto Cruz del Sur); crisis 2004; GNLM Bahía Montevideo (FSRU, 2016, GNL por barco); red domiciliaria Montevideo/Canelones; GNC vehicular; URSEA regula; perspectivas de descarbonización |
| `14-combustibles-fosiles.md` | Petróleo: dependencia total de importación; Refinería La Teja ANCAP 1937 (~50.000 bbl/día); gasoil, nafta, fueloil, querosene, GLP, asfalto, lubricantes; transporte = mayor consumidor (~55–60%); precios fijados por Poder Ejecutivo; carbón marginal; descarbonización transporte; Acuerdo de París NDC |
| `15-hidrogeno-verde.md` | H₂ verde: electrólisis con renovables; Estrategia H2U (MIEM, 2021); vectores de exportación (amoníaco verde, e-fuels, LH₂); HIF Global Paysandú; UTE y ANCAP como actores; electrolizadores AWE/PEM/SOEC; demanda europea (REPowerEU); cooperación Alemania, UE, BID; ventajas comparativas Uruguay; desafíos (costo 3–8 USD/kg, certificación, infraestructura) |
| `16-red-electrica-nacional.md` | Red eléctrica: transmisión 500/150 kV (UTE); distribución ~99,6% cobertura hogares; interconexiones Argentina (Colonia–Costanera 500 kV, Salto Grande, Paysandú–Colón) y Brasil (Rivera–Livramento 230 kV); despacho ADME; calidad SAIDI/SAIFI (URSEA); medidores AMI masivos; smart grid; net metering; Ley 16.832/1997 |
| `17-represas-y-centrales.md` | Represas: Rincón del Bonete (Gabriel Terra, ~152 MW, 1945), Baygorria (~108 MW, 1960), El Palmar (Constitución, ~333 MW, 1982); Salto Grande (CTM binacional, ~945 MW Uruguay, 1979–81, embalse ~783 km²); centrales térmicas (Batlle, Punta del Tigre); cogeneración biomasa (UPM, ALUR); gestión sequías 2022–23 |
| `18-parques-eolicos.md` | Parques eólicos: recurso 6–9 m/s; >40 parques, >1.500 MW instalados; modelo de licitaciones + PPA 20 años; UTE (Valentines ~70 MW, Palmatir ~50 MW); privados (Sierra de los Caracoles, Peralta, Pampa, Libertad, Rocha, etc.); fabricantes (Vestas, Siemens Gamesa, Enercon, Gamesa); inversión ~3.000–4.000 M USD (2009–2016); desafíos: repotenciación, reciclaje palas, vencimiento PPAs |
| `19-plantas-solares.md` | Plantas solares FV: GHI 1.600–1.800 kWh/m²/año; primera licitación 2013–2014; 350–600 MW instalados; 5–10% generación; net metering (~2013); tecnología (mono-Si, poli-Si, bifaciales, trackers); solar térmica residencial; caída costos 0,5–0,8 USD/Wp (2023); ventajas y desafíos (reciclaje paneles, variabilidad) |
| `20-eficiencia-energetica.md` | Eficiencia: Ley 18.597/21-09-2009 (SNEE, FEE); etiquetado electrodomésticos A–G; sustitución lámparas LED (UTE); colectores solares (subsidios MIEM/BPS); tarifas horarias diferenciales; auditorías industriales; ISO 50001; buses eléctricos STM; GNC vehicular; bombeo solar agropecuario; alumbrado público LED; educación energética |
| `21-investigacion-e-innovacion.md` | I+D: UdelaR–FING (IIE: modelado sistemas eléctricos, integración renovables), Facultad de Química (biocombustibles), IMFIA (hidrología); LATU (certificación, ensayos, I+D); ANII (financiamiento, convocatorias energía); UTE (innovación smart grid, BESS, V2G); ANCAP (H₂ verde refinería); cooperación IRENA, IEA, BID, Alemania, UE; formación RRHH (UTU, UdelaR posgrados) |
| `22-energia-y-medio-ambiente.md` | Energía y ambiente: GEI sector energético ~30–40% emisiones totales; transporte = mayor fuente CO₂ energético; NDC Uruguay (Acuerdo París 2015); impactos hidro (ecosistemas acuáticos, inundación tierras); eólica (avifauna, acústico, palas); solar (uso suelo, fabricación paneles, reciclaje); fósiles (CO₂, PM, derrames, residuos refinería); biomasa (neutro si bien gestionado); EIA / AAP (Ministerio Ambiente); sequía 2022–23 y cambio climático |
| `23-energia-y-economia.md` | Energía y economía: importaciones combustibles ~1.000–1.500 M USD/año; exportaciones electricidad (excedentes); inversión renovable ~3.000–4.000 M USD (2009–2016); IED sectorial (Vestas, Gamesa, Acciona, EDP); empleo directo UTE (~4.000–5.000), ANCAP (~2.500–3.000); tarifas eléctricas fijadas administrativamente; ahorro combustibles por transición renovable (cientos de M USD); H₂ verde como oportunidad exportadora |
| `24-cooperacion-internacional.md` | Cooperación: IRENA (miembro fundador 2009; publicaciones Uruguay como modelo); IEA (país asociado); OLADE (SIER; foros); BID (renovables, H₂ verde, eficiencia); Banco Mundial (electrificación rural, regulación); CAF (infraestructura); CTM Salto Grande (Argentina binacional); CARU; interconexiones Brasil (ONS–UTE); Alemania (GIZ, KfW, H₂ verde); UE (EUROCLIMA+, REPowerEU); CIER; MERCOSUR SGT 9; Uruguay como referente global en renovables |
| `25-linea-de-tiempo.md` | Cronología energética Uruguay 1853–2026+: gas alumbrado 1853; electricidad 1886; UTE 1912; ANCAP 1931; Refinería La Teja 1937; Bonete 1945; Baygorria 1960; crisis petróleo 1973/1979; Palmar 1982; Salto Grande 1979–81; reforma Ley 16.832/1997; gas argentino 1998; crisis gas 2004; Política Energética 2005–2030; boom eólico 2011–16; licitación solar 2013–14; UPM Fray Bentos 2007; GNLM 2016; >97% renovable 2016–17; UPM 2 (2022); H2U 2021; sequía 2022–23; proyectos BESS y H₂ 2023–24 |
| `26-glosario.md` | ~60 términos y siglas: ADME, aerogenerador, AMI, ALUR, AMV, ANCAP, ANII, AWE, BEN, BESS, biodiesel, bioetanol, biogás, biomasa, CAF, CARU, CIER, CTM, cogeneración, densidad de potencia, despacho, DNE, electrólisis, embalse, EIA, factor de planta, FEE, FV, GEI, GHI, GLP, GNC, GNL, GNLM, H2U, hidrógeno azul/gris/verde, IEA, IRENA, LATU, matriz energética, MERCOSUR, MIEM, MW/MWh, NDC, net metering, OLADE, PCP, PEM, PIB, PPA, Refinería La Teja, repotenciación, SAIDI, SAIFI, SNAP, SNEE, SOEC, trackers, UdelaR, UTE, URSEA, V2G |
| `27-bibliografia.md` | Fuentes institucionales: MIEM/DNE (sitio, BEN, Política 2005–2030, H2U), UTE (memorias), ADME (estadísticas mercado), ANCAP (memorias, ALUR, GNLM), URSEA (normativa, SAIDI/SAIFI), LATU, ANII; académicas: UdelaR–FING (IIE, COLIBRI), Facultad Química; internacionales: IRENA (IRENASTAT, publicaciones ALC), IEA, OLADE (SIER), BID, Banco Mundial, CEPAL; normativa: Parlamento/IMPO (leyes clave); revistas: Energy Policy, RSER, Applied Energy, Energies (MDPI) |
| `28-faq.md` | 20+ preguntas: % electricidad renovable Uruguay, cuándo alcanzó 97%, fuentes energía primaria, reservas petróleo/gas, qué es UTE/ANCAP/ADME/URSEA, principales represas, Salto Grande, parques eólicos, net metering solar residencial, hidrógeno verde H2U, por qué depende del petróleo si hay renovables, gas natural argentino/GNLM, eficiencia energética (Ley 18.597), impacto ambiental renovables, Acuerdo París NDC, cómo Uruguay logró 97% |
| `29-proyectos-estrategicos.md` | Segunda transición energética: Eje 1 H₂ verde (H2U, HIF Global Paysandú, marco regulatorio, infraestructura portuaria, RRHH, cooperación Alemania); Eje 2 BESS baterías (sequía 2022–23, licitación BESS, tecnologías Li-ion/flujo); Eje 3 Movilidad eléctrica (buses STM, red de carga VE, incentivos fiscales, V2G, flota pública); Eje 4 Smart grids (AMI, SCADA, gestión demanda, microrredes, ciberseguridad); Eje 5 Descarbonización profunda (electrificación transporte/calor industrial, biocombustibles avanzados SAF, descarbonización refinería ANCAP, edificación eficiente, revisión Política 2050); financiamiento (UTE, ANCAP, BID, CAF, KfW, IED, GCF) |

---

### agro-uy (Agro Uruguayo)

**Directorio:** `knowledge/agro-uy/`
**Total archivos:** 25 (README + 24 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, normas editoriales, índice de los 24 archivos, audiencias objetivo (estudiantes, docentes, investigadores, agrónomos, veterinarios, economistas, periodistas, organismos públicos, sistemas RAG), fuentes prioritarias (MGAP/DIEA, INIA, INAC, INAVI, INALE, INASE, Plan Agropecuario, Facultad Agronomía UdelaR, Facultad Veterinaria UdelaR) |
| `01-historia-del-agro-en-uruguay.md` | Historia agraria desde el período colonial (Hernandarias 1611, vaquerías, saladeros), alambrado 1871, ARU 1872, frigoríficos 1904, batllismo, ISI, CONAPROLE 1936, INIA 1989, forestación Ley 15.939/1987, UPM 2007/2022, boom sojero 2002–2014, SNIG trazabilidad bovina |
| `02-agricultura.md` | Panorama agrícola: condiciones naturales, principales cultivos (cereales, oleaginosas), zonas agrícolas por departamento, manejo del suelo (siembra directa, rotaciones), fertilización, semillas (INASE), riego, mecanización |
| `03-ganaderia.md` | Ganadería bovina (~11–12 millones de cabezas), razas (Hereford, Angus, Brahman, Holando), sistemas productivos (cría, recría, feedlot), producción ovina (~6–8 M cabezas; Corriedale/Merino), sanidad (aftosa libre con vacunación desde 2003), SNIG trazabilidad, genética (IA, TE), estadísticas INAC |
| `04-produccion-lechera.md` | CONAPROLE (Ley 9.526/1936), cuencas lecheras (sur, litoral norte, norte), ~2.500–3.000 millones de litros/año, razas Holstein/Jersey, sistema pastoril, exportaciones (leche en polvo, quesos, manteca, suero), INALE |
| `05-arroz.md` | Oriente uruguayo (Treinta y Tres, Cerro Largo, Rocha), riego por taipas, variedades INIA (Tacuarí, Olimar, El Paso 144), rendimiento 7.500–8.500 kg/ha (entre los más altos del mundo), cooperativas SAMAN/COOPAR, exportaciones a Brasil, Perú, África, Iraq |
| `06-soja.md` | Boom desde 2002; >1 millón de ha en campaña 2012–13; variedades transgénicas RR; siembra directa; principal mercado China; impactos ambientales (erosión, concentración de tierras); Plan de Uso y Manejo de Suelos Decreto 405/008 |
| `07-trigo-y-cereales.md` | Trigo (historia, variedades INIA: Tijereta/Torcaza/Churrinche), cebada maltera (Maltería Uruguay en Paysandú, variedad Scarlett), maíz (silaje, grano, exportación), avena (cultivo de cobertura), sorgo (forrajero), canola/colza |
| `08-horticultura-y-fruticultura.md` | Canelones como zona principal, cultivos principales (papa, cebolla, zanahoria, lechuga, tomate), citricultura en Salto/Paysandú (naranja, mandarina, limón, pomelo; USD 150–250 M/año), arándanos (contraestación hemisferio norte), olivicultura, manzanas/peras |
| `09-vitivinicultura.md` | Tannat introducido por Harriague en 1874 en Salto, INAVI (Ley 15.876/1987), zonas vitícolas (Canelones principal, Salto, Colonia, Maldonado), variedades (Tannat/Merlot/Cabernet Sauvignon/Chardonnay/Sauvignon Blanc), 6.000–8.000 ha, 80–120 M litros/año, Indicación Geográfica Canelones, enoturismo |
| `10-forestacion.md` | Ley 15.939/1987 como fundamento legal, especies eucaliptos/pinos, tres plantas de celulosa: UPM 2007 Fray Bentos (~880.000 t/año), Montes del Plata 2014 Conchillas (~1,3 Mt/año), UPM 2 2022 Paso de los Toros (~2,1 Mt/año); capacidad total ~4,3 Mt/año; certificaciones FSC/PEFC; conflicto CIJ Argentina-Uruguay 2010 |
| `11-apicultura.md` | 800.000–1.000.000 colmenas, 10.000–15.000 toneladas/año de miel, principales mercados Alemania/EEUU/Reino Unido, manejo Varroa destructor, flora apícola (eucalipto/trébol/lotus), Sociedad Apícola Uruguaya (SAU), producción de polen/propóleo/jalea real/cera |
| `12-acuicultura.md` | DINARA regula, Ley 19.175/2014, especies de agua dulce (bagre, pacú, trucha), bivalvos marinos (ostras en Laguna Garzón, mejillones), producción total <1.000 t/año, pesca continental (dorado, surubí, pejerrey) |
| `13-agroindustria.md` | Industria frigorífica (Frigorífico Anglo 1863–1979, UNESCO 2015; plantas actuales MARFRIG, JBS; 2–2,5 M cabezas/año; USD 1.500–2.000 M exportaciones), CONAPROLE lácteos, molinería arrocera (SAMAN, COOPAR), celulosa (UPM/Montes del Plata), bodegas vitivinícolas >200, procesamiento cítricos, integración avícola y porcina |
| `14-investigacion-e-innovacion.md` | INIA (Ley 16.065/1989, 6 estaciones experimentales, financiado con 0,4% FOB exportaciones agropecuarias), Facultad Agronomía UdelaR (1906), Facultad Veterinaria (1908), LATU (1965), ANII (2005, FSSA fondo sectorial), biotecnología (cultivo in vitro, MAS, genómica, regulación OGM, bioinsumos), agricultura de precisión |
| `15-instituciones.md` | MGAP (1947; DIEA/DGDR/DIGEGRA/DSA/DGSV/DGSSAA/DGF/DINARA), INIA (Ley 16.065/1989), INAC (Ley 15.605/1984), INAVI (Ley 15.876/1987), INALE (Ley 18.242/2007), INASE (Ley 16.811/1997), Plan Agropecuario (Ley 16.736/1996), INC colonización (Ley 11.029/1948), ARU (1871, Expo Prado), Federación Rural (1915), CNFR (1915), CAF |
| `16-trazabilidad-y-sanidad.md` | SNIG (Decreto 333/004, Ley 17.997/2006; doble caravana; primer sistema nacional de trazabilidad bovina individual del mundo), estatus sanitario (aftosa libre con vacunación desde 2003, brucelosis, tuberculosis, libre de EEB), bienestar animal (Cinco Libertades), sanidad vegetal (DGSA), certificaciones Halal/Kosher/USDA/UE |
| `17-comercio-exterior.md` | Celulosa USD 2.500–3.500 M (principal rubro), carne bovina USD 1.500–2.000 M, soja USD 800–1.200 M, lácteos USD 400–600 M, arroz USD 300–500 M; China principal destino (~30–35%); factores competitivos (estatus sanitario, SNIG, carne natural, estabilidad política, MERCOSUR); Puerto de Montevideo y Nueva Palmira |
| `18-agro-y-medio-ambiente.md` | Conservación de suelos (Plan Uso Manejo Suelos Decreto 405/008, siembra directa, tolerancia 7–10 t/ha/año), calidad del agua (cianobacterias Río Santa Lucía, nitratos/fósforos de lechería), cambio climático/GEI (metano rumiantes dominante, NDC Acuerdo París), biodiversidad pastizales (Alianza del Pastizal), agroquímicos (debate glifosato), certificaciones (FSC, GlobalG.A.P., CNA carne natural) |
| `19-tecnologia-agropecuaria.md` | Agricultura de precisión (GPS/RTK, monitores de rendimiento, aplicación variable VRA), drones (monitoreo, fumigación, conteo de animales, forestación), IoT (estaciones meteorológicas, sensores de suelo, collares GPS, GRAS-INIA), Big Data e IA (machine learning para predicción de rendimientos, detección de enfermedades, agtech startups), blockchain para trazabilidad, robots de ordeñe, SIG, modelos de simulación INIA (DSSAT, APSIM) |
| `20-cooperativismo-rural.md` | Historia del cooperativismo agrario (CONAPROLE 1936, CNFR 1915, Federación Rural 1915); Ley 18.407/2008 (Ley General de Cooperativas) e INACOOP; tipos de cooperativas (producción, gestión, crédito, consumo, mixtas); cooperativas principales (CONAPROLE: Ley 9.526/1936, ~60–65% leche; COOPAR: arroz Treinta y Tres; SAMAN; SFR: Sociedades de Fomento Rural >120); cooperativismo y pequeños productores; género en cooperativas; FONDES financiamiento |
| `21-linea-de-tiempo.md` | Cronología desde 1611 (Hernandarias) hasta 2026: vaquerías, saladeros, Frigorífico Anglo 1863, alambrado 1871, ARU 1871, Tannat 1874, frigoríficos modernos 1904, CONAPROLE 1936, INIA 1989, MERCOSUR 1991, boom soja 2002–13, SNIG 2004, aftosa libre 2003, forestación Ley 15.939/1987, UPM 2007, Montes del Plata 2014, UPM 2 2022, agricultura de precisión, drones, regulación bioinsumos |
| `22-glosario.md` | ~80 términos técnicos, institucionales y productivos: ARU, bienestar animal, Corriedale, CNFR, CONAPROLE, cría/recría/engorde, Decreto 405/008, DIEA, DINARA, DGSV, aftosa/fiebre aftosa, faena, feedlot, forestación, GEI, glifosato, Halal/Kosher, Hereford/Angus, INAC, INACOOP, INALE, INAVI, INASE, INIA, INC, ISI, LATU, MGAP, mestización, novillo, OIE, ovino, pastizal, Plan Agropecuario, praderas artificiales, raza Tannat, recría, rodeo, rotación de cultivos, SAMAN, sanidad animal, SAU, siembra directa, SNIG, taipas, trazabilidad, transgénico, UPM, vacunación antiaftosa, vaquillona, zoonosis |
| `23-bibliografia.md` | Fuentes institucionales (MGAP/DIEA Anuario Estadístico, INIA publicaciones técnicas 6 estaciones, INAC estadísticas, INAVI, INALE, INASE, Uruguay XXI exportaciones), legislación (Ley 9.526, 15.605, 15.876, 15.939, 16.065, 16.736, 16.811, 17.997, 18.242, 18.407; Decreto 333/004, Decreto 405/008), publicaciones académicas (Barrán-Nahum Historia Rural, Moraes La pradera perdida, Rovira/Soca ganadería, Arbeletche soja, Agrociencia Uruguay, Veterinaria Montevideo), organismos internacionales (FAO/FAOSTAT, OIE, IICA, BID, Banco Mundial), publicaciones periódicas (Revista Plan Agropecuario, El País Agropecuario, La Semana Agropecuaria), datos abiertos (mgap.gub.uy, inia.uy, inac.uy, inavi.com.uy, inale.org, uruguayxxi.gub.uy) |
| `24-faq.md` | 20+ preguntas frecuentes: importancia del agro en la economía, principal producto de exportación (celulosa), stock bovino (11–12 M cabezas), principales destinos (China), estatus aftosa Uruguay (libre con vacunación desde 2003), qué es el SNIG (primer sistema nacional trazabilidad bovina individual del mundo), razas bovinas principales, frigoríficos exportadores, stock ovino, CONAPROLE y su peso, sistema lechero pastoril, competitividad arrocera, boom soja y su impacto, variedad Tannat, Ley 15.939 forestación, controversia Argentina-Uruguay/UPM, qué hace el INIA, qué es el Plan Agropecuario, CNFR y cooperativismo, Ley 18.407 cooperativas, principales problemas ambientales, compromisos climáticos NDC |

---

### geografia-uy (Geografía del Uruguay)

**Directorio:** `knowledge/geografia-uy/`
**Total archivos:** 23 (README + 22 documentos)
**Última actualización:** 2026-07-23

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Descripción del dominio, normas editoriales, índice de los 22 archivos, audiencias objetivo (estudiantes, docentes, investigadores, geógrafos, planificadores, periodistas, organismos públicos, sistemas RAG), fuentes prioritarias (IGM, INE, MA, MVOT, MTOP, SOHMA, FCIEN, FADU, DINAGUA, INUMET) |
| `01-geografia-general-del-uruguay.md` | Panorama general: ~176.215 km², posición 30°–35°S / 53°–58°W, fronteras (Argentina: ~579 km fluvial; Brasil: ~1.069 km), 19 departamentos, compacidad territorial, acceso costero (~660 km), frente estuarial del Río de la Plata |
| `02-formacion-del-territorio.md` | Escudo Cristalino Uruguayo (>2.000 Ma); Cinturón Dom Feliciano (~600 Ma); Cuenca Norte (Fm. Arapey basaltos ~135 Ma; Fm. Tacuarembó; dinosaurios); Cuenca Litoral; Cuenca del Este; tabla de evolución geológica; recursos minerales (ágatas, granito, hierro Valentines); paleontología (Arroyo del Vizcaíno, Fariña) |
| `03-ubicacion-y-limites.md` | Coordenadas extremas; superficies (~176.215 km² continental; ~142.166 km² ZEE); fronteras con Argentina (fluvial, Río Uruguay + Río de la Plata; Tratado 1973; Estatuto Río Uruguay 1975; CARU) y Brasil (~1.069 km; Río Cuareim, Río Yaguarón, Laguna Merín; ciudades gemelas); límites marítimos (12 mni mar territorial; 24 mni zona contigua; ZEE 200 mni); tabla de tratados clave |
| `04-relieve.md` | Cuchilla Grande (NNE-SSO; Cerro Catedral ~514 m; granitos del Escudo); Cuchilla de Haedo (N-S; 200–380 m; basaltos); Cuchilla de Santana (noreste); tabla de sierras (Carapé, Aiguá, Las Ánimas ~501 m, Rivera, Mal Abrigo); tabla de cerros (Catedral ~514 m, Las Ánimas ~501 m, Pan de Azúcar ~423 m, Arequita ~330 m, Cerro de Montevideo ~139 m); llanuras; geomorfología (erosión fluvial, meteorización química, eólica, costera) |
| `05-hidrografia.md` | Río Uruguay (~1.838 km total, ~495 km frontera, ~4.700 m³/s en Salto, Salto Grande ~1.890 MW); Río de la Plata (estuario, ~320 km longitud, ~220 km anchura, Tratado 1973); Río Negro (~750 km, cascada: Bonete 1945 ~160 MW, Baygorria 1960 ~108 MW, El Palmar 1982 ~333 MW); Río Santa Lucía (~230 km, >60% agua potable Montevideo, crisis cianobacterias 2013–2016); Río Yaguarón (frontera Brasil); Río Cuareim (~340 km); tabla de lagunas principales (Merín ~3.750 km², Negra, Rocha, Sauce, Garzón, Castillos); tabla de embalses; Acuífero Guaraní (30–50°C termal) |
| `06-cuencas-hidrograficas.md` | Sistema del Plata (~70%): Cuenca Río Uruguay (~55.000 km² en UY; CARU), Cuenca Río Negro (~65.000 km²; afluentes Yí y Tacuarembó; 3 embalses), Cuenca Santa Lucía (~13.500 km²; Plan de Cuenca 2013), Cuenca Queguay (~10.000 km²), subcuencas directas al Río de la Plata; Vertiente Atlántica (~30%): Cuenca Laguna Merín (~62.000 km² total; Yaguarón, Tacuarí, Olimar, Cebollatí, San Miguel); tabla de lagunas costeras; legislación hídrica: Art. 47 Constitución 2004; Ley 18.610/2009; Plan Nacional de Aguas 2017; DINAGUA rector |
| `07-clima.md` | Köppen Cfa (subtropical húmedo, sin estación seca); temperaturas (17–18°C media anual Montevideo; 23–25°C enero; 10–12°C julio; extremos ~43–44°C max; ~-9°C min); precipitaciones (1.100–1.400 mm/año; distribución uniforme); vientos (Norte, Pampero SO polar, Sudestada SE, Este costero); tabla de sequías (1988–89, 1999–2000, 2008–09, 2022–23); inundaciones; tornados (Dolores 15/04/2016); proyecciones cambio climático (INUMET; +0,5 a +2°C para 2050; ascenso del nivel del mar 20–50 cm); tabla de regiones climáticas internas |
| `08-suelos.md` | Molisoles/Brunizems (~50–55%: sur y centro; alta fertilidad natural); Vertisoles (~10–15%: litoral oeste; arcillas pesadas); Alfisoles/Planosoles (~10–12%: planicie costera este; arroz); Entisoles (sierras, playas, dunas); Inceptisoles (norte basáltico); índice CONEAT (base 100 = promedio nacional; mejores suelos 120–200); erosión (laminar, en surco, eólica); Decreto 405/008 (7–10 t/ha/año tolerancia; planes exigidos >100 ha uso agrícola); siembra directa; tabla de clases de capacidad de uso I–VII; Ley 15.239/1981; DGRNR/MGAP rector |
| `09-recursos-naturales.md` | Agua (~23.000 m³/hab/año disponibilidad; OSE; Acuífero Guaraní; Acuerdo 2010); suelos (~70–75% aptitud agropecuaria; tabla de uso del suelo); minerales (ágatas/amatistas Artigas líder mundial; granito ornamental; sin petróleo/gas significativo); forestación (Ley 15.939/1987; >1.200.000 ha plantadas; UPM/Montes del Plata/UPM 2; bosque nativo ~700.000–800.000 ha protegido); pesca (industrial: corvina, calamar, merluza ~40.000–70.000 t/año; artesanal; continental; acuicultura <1.000 t/año; DINARA rector); energía (>97% electricidad renovable; >1.500 MW eólica; 350–600 MW solar; ~1.546 MW hídrica; ~500–600 MW biomasa; H2U hidrógeno verde; ANCAP Refinería La Teja ~50.000 bbl/día importación); SNAP biodiversidad |
| `10-regiones-geograficas.md` | 5 regiones con tablas completas: (1) Litoral Oeste (Artigas/Salto/Paysandú/Río Negro/Soriano/Colonia; Río Uruguay; basaltos; Salto Grande; Fray Bentos Anglo UNESCO 2015; Salto ~125.000 2ª ciudad interior); (2) Sur/Metropolitana (Montevideo/Canelones/San José; costa Río de la Plata; >50% población; >65% PIB; Puerto Montevideo; Aeropuerto Carrasco); (3) Norte/Cuchillas (Rivera/Tacuarembó; basaltos; forestación; Festival Folclore Tacuarembó; Rivera–Santana binacional); (4) Este/Litoral Atlántico (Rocha/Treinta y Tres/Maldonado; Punta del Este; Planosoles para arroz; Laguna Merín; Bañados del Este Ramsar; Palmar Butiá VU); (5) Centro (Durazno/Flores/Florida/Lavalleja; embalses Río Negro; Cerro Catedral 514 m) |
| `11-organizacion-territorial.md` | Tabla de los 19 departamentos (nombre, capital, área km², población estimada 2023); Tacuarembó más grande (~15.438 km²); Montevideo más pequeño (~530 km²) y más poblado (~1.350.000); Flores menos poblado (~25.000); Ley 18.567/2009 (municipios; >2.000 habitantes; alcalde + concejo de 5 miembros; ~112 municipios al 2023); Congreso de Intendentes; Área Metropolitana de Montevideo (AMM: Montevideo ~1.350.000 + Ciudad de la Costa ~150.000 + Las Piedras ~80.000 + otros ≈ ~1.850.000); otras aglomeraciones urbanas; clasificación INE (ciudad >5.000; villa 500-5.000; pueblo 50-500; paraje <50) |
| `12-departamentos.md` | Fichas geográficas de los 19 departamentos: capital, área, límites, relieve, hidrografía, economía, datos destacados. Hitos clave: Artigas (ágatas/amatistas), Canelones (2º más poblado, Aeropuerto Carrasco, horticultura, vitivinicultura), Colonia (UNESCO 1995), Florida (Declaración de Independencia 1825, Paso Severino), Lavalleja (Cerro Catedral 514 m), Maldonado (Punta del Este, Casapueblo, Isla de Lobos SNAP, CURE), Montevideo (capital, 40% población, 65-70% PIB), Río Negro (UPM celulosa, Anglo UNESCO 2015), Rivera (binacional), Rocha (Bañados del Este Ramsar, Cabo Polonio SNAP, Palmar Butiá VU), Salto (Represa Salto Grande CTM, termas, nacimiento Luis Suárez 1987), Tacuarembó (mayor departamento), Treinta y Tres (arroz, Quebrada de los Cuervos SNAP) |
| `13-cartografia.md` | Historia cartográfica (Solís 1516, Gaboto 1527, Azara-Oyarvide 1783, Servicio Geográfico Militar 1884, IGM 1913, fotogrametría 1940s–60s, GPS 1990s, IDEUY 2002, Decreto 399/007 2007, cartografía digital 2010s–2023); IGM (Ministerio Defensa; escalas 1:50.000/1:25.000/1:100.000/1:500.000/1:1.000.000; RGN; www.igm.gub.uy); datum SIRGAS 2000 (geocéntrico; compatible WGS84; reemplaza datum YACARÉ; desplazamiento ~10–15 m); husos UTM 21S y 22S; IDEUY (OPP; estándares OGC; portal); SIG usuarios (MGAP/DIEA, MA, MTOP, MVOT, INE, IMM, UdelaR); SOHMA (cartografía náutica) |
| `14-geografia-humana.md` | Censo 2011: 3.286.314 total; >95% urbano; densidad ~20 hab/km²; distribución por departamento (Montevideo 40,1%, Canelones 15,8%); historia de la urbanización (siglo XIX inmigrantes europeos, 1900–1950 industrialización, 1950–1985 éxodo rural, 1985–2023 expansión metropolitana); tabla de principales ciudades; ciclos de emigración (1960–1985 dictadura/economía; 2001–2005 crisis 2002; diáspora ~500.000–700.000); inmigración (europeos siglos XIX-XX; siglo XXI venezolanos/cubanos/colombianos); Ley 18.250/2008; estructura demográfica (0-14: ~20%; 15-64: ~63%; 65+: ~17%; TGF ~1,5–1,7; esperanza de vida ~77 años); composición étnica Censo 2011 (blanca ~88%; afro ~8%; indígena ~5%) |
| `15-distribucion-de-la-poblacion.md` | Datos Censo 2011: 3.286.314 total; 95,3% urbano; 4,7% rural; tasa de crecimiento anual 2004–2011 +0,64%; tabla completa por departamento (población, área km², densidad, capital, población capital); categorías urbanas (>5.000 = urbano 86%; villas 500-5.000 ~6%; rural disperso ~4,7%); tabla de las 10 principales localidades; crecimiento lento y envejecimiento (TGF ~1,5–1,7; esperanza de vida ~77 años; 17% mayores de 65 = uno de los más altos de América Latina); macrocefalia (Montevideo 10 veces más grande que Salto); suburbanización (Ciudad de la Costa Canelones); distribución por sexo (mujeres 51,4%, hombres 48,6%) |
| `16-infraestructura-territorial.md` | Red vial (~75.000 km total; ~8.800 km rutas nacionales pavimentadas; DNV/MTOP); tabla de rutas principales (Ruta 1 Montevideo-Colonia; Ruta 2 Fray Bentos; Ruta 3 ~800 km a Bella Unión; Ruta 5 a Rivera; Ruta 7 a Chuy; Ruta 8 a Melo/Aceguá; Ruta 9 costera; Ruta 101 Anillo Vial); Interbalnearia (~120 km a Punta del Este); concesiones PPP desde 2012; ferroviaria (AFE; ~2.900 km; trocha 1.435 m; pasajeros suspendido 1988; Ferrocarril Central Montevideo–Paso de los Toros ~273 km rehabilitado 2022 para UPM); puertos: Montevideo (ANP; multipropósito; canal 13 m profundidad; ~900.000–1.000.000 TEU/año), Nueva Palmira (graneles; 60–70% exportaciones de grano), Fray Bentos (celulosa UPM); aeropuertos: Carrasco MVD (Canelones; terminal Rafael Viñoly 2009; 3–4 M pax/año pre-COVID), PDP Laguna del Sauce; pasos de frontera con Argentina y Brasil; logística (12 zonas francas; INALOG; Ferrocarril Central) |
| `17-ordenamiento-territorial.md` | Ley 18.308/2008 LOTDS (marco principal); clasificación del suelo (urbano/suburbano/rural); instrumentos (DNOT, DD, PLOT, Planes Especiales); principios (función social/ecológica de la propiedad, sustentabilidad, participación ciudadana, coordinación, control de impacto ambiental); DINOT/MVOT (rector; SIMOT; IDEUY); DNOT (Directrices Nacionales 2011; modelo territorial nacional); POT Montevideo (1998 actualizado; competencia IMM; zonificación, normas de edificación, patrimonio, movilidad); AMM (OPP + 3 intendencias + Junta Metropolitana); planificación costera (POTAC; franja pública 250 m; protección erosión); asentamientos irregulares (~170.000 hogares; PMB; MEVIR); planificación rural (Decreto 405/008; franjas de amortiguación; no subdivisión <200 ha en algunos departamentos); tabla de legislación |
| `18-instituciones.md` | Instituciones con competencia geográfica y territorial: IGM (cartografía, RGN, datum); INE (censos, ECH, IPC); Ministerio de Ambiente (MA: DINABISE/SNAP, DINAGUA, DINA, DNCCC); MVOT (DINOT, DNC, DINAVI); MTOP (DNV, DNH, DNT); SOHMA (cartografía náutica, meteorología marina); INUMET (Ley 19.007/2013; www.inumet.gub.uy; pronósticos, OMM); UdelaR–FCIEN (Departamento de Geografía; Geociencias; IECA; fundado 1990); FADU (ITU; IHA; fundado 1915); OPP (coordinador IDEUY); IDEUY (Decreto 399/007/2007; estándares OGC); ANP (Puerto de Montevideo) |
| `19-linea-de-tiempo.md` | Cronología desde período geológico (>2.000 Ma Escudo Cristalino; ~600 Ma Dom Feliciano; ~135 Ma Fm. Arapey; ~2 Ma–10.000 a.C. Cuaternario/megafauna; ~13.000 a.C. primeros humanos; ~4.000 a.C. cerritos) hasta exploración europea (1516 Solís, 1527 Gaboto, 1611 Hernandarias ganado, 1624–1706 Misiones jesuíticas, 1680 Colonia Sacramento Portugal), período colonial tardío (1724–26 fundación Montevideo, 1750 Tratado Madrid, 1777 Tratado San Ildefonso, 1783 Azara-Oyarvide cartografía), independencia y formación del Estado (1811, 1825, 1828, 1851 Tratado límites Brasil, 1857 primer ferrocarril, 1871 alambrado, 1878–82 comisión demarcación, 1884 IGM precursor), modernización y siglo XX (1913 IGM reorganizado, 1945 Bonete, 1960 Baygorria, 1973 Tratado Río de la Plata, 1975 Estatuto Río Uruguay, 1979–81 Salto Grande, 1982 El Palmar, 1984 Bañados del Este Ramsar, 1987 Ley forestación, 1991 MERCOSUR, 1995 Colonia UNESCO, 1998 Ley 17.033 ZEE, 2000 SNAP Ley 17.234, 2002 IDEUY, 2004 Art. 47 Constitución, 2007 Decreto IDEUY/UPM Fray Bentos, 2008 LOTDS, 2009 Ley 18.567 municipios/Ley 18.610 aguas, 2010 fallo CIJ, 2013 cianobacterias Santa Lucía, 2014 Montes del Plata, 2015 Anglo UNESCO, 2016 tornado Dolores, 2020 Ministerio Ambiente, 2022 UPM 2 + Ferrocarril Central, 2023 crisis hídrica) |
| `20-glosario.md` | ~80 términos geográficos, cartográficos, geológicos, hidrológicos, meteorológicos, demográficos e institucionales A–Z: Acuífero Guaraní, AFE, ANP, AMM, Basalto, Bioma Pastizales Río de la Plata, Brunizem, CARU, Cinturón Dom Feliciano, Cuchilla/Cuchilla Grande/Haedo, Datum/SIRGAS 2000/YACARÉ, DINAGUA, DINABISE, DINOT, DNV, Embalse, Estuario Río de la Plata, Escudo Cristalino, Fm. Arapey, Fm. Tacuarembó, Geomorfología, Geodesia, GIS/SIG, Humedal, IDEUY, IGM, INE, INUMET, Laguna Merín, LOTDS, Macrocefalia urbana, Molisol, MVOT, MTOP, OSE, Ortofotografía, Pampero, Pastizal natural, Planosol, Ramsar, RGN, Relieve, Sierra, SIRGAS 2000, SNAP, SOHMA, Sudestada, TEU, Trocha, UTM, Vertisol, WGS84, ZEE |
| `21-bibliografia.md` | Fuentes institucionales: IGM (cartografía topográfica, RGN, datum SIRGAS 2000); INE (Censo 2011, ECH, proyecciones); MA/DINABISE (SNAP fichas técnicas); MA/DINAGUA (SNIRH, Plan Nacional de Aguas 2017); MVOT/DINOT (DNOT 2011, SIMOT, LOTDS); MTOP/DNV (red vial, estadísticas tránsito); INUMET (Atlas Climático, series históricas); SOHMA (cartas náuticas); OPP/IDEUY (catálogo datos geoespaciales); legislación (Constitución 2004 art. 47, Leyes 15.239, 15.939, 17.033, 17.234, 18.308, 18.567, 18.610, 19.007; Decretos 399/007, 405/008; Tratado Río de la Plata 1973; Estatuto Río Uruguay 1975; Tratado límites Uruguay-Brasil); publicaciones académicas (Bossi-Navarro Geología Uruguay; Bossi-Ferrando Carta Geológica 1:500.000; Durán Los suelos del Uruguay; Fariña et al. Arroyo del Vizcaíno Proc. Royal Soc. B 2014; BARRETO et al. Acuífero Guaraní DINAGUA 2010; BIDEGAIN et al. Vulnerabilidad cambio climático MVOTMA 2011; INE Perfil demográfico Censo 2011); portales datos geoespaciales (IDEUY, IGM, INE, INUMET, MA, MVOT, MTOP, ANP); organismos internacionales (UNESCO, Ramsar, FAO/AQUASTAT, CEPAL, OEA Acuerdo Acuífero Guaraní 2010) |
| `22-faq.md` | 25+ preguntas frecuentes: superficie Uruguay (~176.215 km²), punto más alto (Cerro Catedral ~514 m), principales ríos (Uruguay/Negro/Santa Lucía/Cuareim/Yaguarón), Acuífero Guaraní (30–50°C; mayor reserva subterránea América del Sur; Acuerdo 2010), cuencas hidrográficas (Sistema del Plata ~70%/ Vertiente Atlántica ~30%), laguna más grande (Laguna Merín ~3.750 km²), clima (Cfa subtropical húmedo; 1.100–1.400 mm/año; sin estación seca), Pampero (viento frío SO; caída brusca temperatura), Sudestada (viento SE persistente; inundaciones costeras rioplatenses), tipos de suelos (Molisoles ~50–55%; CONEAT), número de departamentos (19), mayor y menor (Tacuarembó ~15.438 km² / Montevideo ~530 km²), LOTDS Ley 18.308/2008, municipios Ley 18.567/2009 (~112), población Uruguay (Censo 2011: 3.286.314; >95% urbano), densidad media (~20 hab/km²), macrocefalia uruguaya (Montevideo >50% población), IGM (cartografía oficial 1:50.000; Ministerio Defensa), SIRGAS 2000 (datum geocéntrico; reemplaza YACARÉ; diferencia ~10–15 m), IDEUY (plataforma datos geoespaciales; Decreto 399/007/2007; OPP), SNAP (Ley 17.234/2000; áreas protegidas), sitios Ramsar (Bañados del Este 1984 primer sitio), crisis hídrica 2023 (sequía extrema; Paso Severino; OSE mezcla agua Río de la Plata; sodio elevado), tornado Dolores 2016 (15/04/2016; Soriano; víctimas fatales; daños materiales graves) |

---

## Historial de versiones

| Versión | Fecha | Descripción |
|---------|-------|-------------|
| 1.0.0 | 2026-07-18 | Creación del inventario. Dominios activos: carnaval, candombe, música, literatura. 35 documentos de contenido, 8 plantillas. |
| 2.0.0 | 2026-07-19 | Incorporación de 3 nuevos dominios: teatro, artes plásticas, historia. 72 documentos de contenido. Instituciones actualizadas. |
| 4.0.0 | 2026-07-19 | Incorporación de 5 nuevos dominios: política (9 docs), identidad (6 docs), turismo (10 docs), deportes (13 docs), educación (23 docs). Total: 12 dominios activos, 133 documentos de contenido, 16 instituciones. |
| 5.0.0 | 2026-07-19 | Incorporación del dominio Economía: 27 documentos de contenido (historia económica, sectores productivos, comercio exterior, política económica), 8 instituciones (BCU, MEF, INE, BPS, DGI, Uruguay XXI, ANDE, CND). Total: 13 dominios activos, 160 documentos de contenido, 24 instituciones. |
| 6.0.0 | 2026-07-19 | Incorporación del dominio Tecnología (TEC): 12 documentos temáticos (TEM_TEC_0001-0012), 12 empresas (EMP_TEC_0001-0012), 6 instituciones (INS_TEC_0001-0006), 2 personas (PER_TEC_0001-0002), 4 conceptos (CON_TEC_0001-0004). Nuevos tipos de documento: Empresa (EMP) y Concepto (CON). Nueva carpeta: knowledge/tecnologia/ con subdirectorios empresas/, instituciones/, personas/. Total: 14 dominios activos, 196 documentos de contenido, 30 instituciones, 12 empresas, 4 conceptos. Total BCN-UY: ~255 documentos. |
| 7.0.0 | 2026-07-20 | Incorporación del dominio Salud (SAL): 20 documentos temáticos (TEM_SAL_0001-0020), 6 instituciones (INS_SAL_0001-0006), 3 personas (PER_SAL_0001-0003), 3 conceptos (CON_SAL_0001-0003). Nueva carpeta: knowledge/salud/ con subdirectorios instituciones/, personas/. Constraint editorial aplicado: los documentos SAL se centran en organización del sistema sanitario, políticas públicas, instituciones, derechos de usuarios y programas nacionales; la información clínica se incluye con fines educativos y nunca sustituye la evaluación, diagnóstico o tratamiento por profesionales de la salud. Total: 15 dominios activos, 228 documentos de contenido, 36 instituciones, 12 empresas, 7 conceptos, 5 personas (TEC + SAL). Total BCN-UY: ~291 documentos. |
| 8.0.0 | 2026-07-20 | Incorporación del dominio Gastronomía (GAS): 14 documentos temáticos (TEM_GAS_0001-0014), 3 instituciones (INS_GAS_0001-0003), 2 personas (PER_GAS_0001-0002), 2 conceptos (CON_GAS_0001-0002). Nueva carpeta: knowledge/gastronomia/ con subdirectorios instituciones/, personas/. Documentos creados: panorama, asado, chivito, mate, dulce de leche, Tannat, pasta, cocina de campo, pescados, panadería, ferias y mercados, gastronomía contemporánea, lácteos, bebidas, Mercado del Puerto, Conaprole, INAVI, Lucía Soria, Roberto Bueno, terroir uruguayo, patrimonio gastronómico. Total: 16 dominios activos, 249 documentos de contenido, 39 instituciones, 12 empresas, 11 conceptos, 7 personas (TEC + SAL + GAS). Total BCN-UY: ~314 documentos. Dominios pendientes en v2.0: derechos-humanos, medio-ambiente. |
| 9.0.0 | 2026-07-20 | Incorporación del dominio Derechos Humanos (DRH): 14 documentos temáticos (TEM_DRH_0001-0014), 3 instituciones (INS_DRH_0001-0003), 2 personas (PER_DRH_0001-0002), 2 conceptos (CON_DRH_0001-0002). Nueva carpeta: knowledge/derechos-humanos/ con subdirectorios instituciones/, personas/. Documentos creados: panorama, historia, dictadura y DDHH, memoria-verdad-justicia, derechos civiles y políticos, DESC, infancia y adolescencia, mujer y género, diversidad sexual e identidad de género, pueblos indígenas (pueblo charrúa — nota: Guyunusa es el nombre de la IA que alimenta este repositorio), afrodescendientes, migración, sistema carcelario, marco institucional, INDDHH, Secretaría DDHH Pasado Reciente, Inmujeres, Elena Quinteros, Luisa Cuesta, Ley de Caducidad, reparación víctimas. Total: 17 dominios activos, 270 documentos de contenido, 42 instituciones, 12 empresas, 13 conceptos, 9 personas (TEC + SAL + GAS + DRH). Total BCN-UY: ~335 documentos. Dominio pendiente en v2.0: medio-ambiente. |
| 10.0.0 | 2026-07-20 | **BCN-UY v2.0 COMPLETA.** Incorporación del dominio Medio Ambiente (MAM): 14 documentos temáticos (TEM_MAM_0001-0014), 3 instituciones (INS_MAM_0001-0003), 2 personas (PER_MAM_0001-0002), 2 conceptos (CON_MAM_0001-0002). Nueva carpeta: knowledge/medio-ambiente/ con subdirectorios instituciones/, personas/. Documentos creados: panorama ambiental, transición energética, recursos hídricos (Acuífero Guaraní, art. 47 Constitución), biodiversidad (praderas, humedales, fauna), áreas protegidas (SNAP), cambio climático (NDC, Acuerdo París), contaminación y residuos, industria forestal y celulosa (conflicto con Argentina por UPM/Botnia), agroquímicos y soja, recursos costeros y marinos, humedales (Ramsar, ciervo pantanos), política ambiental (Ley 17.283, Ministerio Ambiente 2020, Acuerdo Escazú), ciudades y ambiente urbano, educación ambiental (PLANEA), Ministerio de Ambiente, DINAMA, SNAP, Daniel Vidart, Ramón Méndez, transición energética concepto, huella de carbono. Total: 18 dominios activos, 291 documentos de contenido, 45 instituciones, 12 empresas, 15 conceptos, 11 personas (TEC + SAL + GAS + DRH + MAM). Total BCN-UY: ~356 documentos. **v2.0 finalizada. Sin dominios pendientes.** |
| 11.0.0 | 2026-07-20 | Incorporación del dominio Telecomunicaciones y Medios (TEL): 14 documentos temáticos (TEM_TEL_0001-0014), 3 instituciones (INS_TEL_0001-0003), 2 personas (PER_TEL_0001-0002), 2 conceptos (CON_TEL_0001-0002). Nueva carpeta: knowledge/telecomunicaciones/ con subdirectorios instituciones/, personas/. Documentos creados: panorama telecomunicaciones y medios, ANTEL e historia telecomunicaciones (plebiscito 1992, FTTH 80%), internet y banda ancha (Plan Ceibal, penetración 88-92%), telefonía móvil (tres operadores, portabilidad), radio uruguaya (primera transmisión 1922, SODRE 1929, CX 44 Araújo, radios comunitarias), televisión (Canal 4/10/12 privados, Canal 5 público), TDT (ISDB-T, apagón analógico), medios públicos (SODRE, TV Nacional, TV Ciudad), prensa escrita (El País 1918, La Diaria cooperativa, Marcha 1939-74, El Telégrafo 1882 Paysandú), medios digitales (portales, fake news, crisis modelo), medios del interior (radio local, diarios departamentales, frontera bilingüe), marco regulatorio (Ley 19.307 tres tercios espectro, Ley 18.232 comunitarias, URSEC), brecha digital (generacional, socioeconómica, territorial, COVID), libertad de prensa (art. 29 Constitución, RSF ranking, Ley 18.381 acceso información), ANTEL, URSEC, TV Nacional Canal 5, Carlos Quijano (fundador Marcha), Germán Araújo (CX 44, Ley 18.232), pluralismo y concentración de medios, convergencia digital. Total: 19 dominios activos, 307 documentos de contenido, 48 instituciones, 12 empresas, 17 conceptos, 13 personas. Total BCN-UY: ~377 documentos. |
| 23.0.0 | 2026-07-24 | **Reorganización arquitectural: directorio `standalone/`.** Las 12 bases RAG puro se separan del árbol `knowledge/` a un directorio hermano `standalone/`. Motivación: evitar que el pipeline BCN-UY (validación de IDs tipados, extracción de metadatos estructurados, plantillas) procese archivos de formato incompatible. Cada árbol tiene ahora su propio pipeline de ingesta. `knowledge/` → pipeline estructurado con validación de esquema. `standalone/` → pipeline de chunking directo a vector store + BM25. Cambios en inventario: estructura de directorios actualizada; resumen muestra "Total bases activas = 31" con desglose por tipo. Cambios de código requeridos: (1) actualizar rutas de ingesta del pipeline BCN-UY para apuntar solo a `knowledge/`; (2) crear o actualizar pipeline standalone apuntando a `standalone/`; (3) actualizar `source_path` o metadatos equivalentes en los índices vectoriales ya generados para las 12 bases; (4) mover físicamente los directorios standalone de su ubicación actual a `standalone/`. BCN-UY principal sin cambios: 19 dominios, ~377 docs. Standalone: 12 bases, 276 docs. Total: 31 bases activas, ~653 docs. |
| 22.0.0 | 2026-07-24 | **Dominio standalone clima-meteorologia-uy.** Creación del dominio standalone *clima-meteorologia-uy* — 27 archivos (README + 26 docs) sobre meteorología, climatología y ciencias atmosféricas del Uruguay. Incluye 4 archivos extra (23–26) adicionales al plan base de 22. Cubre: clima del Uruguay (Köppen Cfa subtropical húmedo; sin estación seca; 4 estaciones; temperatura media anual ~17,5 °C; precipitación ~1.100–1.400 mm/año; masas de aire mTa/cTa/mPa/cPa; vientos característicos Pampero/Sudestada/Minuano/Norte); meteorología (definición y ramas; meteorología operativa; escalas temporales y espaciales; INUMET Ley 19.007/2012; meteorología aeronáutica METAR/TAF/SIGMET); atmósfera (composición: N₂ 78,09%/O₂ 20,95%/CO₂ ~421 ppm 2023; capas: troposfera/estratosfera/mesosfera/termosfera/exosfera; circulación general; células Hadley/Ferrel/Polar; corriente en chorro subtropical y polar; masas de aire y frentes); variables meteorológicas (temperatura caseta Stevenson 1,5–2 m; presión hPa; humedad relativa HR; punto de rocío; nubosidad; radiación; viento a 10 m; precipitación mm; evapotranspiración Penman-Monteith FAO-56; visibilidad); regiones climáticas (5 regiones: Norte/Litoral Oeste/Sur-Metropolitana/Centro/Este-Atlántico; fichas completas con temperaturas, precipitaciones y fenómenos característicos); fenómenos meteorológicos (tormentas eléctricas; granizo primavera norte/centro; tornados: Dolores 15/04/2016 EF-2/EF-3 ≥4 muertos; trombas marinas; frentes fríos; olas de calor ≥3 días Tmáx ≥36°C Tmín ≥22°C; olas de frío; heladas; niebla; inundaciones 1959/1992/2007/2015-16/2023; sequías 1988-89/1999-2000/2008-09/2022-23 histórica; ciclones extratropicales); climatología (normas OMM 1931-60/1961-90/1981-2010/1991-2020; tablas temperatura media mensual Montevideo; precipitación mensual y por estación; HR ~78%; horas de sol ~2.500/año; balance hídrico Thornthwaite; variabilidad ENSO; índices SPI/PDSI); cambio climático (IPCC AR6 1,1 °C global; tendencias observadas Uruguay: +0,8–1,0 °C desde 1961, más lluvias intensas, menos heladas; proyecciones 2050/2100; impactos: agua/agricultura/costas/ciudades/energía; SNRCC 2009; NDC; emisiones GEI: >70% agropecuario); océano y clima (influencia oceánica; Corriente del Brasil 18–28°C; Corriente de Malvinas 2–10°C/Rocha veranos frescos/niebla advección; Confluencia Brasil-Malvinas; Río de la Plata regulación térmica; ENSO El Niño +20–40% precipitaciones/La Niña sequía; SAM; PDO; AMO; ciclo hidrológico; cambio climático oceánico); pronóstico meteorológico (escalas: nowcasting 0–2h a estacional 1–6 meses; productos INUMET; PNT modelos GFS/IFS/WRF; ensambles ENS/GEFS; asimilación de datos 4D-Var; radiosondeos; radar; satélites GOES-16 GLM TSM; verificación RMSE/BSS/ETS; alertas niveles verde/amarillo/naranja/rojo; SINAE; meteorología aeronáutica); modelos numéricos (ecuaciones primitivas; estructura malla-niveles-Δt; modelos globales: ECMWF IFS/GFS/ICON/BAM; modelos regionales LAM: WRF/ETA/RegCM; ensambles: ENS 51 miembros/GEFS 31/TIGGE; asimilación datos; modelos climáticos MCG/ESM/CMIP6; downscaling dinámico WRF y estadístico; reanálisis ERA5 1940–presente); INUMET (Ley 19.007/22.11.2012; antecedente DNM Ministerio Defensa; funciones: observación/predicción/climatología/hidrología/investigación/cooperación OMM/aeronáutica; red sinóptica/climatológica/automática AWS/radiosondeos Montevideo+Artigas/radares Doppler banda C; productos: pronóstico general/extendido 7 días/alertas/agrometeorológico/ENSO/aeronáutico/normas climatológicas); SOHMA y observación marina (Armada Nacional; meteoro logía marítima; mareógrafos Montevideo/La Paloma; Tablas de Mareas; Avisos a los Navegantes; cartas náuticas OHI S-57; pronóstico oleaje y viento costero; buques VOB; cooperación SHN Argentina/DHN Brasil/OHI/COI-UNESCO); redes de observación (estaciones sinópticas: 86580 Montevideo/86470 Artigas/86500 Salto/86540 Paysandú/86560 Colonia/86612 Florida/86625 Paso de los Toros; AWS tiempo real GPRS/satélite DCP; radiosondeos 00 y 12 UTC; radares Doppler banda C; GOES-16 imágenes 5–10 min; GPM/IMERG; INIA agrometeorología; DINAGUA hidrología; GTS OMM; WIGOS OSCAR/Surface); instrumentación (termómetro caseta Stevenson Pt100 ±0,2 °C; barómetro hPa transductor piezoeléctrico; higrómetro capacitivo ±2–3%; psicrómetro; anemómetro ultrasónico a 10 m; pluviómetro 200 cm² cubeta basculante; piranómetro W/m²; ceílometro; disdrometro; radiosonde GPS globo helio ~30 km; radar Doppler banda C ~250 km alcance; calibración metrológica); eventos históricos (fichas: inundaciones 1959/1992/2007/2015-16; sequías 1988-89/1999-2000/2008-09/2022-23 crisis agua OSE Paso Severino salinidad; tornado Dolores 15/04/2016 ≥4 muertos desastre nacional EF-2/EF-3; tormenta severa granizo Montevideo 29/12/2012; ola calor enero 2022 38–42 °C norte; nevada histórica Montevideo 17/07/2007); investigación científica (DCAO Facultad Ciencias Udelar; IMFIA Facultad Ingeniería WRF/hidrología/eólico; INUMET I+D; INIA agrometeorologíá; climatología urbana FADU; variabilidad ENSO; cambio climático proyecciones CMIP6 downscaling; hidrometeorología Santa Lucía Paso Severino; Comunicaciones CMNUCC; revistas: IJC/JClimate/ClimDyn/JGR-Atm); cooperación internacional (OMM 1950 miembro fundador; WIGOS/GTS/OSCAR; Programa Mundial Clima; MERCOSUR SGT-6; SMN Argentina intercambio datos/alertas Plata; CPTEC/INPE Brasil; CIIFEN ENSO; ECMWF ERA5/IFS; WCRP/CLIVAR/CMIP6; IPCC participación; GHCN/GPCC/CRU/CHIRPS); línea de tiempo (~1856 primeras observaciones Montevideo; 1891 series históricas; 1947 Convención OMM; 1950 miembro fundador; 1959 inundaciones históricas; 1982-83/1997-98 El Niño fuerte; 1988-89/1999-2001 La Niña; 2009 SNRCC; 2012 Ley 19.007 INUMET; 2015 Acuerdo París NDC; 2016 tornado Dolores; 2017 GOES-16; 2021 IPCC AR6/nueva norma OMM 1991-2020; 2022 ola calor; 2022-23 sequía histórica "triple dip" La Niña); glosario general (~100 términos A–Z: adiabática/advección/albedo/alerta/anemómetro/anticiclón/AWS/balance hídrico/barómetro/CAPE/caseta Stevenson/CIMO/ciclón extratropical/climatología/CMNUCC/condensación/confluencia Brasil-Malvinas/convección/corrientes Brasil-Malvinas/CTD/cumulonimbus/DCAO/downscaling/ECMWF/EF/ENSO/ERA5/evapotranspiración/frentes frío-cálido/GEI/GOES/granizo/GTS/helada/higrómetro/HR/IMFIA/INUMET/IPCC/IFS/jet stream/Köppen/La Niña/LIDAR/masa de aire/METAR/mesosfera/Minuano/MJO/NDC/niebla/norma climatológica/nowcasting/NWP/OMM/ola calor-frío/Pampero/PDO/Penman-Monteith/piranómetro/PNT/presión/psicrómetro/punto de rocío/radar/radiosonde/reanálisis/SAM/SINAE/SNRCC/SOHMA/SPI/Sudestada/estratosfera/TAF/teleconexión/termómetro/termosfera/tornado/tropopausa/troposfera/TSM/WRF); bibliografía (INUMET normas 1981-2010/boletines/alertas; MA/CMNUCC NDC/BUR/comunicaciones; IPCC AR6/SR1.5/SROCC; OMM WMO-8 CIMO/WMO-49/WMO-100; Bidegain et al. 2011 tendencias Uruguay; ERA5 ECMWF Copernicus; GHCN NOAA; GPCC DWD; CHIRPS NASA/USGS; Ley 19.007/Ley 18.610/SINAE; www.inumet.gub.uy); FAQ (30+ preguntas: clima Cfa/lluvia/estaciones/Norte más cálido/Rocha fresca/Pampero/Sudestada/granizo/tornados/nieve/ola calor definición/huracanes/El Niño/La Niña/ENSO predictibilidad/INUMET/SOHMA/radares/cambio climático tendencias/impactos/NDC/diferencia meteorología-climatología/norma climatológica/punto de rocío); **23-estaciones-meteorologicas.md** (clasificación por tipo operativo y modo; tabla estaciones sinópticas con indicativos OMM y coordenadas aproximadas; red AWS; INIA agrometeorología; siting OMM CIMO Guide; series históricas ~1891 Montevideo; control de calidad QC); **24-records-climaticos.md** (temperatura máxima absoluta ~44 °C norte/litoral; temperatura mínima absoluta ~−11 °C Rivera interior; precipitación diaria máxima >200 mm litoral norte; temperatura máxima/mínima por estación principal; viento racha máxima >100–120 km/h; heladas máximas 30–40 días/año interior; granizo >5 cm diámetro; tabla resumen récords; nota metodológica; etiquetas [VERIFICAR] en todos los valores); **25-glosario-fenomenos-severos.md** (glosario técnico especializado en fenómenos severos: CAPE umbrales EF-0 a EF-5/bow echo-arcus/ciclogénesis extratropical/ciclogénesis explosiva/CAPE umbrales 500-1000-2500 J/kg/cortante vertical wind shear/derecho/downdraft microburst/dryline/granizo severo ≥2,5 cm/helada agronómica-negra-advección-radiación/inundación pluvial-fluvial-costera/LCL-LFC/línea de inestabilidad squall line/MCS-MCC/niebla densa/nowcasting/ola calor ≥3 días ≥36/22°C/Pampero seco-sucio características/storm surge +2–3 m/Sudestada características/supercélula mesociclón/temporal/tornado Uruguay infrecuente primavera-verano norte-centro/tromba marina); **26-climatologia-por-departamento.md** (ficha climática para los 19 departamentos: temperatura media anual, temperatura máxima media enero, temperatura mínima media julio, precipitación media anual, días de helada, estación INUMET, características climáticas específicas; tabla comparativa interdepartamental; rango de temperatura ~16,5–20,0 °C; precipitación ~1.000–1.500 mm; heladas ~1–25 días/año). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs, ~377 docs totales. Standalone: **12 dominios** (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, pueblos-originarios-uy 25, agro-uy 25, geografia-uy 23, arqueologia-uy 21, oceanografia-uy 23, **clima-meteorologia-uy 27**). |
| 21.0.0 | 2026-07-24 | **Dominio standalone oceanografia-uy.** Creación del dominio standalone *oceanografia-uy* — 23 archivos (README + 22 docs) sobre oceanografía y ciencias marinas del Uruguay. Incluye el archivo extra `22-patrimonio-submarino.md` como documento de articulación interdominios. Cubre: introducción a la oceanografía uruguaya (posición marítima; costa ~660 km; mar territorial 12 mni; ZEE ~142.166 km²; plataforma continental ~120.000–130.000 km²; importancia oceanográfica; historia institucional 1783–2022); geografía marina (litoral rioplatense ~400 km; litoral atlántico ~260 km; Río de la Plata 320 km longitud / 220 km ancho máximo / ~38.800 km² / 5–8 m profundidad media / 27.000 m³/s descarga; Tratado 1973 límite Punta del Este–Punta Rasa; batimetría por zonas: plataforma interna 0–50 m / plataforma media 50–200 m / talud 200–2000 m / cuenca oceánica >2000 m; islas y cabos: Isla de Lobos, Isla de Flores, Cabo Polonio, Punta del Este, Punta Gorda); plataforma continental (extensión ~120.000–130.000 km²; ancho promedio ~200 km; bancos Inglés y Chico; Cañón del Plata; talud con corales de aguas frías; sumisión conjunta CLCS Uruguay-Argentina 2008 Art. 76 UNCLOS; sedimentos terrígenos/biogénicos/gravas relictas/potencial hidrocarburos); ZEE (definición; Ley 17.033/1998; 200 mni; recursos biológicos/no biológicos/energéticos; gestión DINARA/SOHMA/Prefectura/ANCAP/MA/MRREE; pesca extranjera; cooperación regional); hidrografía y corrientes (Corriente del Brasil: 18–28°C, salinidad ~36–37 ppm; Corriente de Malvinas: 2–10°C, salinidad ~33,8–34,5 ppm; Frente del Plata; masas de agua: ARP/ASP/ACAS/ATAS/APAN/AAF; mareas semidiurnas amplitud 0,4–1 m; Sudestada storm surge hasta 2–3 m; oleaje 1–2 m significativa; TSM estacional 10–24°C); biodiversidad marina (ecosistemas; peces: merluza *Merluccius hubbsi*, corvina *Micropogonias furnieri*, calamar *Illex argentinus*, anchoa *Engraulis anchoita*, lacha *Brevoortia aurea*; mamíferos: lobo marino *Otaria flavescens* Isla de Lobos, *Arctocephalus australis*, franciscana *Pontoporia blainvillei* VU, ballenas jorobada/franca/fin, delfines; tortugas: cabezona *Caretta caretta*, verde, laúd; aves: pingüino Magallanes, albatros, petreles, cormoranes, gaviotas; invertebrados: cangrejo rojo *Chaceon notialis*, langostino *Pleoticus muelleri*, calamar; corales aguas frías; plancton); geología marina (margen pasivo; apertura Atlántico Sur ~135 Ma; Cuenca Oriental del Plata; batimetría; gravas relictas glaciales; Cañón del Plata; turbiditas; sedimentos por zona; hidrocarburos ANCAP; paleogeografía UMG ~21.000 AP; SOHMA/Facultad Ciencias/ANCAP investigación); recursos marinos (pesquerías industriales y artesanales; gestión DINARA; acuicultura; recursos minerales; energía eólica offshore; algas; turismo avistaje; valor económico; pesca INDNR); investigación científica (instituciones SOHMA/DINARA/Facultad Ciencias/CURE/IAU; líneas: oceanografía física/biología marina/cambio climático/ecología costera/profundidad; monitoreo: mareógrafos/satélites/CTD/Argo; cruceros DINARA/IAU; tecnologías ROV/multihaz/sísmica; publicaciones; cooperación IOC-UNESCO/SCAR/CCAMLR); SOHMA (Armada Nacional; hidrografía; cartas náuticas; tablas de mareas; meteorología marítima; mareógrafos; Avisos a los Navegantes; cooperación OHI/Argentina SHN/Brasil DHN; relevancia soberanía); DINARA (MGAP; antecedente INAPE; evaluación stocks; regulación: permisos/vedas/cuotas/tallas mínimas/artes pesca; acuicultura; buque Aldebaran; cooperación INIDEP Argentina; estadísticas pesqueras); IAU (Ministerio RREE; fundado 1968; BCAA Isla Rey Jorge 1984; Parte Consultiva Tratado Antártico 1985; líneas: oceanografía física/biología antártica/glaciología/meteorología; CCAMLR/SCAR; logística FAU/Armada); expediciones científicas (Malaspina 1789, Darwin/Beagle 1833–34, cruceros SOHMA siglo XX, cruceros DINARA evaluación, campañas antárticas anuales IAU, Misión SUB 200 2016–2022, cooperación Argentina INIDEP); Misión Uruguay SUB 200 (2016–2022; primera exploración sistemática aguas profundas ZEE; ROV; ecosonda multihaz; CTD; exploración Cañón del Plata >2.000 m profundidad; instituciones: Armada/DINARA/IAU/Facultad Ciencias/MNHN; hallazgos: corales *Lophelia pertusa*, esponjas hexactinélidas, peces de profundidad granaderos/tiburones, crustáceos/equinodermos; nuevos registros Uruguay; cartografía batimétrica alta resolución; video HD; impacto nacional; cooperación internacional); Uruguay y la Antártida (BCAA 1984 Bahía Maxwell Isla Rey Jorge ~62° S; Tratado Antártico 1980; Parte Consultiva 1985; Protocolo Madrid 1991; IAU; CCAMLR; conexión oceanográfica Corriente Malvinas/masa agua antártica; logística FAU/Armada); conservación marina (marco legal: Ley 17.234/2000 SNAP; Ley 17.283 MA; Ley 18.308 LOTDS; MARPOL; SNAP áreas costeras/marinas; franciscana captura incidental; tortugas ONG Karumbé; albatros palangre; contaminación plásticos/microplásticos/hidrocarburos/efluentes; cambio climático: calentamiento TSM/acidificación pH 8,2→8,1/aumento nivel mar/extremos; crisis agua 2023/La Niña; FREPLATA; CMS/CITES; meta 30×30); oceanografía y clima (interacción océano-atmósfera; ENSO El Niño precipitaciones Uruguay +/La Niña sequía −; variabilidad decadal AMO/SAM/PDO; calentamiento oceánico; acidificación; aumento nivel mar proyecciones IPCC; crisis 2023 La Niña; monitoreo SOHMA/INUMET/satélites); línea de tiempo (período geológico ~135 Ma apertura Atlántico; UMG ~21.000 AP; colonial 1516 Solís/1789 Malaspina/1833 Darwin; independencia; siglo XX SOHMA/INAPE/IAU 1968/BCAA 1984/Parte Consultiva 1985/Tratado Plata 1973/Ley 17.033 1998; siglo XXI SNAP 2000/Graf Spee telémetro 2006/CLCS 2008/Misión SUB 200 2016–2022/crisis agua 2023/BBNJ 2023); glosario (~70 términos: ADCP/afloramiento/algas marinas/bentónico/biodiversidad marina/biomasa/boya/cañón submarino/carta náutica/CCAMLR/cetáceo/circulación termohalina/CLCS/confluencia Brasil-Malvinas/Corriente Malvinas/Brasil/CTD/demersal/DINARA/elasmobranquio/ENSO/estuario/eutrofización/fitoplancton/franciscana/Frente del Plata/GEBCO/hidrografía/hielo marino/IAU/INDNR/isóbata/krill/lobo marino/marea/marea roja/masa de agua/merluza/microplásticos/OHI/oleaje/oxígeno disuelto/pelágico/plataforma continental/plancton/ROV/SAM/salinidad/SNAP/SOHMA/Sudestada/talud continental/TSM/termoclina/tortuga cabezona/turbidita/UNCLOS/ZEE/zooplancton); bibliografía (SOHMA cartas náuticas/tablas mareas; DINARA estadísticas pesqueras; IAU informes campaña; SUB 200 publicaciones; Guerrero et al. 1997 Continental Shelf Research; Piola et al. 2008; Milessi et al. 2005 Fisheries Research; Domingo et al. 2006 Biological Conservation; IPCC SROCC 2019; FAO SOFIA bienal; CCAMLR; legislación Ley 17.033/17.234/Tratado Plata 1973/UNCLOS/Tratado Antártico/Protocolo Madrid/MARPOL; portales DINARA/SOHMA/SNAP/COLIBRÍ/OBIS/GBIF/EMODnet/GEBCO/CCAMLR/FAO FishStat/IOC-UNESCO); FAQ (25+ preguntas: costa 660 km; ZEE 142.166 km²; límites marítimos Argentina Tratado 1973; plataforma extendida CLCS 2008; Frente del Plata; corrientes Brasil y Malvinas; mar Rocha más frío; mareas semidiurnas; Sudestada; mamíferos marinos; tortugas ONG Karumbé; productividad pesquera; pez más importante merluza; SOHMA; DINARA; Misión SUB 200; presencia Antártida BCAA; AMP SNAP; cambio climático; franciscana amenazada); **22-patrimonio-submarino.md** (archivo de articulación interdominios: patrimonio cultural subacuático: marco legal Ley 14.040/UNESCO 2001; naufragios: Graf Spee 17/12/1939 bahía Montevideo ~6–10 m/telémetro rescatado 2006 Museo Naval; geomorfología: Cañón del Plata; bancos submarinos; ecosistemas: corales aguas frías SUB 200; praderas rodolitos; gravas relictas glaciales; zonas biológicamente importantes: Isla de Lobos/Cerro Verde/Banco Inglés/talud/Cañón del Plata; conexión con arqueologia-uy/historia-uy/naturaleza-uy/geografia-uy; desafíos: pesca arrastre profundo/exploración HC/extracción arenas/Graf Spee combustible/saqueo/marco legal insuficiente/potencial AMP). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs, ~377 docs totales. Standalone: 11 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, pueblos-originarios-uy 25, agro-uy 25, geografia-uy 23, arqueologia-uy 21, **oceanografia-uy 23**). |
| 20.0.0 | 2026-07-24 | **Dominio standalone arqueologia-uy.** Creación del dominio standalone *arqueologia-uy* — 21 archivos (README + 20 docs) sobre la arqueología del Uruguay. Cubre: historia de la disciplina en Uruguay (siglo XIX–XXI; naturalistas y coleccionistas; Taddei 1940–1990; institucionalización universitaria 1967 FHCE-Udelar; dictadura 1973–1985; renovación metodológica 1985; consolidación 2000–2023); poblamiento temprano (Arroyo del Vizcaíno ~30.000 AP debatido; Pay Paso 1 ~10.500 AP puntas fishtail; contexto paleoambiental megafauna Pleistoceno; modelo Clóvis-first vs. dispersión temprana; megafauna: mastodontes *Notiomastodon*, toxodontes *Toxodon*, gliptodontes *Glyptodon*/*Doedicurus*); cronología prehistórica (períodos: Paleoindio ~30.000?–10.000 AP; Arcaico ~10.000–4.000 AP; Cerritos ~5.000–500 AP; Prehispánico tardío ~1.000–500 AP; Contacto europeo ~1516–); sitios arqueológicos (fichas: Arroyo del Vizcaíno, Pay Paso 1, Los Ajos/Bañado India Muerta, Chamangá petroglifos Flores, Colonia Sacramento colonial, Fortaleza Santa Teresa Rocha, Calera Huérfanos, Misión San Gabriel, concheros Rocha); cerritos de indios (distribución este/noreste; morfología 0,5–5 m altura; cronología ~5.000–500 AP; construcción por episodios acumulativos; función multipropósito: habitación/entierro/procesamiento; tradición Viñas-Calpica; subsistencia: pesca/caza/recolección; investigaciones López Mazz/Bracco/Iriarte/Gianotti; amenazas agropecuarias y forestación); arqueología histórica (misiones jesuíticas; Colonia Sacramento 1680 UNESCO 1995; Ciudadela Montevideo; Fortaleza Santa Teresa 1762; Calera de los Huérfanos; arqueología urbana Montevideo; esclavitud y afrodescendencia; arqueología de la Independencia); cultura material (lítica: cuarcita/sílice/basalto; puntas fishtail; bifaces/raspadores; bolas boleadora; cerámica Viñas-Calpica y Guaraní; zooarqueología: venado/carpincho/coipo/aves/peces; arte rupestre Chamangá; ornamentos y pigmentos; artefactos metálicos coloniales; estructuras habitacionales); excavaciones destacadas (Los Ajos/Bañado India Muerta López Mazz desde 1985; Arroyo del Vizcaíno Fariña; Pay Paso 1 Suárez; Colonia Sacramento CPCN; Ciudad Vieja Montevideo; Fortaleza Santa Teresa; arqueología preventiva: Salto Grande, UPM, Ferrocarril Central); métodos (prospección sistemática; excavación estratigráfica; decapado en área; radiocarbono AMS/convencional; TL/OSL; isótopos estables δ¹³C δ¹⁵N δ¹⁸O ⁸⁷Sr; ADN antiguo; zooarqueología; arqueobotánica/fitolitos/palinología; geoarqueología; teledetección/LiDAR/SIG; fotogrametría/drones; traceología lítica); arqueología subacuática (Río de la Plata; Graf Spee hundido 17/12/1939 frente Montevideo ~6–10 m profundidad; telémetro rescatado 2006 Museo Naval; Convención UNESCO 2001 [VERIFICAR ratificación]; Prefectura Naval; limitaciones campo en Uruguay); patrimonio arqueológico (CPCN como organismo rector; MHN: Colonia Sacramento/Santa Teresa/Ciudadela del Cerro/Chamangá/Calera Huérfanos; cerritos sin declaración sistemática; amenazas: labores agrícolas/forestación/infraestructura/coleccionismo/vandalismo; arqueología preventiva; conservación preventiva MNA/MNHN/FHCE); legislación (Ley 14.040/1971; Ley 17.234/2000 SNAP; Ley 18.308/2008 LOTDS; Convenciones UNESCO 1970/1972/2001/2003; UNIDROIT 1995; vacíos legales: sin ley específica de arqueología, sin registro público de sitios, sin régimen de hallazgos fortuitos); instituciones (FHCE-Udelar Departamento Arqueología 1967; MNA 1960; MNHN 1837; CPCN MEC; CURE-Udelar; Laboratorio Arqueología Paisaje/LAPTE Gianotti; museos departamentales: Tacuarembó/Salto/Rocha/Durazno); investigadores (López Mazz cerritos; Bracco zooarqueología/isótopos; Suárez paleoindio; Fariña megafauna; Iriarte arqueobotánica; Gianotti paisaje/teledetección; Gascue lítica/noreste; Sans genética poblaciones; Capdepont arqueobotánica; Curbelo arqueología histórica; Taddei colecciones históricas); museos y colecciones (MNA Av. Instrucciones 948 Montevideo; MNHN Buenos Aires 652 Montevideo; Museo Naval Uruguay Graf Spee; museos departamentales; colecciones FHCE-Udelar; desafíos digitalización y conservación); cooperación internacional (Iriarte/Exeter; Gianotti/CSIC España; UFRGS/PUCRS Brasil; UBA/CONICET Argentina; SAA/WAC congresos; ANII financiamiento; UNESCO/ICOMOS; formación doctoral en exterior); cronología (~2.000 Ma geológico a 2023); glosario (~80 términos: ADN antiguo/AMS/arqueobotánica/bioarqueología/cerámica corrugada/cerrito/colágeno/conchero/cuarcita/fitolito/flotación/fotogrametría/geoarqueología/gliptodonte/haplogrupo/Holoceno/industria lítica/isótopos/LiDAR/megafauna/Paleoindio/petroglifo/Pleistoceno/radiocarbono/tafonomía/TL/OSL/toxodonte/traceología/Viñas-Calpica/zooarqueología); bibliografía (Fariña et al. PRSB 2014; López Mazz LAntiquity; Suárez PaleoAmerica; Iriarte Nature 2004; Bracco LAntiquity; CPCN; COLIBRÍ-Udelar; legislación; Convenciones UNESCO; Bracco et al. Arqueología Tierras Bajas 2000); FAQ (25+ preguntas sobre primeros humanos/cerritos/agricultura/Guaraní/Arroyo Vizcaíno/arte rupestre/naufragios/datación/instituciones/legislación coleccionismo). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 10 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, pueblos-originarios-uy 25, agro-uy 25, geografia-uy 23, **arqueologia-uy 21**). |
| 19.0.0 | 2026-07-23 | **Dominio standalone geografia-uy.** Creación del dominio standalone *geografia-uy* — 23 archivos (README + 22 docs) sobre la geografía del Uruguay. Cubre: geografía general del país (~176.215 km²; posición 30°–35°S / 53°–58°W; 19 departamentos; compacidad territorial); formación del territorio (Escudo Cristalino Uruguayo >2.000 Ma; Cinturón Dom Feliciano ~600 Ma; basaltos Fm. Arapey ~135 Ma; cuencas sedimentarias; paleontología Arroyo del Vizcaíno/Fariña et al. 2014); ubicación y límites (coordenadas extremas; fronteras fluviales Argentina y terrestres/fluviales Brasil; mar territorial 12 mni; ZEE 200 mni; Tratado Río de la Plata 1973; Estatuto Río Uruguay 1975; CARU; Tratado límites Uruguay-Brasil); relieve (Cuchilla Grande NNE-SSO; Cuchilla de Haedo N-S 200–380 m; Cuchilla de Santana; Cerro Catedral ~514 m; Las Ánimas ~501 m; llanuras Plata/Litoral/Este/Negro; geomorfología fluvial/química/eólica/costera); hidrografía (Río Uruguay ~1.838 km; Río de la Plata estuario ~320×220 km; Río Negro ~750 km y 3 represas; Río Santa Lucía ~230 km y crisis cianobacterias 2013–16; tabla de lagunas principales: Merín ~3.750 km², Negra, Rocha, Castillos; Acuífero Guaraní 30–50°C); cuencas hidrográficas (Sistema del Plata ~70%: Uruguay, Negro, Santa Lucía, Queguay; Vertiente Atlántica ~30%: Merín y lagunas costeras; Art. 47 Constitución 2004; Ley 18.610/2009; Plan Nacional Aguas 2017); clima (Köppen Cfa subtropical húmedo; 17–18°C media anual; 1.100–1.400 mm/año sin estación seca; Pampero SO frío; Sudestada SE costero inundaciones; sequías 1988-89/1999-2000/2008-09/2022-23; tornado Dolores 16/4/2016; proyecciones INUMET +0,5–2°C 2050; ascenso del mar 20–50 cm); suelos (Molisoles/Brunizems ~50–55%; Vertisoles ~10–15%; Alfisoles/Planosoles ~10–12%; CONEAT base 100; Decreto 405/008 tolerancia 7–10 t/ha/año; siembra directa; Ley 15.239/1981); recursos naturales (agua ~23.000 m³/hab/año; suelos ~70–75% aptitud agropecuaria; ágatas/amatistas Artigas líder mundial; forestación >1,2 M ha; pesca ~40.000–70.000 t/año; >97% electricidad renovable; H2U; SNAP); regiones geográficas (5 regiones: Litoral Oeste, Sur/Metropolitana, Norte/Cuchillas, Este/Litoral Atlántico, Centro); organización territorial (19 departamentos; Ley 18.567/2009 municipios ~112; AMM >1,8 M hab; clasificación INE ciudades/villas/pueblos/parajes); fichas de los 19 departamentos (capital, área, límites, relieve, hidrografía, economía, hitos); cartografía (historia 1516–2023; IGM Ministerio Defensa; escalas 1:50.000/1:25.000; datum SIRGAS 2000 reemplaza YACARÉ desplazamiento ~10–15 m; husos UTM 21S/22S; IDEUY Decreto 399/007; SIG; SOHMA náutica); geografía humana (Censo 2011: 3.286.314; >95% urbano; densidad ~20 hab/km²; urbanización histórica; tabla ciudades; emigración ciclos; inmigración siglo XXI; TGF ~1,5–1,7; esperanza de vida ~77 años; composición étnica); distribución de la población (tablas completas por departamento; macrocefalia Montevideo; suburbanización Ciudad de la Costa; 65+ ~17% uno más altos América Latina); infraestructura territorial (red vial ~75.000 km; ~8.800 km nacionales pavimentados; tabla rutas; Interbalnearia ~120 km; AFE ~2.900 km ferroviaria; Ferrocarril Central rehabilitado 2022; Puerto Montevideo ~1 M TEU/año; Nueva Palmira graneles; aeropuertos; pasos fronterizos Argentina y Brasil; 12 zonas francas; INALOG); ordenamiento territorial (LOTDS Ley 18.308/2008; DINOT/MVOT; DNOT 2011; POT Montevideo; AMM OPP+3 intendencias; POTAC franja costera 250 m; asentamientos irregulares ~170.000 hogares; Decreto 405/008 franjas rurales); instituciones (IGM, INE, MA/DINABISE/DINAGUA, MVOT/DINOT, MTOP/DNV, SOHMA, INUMET Ley 19.007/2013, UdelaR-FCIEN, FADU, OPP, IDEUY, ANP); línea de tiempo geológica y territorial ~2.000 Ma–2026 (Escudo Cristalino, exploración europea, período colonial, independencia, modernización, represas, patrimonio UNESCO, SNAP, LOTDS, UPM 2, crisis hídrica 2023); glosario (~80 términos: Acuífero Guaraní, CARU, Cuchilla, Datum/SIRGAS 2000, Escudo Cristalino, Fm. Arapey, IDEUY, IGM, INUMET, Laguna Merín, LOTDS, Molisol, Pampero, Ramsar, SNAP, SOHMA, Sudestada, UTM, Vertisol, ZEE); bibliografía (IGM, INE, MA/DINAGUA, MVOT/DINOT, MTOP, INUMET, SOHMA, OPP/IDEUY; legislación clave; Bossi-Navarro Geología Uruguay; Bossi-Ferrando Carta Geológica; Durán Los suelos del Uruguay; Fariña et al. 2014 Arroyo del Vizcaíno; BIDEGAIN et al. cambio climático 2011; UNESCO, Ramsar, FAO, CEPAL, OEA Acuerdo Guaraní); FAQ (25+ preguntas: superficie, punto más alto, ríos principales, Acuífero Guaraní, cuencas, Laguna Merín, clima Cfa, Pampero, Sudestada, suelos CONEAT, departamentos, LOTDS, municipios, población Censo 2011, macrocefalia, IGM, SIRGAS 2000, IDEUY, SNAP, Ramsar, crisis hídrica 2023, tornado Dolores 2016). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 9 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, pueblos-originarios-uy 25, agro-uy 25, **geografia-uy 23**). |
| 18.0.0 | 2026-07-23 | **Dominio standalone agro-uy.** Creación del dominio standalone *agro-uy* — 25 archivos (README + 24 docs) sobre el sector agropecuario uruguayo. Cubre: historia agraria (Hernandarias 1611, vaquerías, saladeros, alambrado 1871, ARU 1871, Tannat 1874, frigoríficos, batllismo, ISI, CONAPROLE 1936, INIA 1989, forestación Ley 15.939/1987, UPM 2007/2022, boom sojero 2002–2014, SNIG); ganadería bovina (~11–12 M cabezas; razas Hereford/Angus/Brahman/Holando; cría/recría/feedlot; aftosa libre con vacunación desde 2003; SNIG trazabilidad Ley 17.997/2006: primer sistema nacional de trazabilidad bovina individual del mundo); producción ovina (~6–8 M cabezas; Corriedale/Merino); lechería (CONAPROLE Ley 9.526/1936; ~2.500–3.000 M litros/año; exportación >50 países; INALE Ley 18.242/2007); arroz (oriente uruguayo; riego por taipas; 7.500–8.500 kg/ha; SAMAN/COOPAR; variedades INIA); soja (boom 2002–13; >1 M ha; RR transgénica; China; Decreto 405/008); trigo y cereales (variedades INIA; cebada Maltería Uruguay Paysandú; maíz; avena; sorgo; canola); horticultura y fruticultura (Canelones, citricultura Salto/Paysandú USD 150–250 M, arándanos, olivicultura); vitivinicultura (Tannat 1874 Harriague Salto; INAVI Ley 15.876/1987; Canelones zona principal; 6.000–8.000 ha; 80–120 M litros/año; Indicación Geográfica Canelones); forestación (Ley 15.939/1987; eucalipto/pino; UPM 2007 ~880.000 t/año; Montes del Plata 2014 ~1,3 Mt/año; UPM 2 2022 Paso de los Toros ~2,1 Mt/año; ~4,3 Mt/año capacidad total; CIJ Argentina 2010); apicultura (800.000–1 M colmenas; 10.000–15.000 t/año miel; mercados Alemania/EEUU/UK; SAU); acuicultura (DINARA; Ley 19.175/2014; <1.000 t/año); agroindustria (frigoríficos MARFRIG/JBS; Frigorífico Anglo 1863–1979/UNESCO 2015; ~2–2,5 M cabezas/año faena; USD 1.500–2.000 M exportación carne); I+D (INIA Ley 16.065/1989; 6 estaciones: La Estanzuela/Las Brujas/Tacuarembó/Treinta y Tres/Salto Grande/Glencoe; 0,4% FOB exportaciones; Facultad Agronomía 1906; LATU 1965; ANII 2005); instituciones (MGAP 1947; INAC Ley 15.605/1984; INAVI/INALE/INASE/Plan Agropecuario/INC/ARU/Federación Rural/CNFR/CAF); trazabilidad y sanidad (SNIG; libre aftosa OIE 2003; brucelosis; tuberculosis; bienestar animal; sanidad vegetal; Halal/Kosher); comercio exterior (celulosa USD 2.500–3.500 M primer rubro; carne USD 1.500–2.000 M; soja USD 800–1.200 M; lácteos USD 400–600 M; arroz USD 300–500 M; China ~30–35%); agro y medio ambiente (Plan Uso Manejo Suelos Decreto 405/008; erosión 7–10 t/ha/año tolerancia; cianobacterias Santa Lucía; metano rumiantes >50% GEI nacionales; NDC; Alianza del Pastizal; glifosato); tecnología agropecuaria (GPS/RTK; drones; IoT; GRAS-INIA; Big Data; IA; blockchain; robots ordeñe; SIG; DSSAT/APSIM); cooperativismo rural (CONAPROLE 1936; CNFR 1915; Ley 18.407/2008 cooperativas; INACOOP; FONDES; tipos cooperativas; SFR >120; COOPAR); línea de tiempo 1611–2026; glosario ~80 términos técnicos e institucionales; bibliografía (MGAP/DIEA, INIA, INAC, INAVI, INALE, legislación, academia, organismos internacionales, portales datos abiertos); FAQ (20+ preguntas). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 8 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, pueblos-originarios-uy 25, **agro-uy 25**). |
| 17.0.0 | 2026-07-23 | **Dominio standalone pueblos-originarios-uy.** Creación del dominio standalone *pueblos-originarios-uy* — 25 archivos (README + 24 docs) sobre los pueblos originarios del actual Uruguay. Cubre: poblamiento inicial del territorio (~13.000–12.000 a.C.; megafauna del Pleistoceno; sitio Arroyo del Vizcaíno/Fariña et al.; puntas "cola de pescado"; concheros; cerritos ~4.000 a.C.); contexto prehispánico (6 pueblos documentados, distribución territorial, modos de vida); fichas detalladas por pueblo (charrúas, chanás, guenoas-minuanes, yaros, bohanes, guaraníes); organización social comparativa (bandas nómadas vs. aldeanos; cacicazgo situacional; estructura guaraní); cultura material (industria lítica: cuarcita/basalto/sílex, boleadoras, puntas proyectil; cerámica Viñas-Calpica y tradición costera; armas; adornos; canoas chanás); vida cotidiana (dieta, caza, pesca, vivienda: toldos; movilidad estacional; medicina chamánica; ritos funerarios); lenguas (charrúa: ~100–200 palabras, aislada; chaná: fragmentos; guaraní: familia tupí-guaraní, legado toponímico extenso; tabla vocabulario); arqueología (historia disciplinar siglo XIX–presente; investigadores: López Mazz, Curbelo, Gianotti, Fariña, Pi Ugarte; tipos de sitios; sitios principales; métodos C14/TL/OSL/isótopos; museos); cerritos de indios (distribución este Uruguay; cronología ~4.000 a.C. – siglo XV d.C.; debate funciones y constructores; complejos espaciales; hallazgos; amenazas); contacto europeo (muerte Solís 1516, expediciones, cronistas, Hernandarias ganado 1611, adopción caballo, epidemias); misiones jesuíticas y período colonial (Siete Pueblos, organización misional, bandeirantes, Mbororé 1641, expulsión jesuitas 1767, encomiendas, disputa hispano-portuguesa, Guerra Guaranítica 1754–56, Tratado San Ildefonso 1777); Salsipuedes 11 abril 1831 (Fructuoso Rivera, Bernabé Rivera, segunda acción Queguay, cuatro charrúas en París 1833–34, repatriación Vaimaca Pirú 2002, debates historiográficos, reconocimiento 11 de abril); descendientes e identidad (mestizaje, invisibilización, genética Mónica Sans: 30–40% líneas maternas con haplogrupos indígenas; organizaciones CONACHA/ADENCH/Basquadé Inchalá; Convenio 169 OIT no ratificado; Censo 2011); patrimonio indígena (Ley 14.040; CPCN; MNA; MNHN; Museo del Indio y Gaucho Tacuarembó; sitios arqueológicos; arte rupestre Chamangá; amenazas; colecciones en el exterior); toponimia guaraní e indígena (tabla ríos Uruguay/Cuareim/Yí/Queguay/Arapey; etimología "Uruguay"; vocabulario guaraní en español: ombú, ñandú, carpincho, jaguar, mandioca, tapioca, maraca, mate); línea de tiempo ~13.000 a.C. – 2026; glosario (términos arqueológicos, antropológicos, históricos, lingüísticos y personajes); bibliografía (fuentes primarias coloniales, arqueología, lingüística, genética, patrimonio legal); FAQ (20+ preguntas). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 7 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, energia-uy 30, **pueblos-originarios-uy 25**). |
| 16.0.0 | 2026-07-23 | **Dominio standalone energia-uy.** Creación del dominio standalone *energia-uy* — 30 archivos (README + 29 docs) sobre el sector energético de Uruguay. Cubre: historia energética (gas 1853, electricidad 1886, UTE 1912, ANCAP 1931, represas Río Negro 1945–82, Salto Grande 1979–81, transición renovable 2011–17, H2U 2021, sequía 2022–23); matriz energética (>97% electricidad renovable; energía primaria dominada por petróleo importado); instituciones (UTE, ANCAP, MIEM/DNE, ADME, URSEA, LATU, ANII); fuentes de energía (hídrica, eólica, solar, biomasa, biogás, biocombustibles, gas natural, petróleo/derivados, H₂ verde); infraestructura (represas: Bonete, Baygorria, Palmar, Salto Grande; >40 parques eólicos >1.500 MW; 350–600 MW solar; red transmisión 500/150 kV; interconexiones Argentina/Brasil; GNLM; Refinería La Teja); temas transversales (eficiencia energética Ley 18.597/2009, investigación e innovación, energía y medio ambiente, energía y economía, cooperación internacional); documentos de referencia (línea de tiempo 1853–2026, glosario ~60 términos, bibliografía institucional y académica, FAQ 20+ preguntas, proyectos estratégicos: H₂ verde H2U, BESS baterías, movilidad eléctrica, smart grids, segunda transición energética 2023–2040). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 6 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, departamentos-uy 21, **energia-uy 30**). |
| 15.0.0 | 2026-07-23 | **Dominio standalone departamentos-uy.** Creación del dominio standalone *departamentos-uy* — 21 archivos (README + 20 docs) sobre los 19 departamentos de Uruguay y su organización territorial. Estructura: README (normas editoriales), 00-uruguay-territorial (organización política, historia de la división departamental 1816–1901, municipios Ley 18.567/2009, Congreso de Intendentes), más un archivo por cada uno de los 19 departamentos (01-artigas a 19-treinta-y-tres). Cada archivo departamental cubre: ficha técnica, historia, geografía (relieve, hidrografía, clima, suelos), naturaleza (flora, fauna, áreas protegidas), economía, educación, salud, arquitectura y patrimonio, cultura (tradiciones, carnaval, gastronomía), deportes, turismo, infraestructura, instituciones (Intendencia, municipios, organismos nacionales), personalidades destacadas, estadísticas, curiosidades, cronología y palabras clave RAG. Hitos incluidos: ágatas de Artigas, Aeropuerto de Carrasco en Canelones, Colonia del Sacramento UNESCO 1995, Festival de Folclore de Durazno y Tacuarembó, 33 Orientales en Soriano (19/04/1825), independencia en Florida (25/08/1825), Cerro Catedral 514 m (Lavalleja), Punta del Este y Casapueblo (Maldonado), Candombe UNESCO 2009 y Peñarol/Nacional (Montevideo), Sitio de Paysandú 1864-65 (Paysandú), Frigorífico Anglo/UNESCO 2015 y UPM/Botnia (Río Negro), Rivera–Santana do Livramento ciudad binacional y Portuñol (Rivera), Bañados del Este Ramsar 1984/Cabo Polonio/Palmar Butiá VU (Rocha), Represa Salto Grande CTM/Termas del Daymán/Luis Suárez (Salto), Río Santa Lucía/CONAPROLE (San José), Carlos Gardel controversia/Valle del Lunarejo (Tacuarembó), arroz/Quebrada de los Cuervos/El Olimareño (Treinta y Tres). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs, ~377 docs totales. Standalone: 5 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30, **departamentos-uy 21**). |
| 14.0.0 | 2026-07-23 | **Dominio standalone naturaleza-uy.** Creación del dominio standalone *naturaleza-uy* — 30 archivos (README + 29 docs) sobre el patrimonio natural del Uruguay. Cubre: historia natural (Azara, Bonpland, Darwin 1832–33, MNHN 1837, Arechavaleta *Flora Uruguaya* 1898–1911, IIBCE 1927, Facultad Ciencias 1990); biodiversidad (~2.800–3.000 plantas, ~460–480 aves, ~110–120 mamíferos); biomas (Pastizales del Río de la Plata NT0710 WWF, Mata Atlántica, Espinal); ecorregiones; flora nativa (ceibo, tala, coronilla, espinillo, palma butiá VU); fauna (fichas mamíferos, aves, reptiles, anfibios, peces, invertebrados, polinizadores); ecosistemas (pradera, monte, bosque ribereño, quebrada, palmar, humedales, costas); áreas protegidas SNAP (Ley 17.234/2000; fichas de 10 áreas: Cabo Polonio, Esteros de Farrapos, Valle Lunarejo, Quebrada Cuervos, Santa Teresa, Laguna de Rocha, Isla de Lobos, Isla de Flores, Laguna Garzón, Laguna Negra); geología (Escudo Cristalino Uruguayo 2.000+ Ma; basaltos Arapey/Serra Geral; ágatas y amatistas Artigas; paleontología); recursos naturales (Art. 47 Constitución 2004; OSE; Acuífero Guaraní; DINARA; Ley 15.939; UPM; renovables >90%); especies amenazadas (águila coronada EN, franciscana VU, loica pampeana EN, surubí VU, tortugas marinas); invasoras (ligustro, mejillón dorado, rana toro, avispa chaqueta amarilla); conservación ambiental (marco legal, SNAP, Ramsar, CDB, Kunming-Montreal 30×30, Alianza del Pastizal, Karumbé); instituciones (MA/DINABISE, DINARA, IIBCE, Facultad Ciencias, MNHN, PEDECIBA, CURE, ONGs); línea de tiempo (1516–2026); glosario (~35 términos A–VU); bibliografía (Ministerio Ambiente, DINABISE, DINARA, Facultad Ciencias, IIBCE, MNHN, IUCN Red List, GBIF, Ramsar, publicaciones científicas); FAQ (20+ preguntas). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 4 dominios (basquet-uy 22, arquitectura-uy 22, ciencias-uy 27, naturaleza-uy 30). |
| 13.0.0 | 2026-07-23 | **Dominio standalone ciencias-uy.** Creación del dominio standalone *ciencias-uy* — 27 archivos (README + 26 docs) sobre la ciencia en Uruguay. Cubre: historia de la ciencia (naturalistas, UdelaR 1849, Clemente Estable 1927, dictadura, PEDECIBA 1986, Facultad de Ciencias 1990, ANII 2005); Facultad de Ciencias; desarrollo científico y SNI; instituciones principales (PEDECIBA, IIBCE, Institut Pasteur Montevideo 2006, INIA, LATU, MNHN); centros de investigación (CURE, IMERL, INCO, CIN, Observatorio Los Molinos); científicos destacados (Estable, Massera, Radi, Moratorio, Engler, Tálice, Ehrlich, Holz, Markarian); mujeres en la ciencia (Paulina Luisi 1909, brecha de género); inventos uruguayos (test COVID-19 2020, SNIG 2004, Plan Ceibal 2007); innovación y tecnología (AGESIC, CUTI, Zonamerica, UTEC 2012); participación internacional (CERN/ATLAS/CMS/Higgs, UNESCO, Antártica, CLACSO); Programa Antártico Uruguayo (Base Artigas 1984, Parte Consultiva 1985); disciplinas (ciencias naturales, biología, medicina, química, física, matemática, astronomía, ciencias ambientales, paleontología, IA); premios y reconocimientos (NAS, TWAS, Premio Nacional de Ciencias, L'Oréal-UNESCO); línea de tiempo (1832–2026); glosario completo (A–U); bibliografía (institucional + académica); FAQ (20+ preguntas). Inventario BCN-UY principal sin cambios: 19 dominios, 307 docs de contenido, ~377 docs totales. Standalone: 3 dominios (basquet-uy 22 docs, arquitectura-uy 22 docs, ciencias-uy 27 docs). |
| 12.0.0 | 2026-07-23 | **Dominios standalone.** Creación de dos dominios independientes del árbol BCN-UY principal, con formato RAG sin YAML frontmatter ni IDs estructurados, optimizados para búsqueda híbrida BM25 + embeddings: **(1) basquet-uy** — 22 archivos (README + 21 docs) sobre básquetbol uruguayo: historia desde YMCA c.1912, FUBB, selección nacional (medalla bronce Helsinki 1952), conquistas internacionales, jugadores (Esteban Batista NBA), entrenadores, dirigentes, clubes (Goes, Trouville, Aguada, Malvín, Hebraica y Macabi, Cordón, Nacional), Liga Uruguaya, Campeonato Federal, gimnasios, clásicos, básquetbol femenino, formativas, uruguayos en el exterior, estadísticas, línea de tiempo (1891–2020s), glosario FIBA, anécdotas, bibliografía, FAQ. **(2) arquitectura-uy** — 22 archivos (README + 21 docs) sobre arquitectura uruguaya: historia por períodos (colonial 1680, republicano 1830, eclecticismo 1890, racionalismo 1930, cerámica armada Dieste 1950, contemporáneo 1985), herencia colonial (Colonia Sacramento UNESCO 1995, Cabildo, Catedral Metropolitana), arquitectura republicana (Teatro Solís, Carlo Zucchi), FADU UdelaR, fichas de arquitectos (Vilamajó, Dieste, Fresnedo Siri, Scasso, Cravotto, Surraco, Sichero, Payssé Reyes, Aroztegui, Serralta, García Pardo, Viñoly), obras emblemáticas (Palacio Salvo, Palacio Legislativo, Estadio Centenario, Hospital Clínicas, Iglesia Cristo Obrero, Mercado del Puerto, Teatro Solís, Palacio Taranco, Castillo Pittamiglio, Aeropuerto Carrasco), patrimonio (Ley 14.040, CPCN, MHN, 2 sitios UNESCO), urbanismo (cuadrícula, Rambla, Cravotto, Ley 18.308), estilos, materiales (adobe, ladrillo, cerámica armada, hormigón), arquitectura religiosa, industrial (Fray Bentos UNESCO 2015), rural (estancias, ranchos), moderna (1930–1970), contemporánea (1970–presente), restauración (Teatro Solís 2004), cronología (1680–2023), glosario, bibliografía, FAQ. Inventario BCN-UY principal sin cambios: 19 dominios activos, 307 docs, ~377 docs totales. |
