# Carnaval de Montevideo

## Descripción

El **Carnaval de Montevideo** es el **carnaval más largo del mundo**, con una duración oficial de aproximadamente **40 días** (desde fines de enero hasta principios de marzo). Es la celebración cultural más masiva y popular de Uruguay, con una infraestructura institucional, un sistema de competencia y un arraigo comunitario únicos en el mundo.

## Datos generales

| Dato | Información |
|------|-------------|
| Duración | ~40 días (el más largo del mundo) |
| Período | Fines de enero – principios de marzo |
| Organización | DAECPU + Intendencia de Montevideo |
| Escenario principal | Teatro de Verano Ramón Collazo (Parque Rodó) |
| Escenarios barriales | Tablados (distribuidos en barrios de Montevideo) |
| Participantes activos | Decenas de miles |
| Espectadores | Cientos de miles por temporada |

## Historia

### Orígenes coloniales (siglo XVIII)

Los primeros registros de celebraciones carnavalescas en Montevideo datan del período colonial (siglo XVIII). El Cabildo registraba quejas por los festejos callejeros y las mascaradas. Los **candombes** de la comunidad afrorioplatense eran el núcleo de las celebraciones populares.

### Siglo XIX: formación de las modalidades

Durante el siglo XIX se fueron consolidando las modalidades que definen el carnaval uruguayo:
- Las **comparsas de negros** (origen del candombe-comparsa)
- Las primeras **murgas** (de influencia española, especialmente gaditana)
- Los **mascarones** y las fiestas de disfraces de la clase alta

### Siglo XX: institucionalización

El Carnaval del siglo XX se fue sistematizando:
- Creación del **Teatro de Verano** como escenario central (1950s)
- Organización del concurso oficial por modalidades
- Creación de la **DAECPU** (Directores Asociados de Espectáculos del Carnaval y el Payaso del Uruguay) como organizadora

### Dictadura: censura del Carnaval (1973–1985)

Durante la dictadura, el Carnaval no fue prohibido pero fue sometido a **censura**. Las letras de murgas y cuplés debían ser aprobadas por las autoridades militares. Muchos artistas fueron vetados. A pesar de esto, el Carnaval funcionó como uno de los pocos espacios de expresión crítica relativa, con mensajes cifrados que el público descifraba.

### Retorno democrático: explosión carnavalera (1985–presente)

Con el retorno democrático, el Carnaval vivió una explosión de libertad expresiva. Las murgas se convirtieron en uno de los espacios más vibrantes de debate político y social en Uruguay.

## Organización

### DAECPU

La **DAECPU (Directores Asociados de Espectáculos del Carnaval y el Payaso del Uruguay)** es la organización que gestiona el concurso oficial del Carnaval de Montevideo. Organiza las actuaciones, establece el calendario, gestiona los premios y certifica las categorías.

### Intendencia de Montevideo

La **Intendencia de Montevideo** tiene un rol central en la organización del Carnaval: financia el Teatro de Verano, subsidia los tablados barriales y apoya a las agrupaciones con recursos.

## El sistema de tablados

Los **tablados** son los escenarios barriales del Carnaval de Montevideo. Distribuidos en decenas de barrios, permiten que las agrupaciones actúen en el entorno de sus propias comunidades. Los tablados son accesibles económicamente (entrada de bajo costo) y funcionan como espacios de socialización barrial durante el Carnaval.

El sistema de tablados es un elemento diferenciador del Carnaval montevideano: no se concentra exclusivamente en el gran teatro sino que se distribuye por toda la ciudad.

## Modalidades del Carnaval

### Murga

La **murga** es la modalidad más representativa e identitaria del Carnaval de Montevideo. Un conjunto de murga tiene **14 a 17 integrantes** y estructura su espectáculo en:

- **Presentación:** canción de apertura
- **Cuplés:** canciones satíricas sobre la actualidad
- **Retirada:** canción de despedida (frecuentemente emotiva y reflexiva)
- **Percusión:** bombo, platillos y redoblante

Las letras de murga abordan la política, la realidad social, los personajes del año y temas universales con agudeza satírica. Es uno de los géneros literario-musicales más característicos de Uruguay.

**Murgas históricas destacadas:**
- **Araca la Cana:** una de las más antiguas y respetadas
- **Los Patos Cabreros:** gran trayectoria
- **Falta y Resto:** innovadora; múltiples premios
- **La Reina de la Teja:** clásica del barrio Teja
- **Agarrate Catalina:** innovadora; gran repercusión fuera del Uruguay

### Candombe-Comparsa

Las **comparsas de candombe** son el corazón africano del Carnaval. Desfilan con **cuerdas de tambores**, bailarines (vedette, gramillero, escobero, mama vieja, bandera) y una estética de raíces afrouruguayas.

**Personajes arquetípicos de la comparsa:**
| Personaje | Descripción |
|-----------|-------------|
| **Vedette** | Bailarina principal |
| **Gramillero** | Anciano con bastón; figura curandera de la tradición |
| **Mama Vieja** | Mujer adulta que baila con abanico |
| **Escobero** | Malabares con escoba |
| **Bandera** | Portador de la enseña del grupo |

### Parodistas

Los **conjuntos parodistas** realizan parodias de obras teatrales, películas, eventos del año, personajes públicos o momentos históricos, con gran elaboración en vestuario y escenografía.

### Revista

Los **conjuntos de revista** ofrecen espectáculos con vestuario suntuoso, canto y baile, de influencia del teatro de revista europeo y latinoamericano.

### Humoristas

Los **conjuntos de humoristas** presentan sketchs cómicos, generalmente en formato de dúo o trío, con humor costumbrista, absurdo o político.

## El Teatro de Verano Ramón Collazo

El **Teatro de Verano Ramón Collazo** (Parque Rodó, Montevideo) es el escenario central del Carnaval oficial. Con capacidad para varios miles de personas, es donde se realizan las actuaciones del concurso oficial y donde se entregan los premios.

Ramón Collazo (1900–1970) fue un compositor y director musical uruguayo que impulsó el Carnaval durante décadas.

## El concurso oficial

El concurso oficial del Carnaval tiene categorías por modalidad. Los conjuntos compiten a lo largo de las semanas del Carnaval y los ganadores son coronados como campeones de su categoría. La **final de murgas** y la **final de comparsas** son los eventos más seguidos.

## Proyección internacional

El Carnaval de Montevideo ha trascendido las fronteras uruguayas:
- La **murga** es estudiada como género literario-musical único
- Grupos de murga actúan en festivales internacionales
- La murga ha generado escuelas y grupos en Argentina, España y otros países
- El Carnaval es objeto de estudio académico en universidades latinoamericanas y europeas

## Palabras clave

Carnaval Montevideo más largo mundo, Carnaval 40 días Uruguay, DAECPU Uruguay, murga uruguaya, candombe comparsa Carnaval, tablados barriales Montevideo, Teatro Verano Ramón Collazo Uruguay, Araca la Cana murga, Agarrate Catalina murga, Falta y Resto murga, parodistas uruguayos, revista Carnaval Uruguay, historia Carnaval Montevideo, censura Carnaval dictadura Uruguay, Carnaval post-dictadura Uruguay, personajes comparsa gramillero mama vieja, escobero candombe
