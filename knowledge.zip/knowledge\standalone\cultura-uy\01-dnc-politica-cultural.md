# Dirección Nacional de Cultura y Política Cultural del Estado Uruguayo

## Descripción

La **Dirección Nacional de Cultura (DNC)** es la unidad ejecutora del **Ministerio de Educación y Cultura (MEC)** responsable de formular y gestionar las políticas culturales nacionales de Uruguay. A través de sus instrumentos de fomento —principalmente el **FEFCA**— y sus organismos dependientes (INAE, INBA), el Estado uruguayo apoya la creación, formación y difusión artística en todo el país.

## Datos institucionales

| Dato | Información |
|------|-------------|
| Nombre completo | Dirección Nacional de Cultura |
| Sigla | DNC |
| Dependencia | Ministerio de Educación y Cultura (MEC) |
| Sede | Reconquista 535, Montevideo |
| Sitio web | www.gub.uy/ministerio-educacion-cultura (sección Cultura) |

## Historia de la política cultural uruguaya

### Batllismo y construcción del Estado cultural (1900–1930)

Las bases de la política cultural estatal uruguaya se establecieron durante el **batllismo** (presidencias de José Batlle y Ordóñez, 1903–1907 y 1911–1915). El Estado impulsó la creación del SODRE (1929), el teatro oficial, las orquestas y los espacios culturales públicos como instrumentos de la identidad nacional.

### Período de expansión institucional (1930–1970)

Entre 1930 y 1970, el Estado uruguayo consolidó su rol como mecenas cultural:
- Expansión del SODRE (radio, ballet, orquesta)
- Creación de museos nacionales
- Apoyo a la educación artística (INBA, IPA con especialidades artísticas)
- Apoyo a festivales, exposiciones y premios literarios

### Dictadura: supresión cultural (1973–1985)

La dictadura cívico-militar (1973–1985) tuvo un impacto devastador sobre la cultura uruguaya:
- **Censura** de libros, obras musicales, piezas teatrales y películas
- **Listas negras** de artistas, escritores y músicos
- Exilio de figuras clave: Mario Benedetti, Eduardo Galeano, Alfredo Zitarrosa, Los Olimareños, entre cientos
- Cierre de publicaciones culturales y espacios de debate
- Intervención y censura del Carnaval

### Retorno democrático y reconstitución (1985–2000)

Con la restauración democrática (1985), la cultura uruguaya vivió un **renacimiento intenso**. El regreso de los artistas exiliados, la proliferación de grupos teatrales y musicales, y la libertad de expresión recuperada generaron una efervescencia cultural notable.

### Institucionalización de la política cultural (2000–2026)

En el siglo XXI, la política cultural uruguaya se sistematizó:
- Creación del **ICAU** (Instituto del Cine y Audiovisual del Uruguay) en 2008
- Consolidación del **FEFCA** como instrumento de fomento
- Aprobación de la **Ley de Mecenazgo** para promover el aporte privado a la cultura
- Políticas de descentralización cultural hacia el interior mediante los **Centros MEC**

## Competencias de la DNC

- Formulación de políticas culturales nacionales
- Gestión del **FEFCA** (Fondo de Estímulo a la Formación y Creación Artística)
- Supervisión del **INAE** (Instituto Nacional de Artes Escénicas)
- Supervisión del **INBA** (Instituto Nacional de Bellas Artes)
- Coordinación con organismos culturales departamentales
- Relaciones con organismos internacionales de cultura (UNESCO, OEI)
- Políticas de diversidad cultural
- Gestión de espacios culturales dependientes del MEC

## FEFCA — Fondo de Estímulo a la Formación y Creación Artística

El **FEFCA** es el principal instrumento de financiamiento de la actividad artística y cultural gestionado por el MEC a través de la DNC.

### Líneas del FEFCA

| Línea | Descripción |
|-------|-------------|
| **Creación** | Subsidio para producción de obras artísticas inéditas |
| **Formación** | Becas para estudios artísticos en el exterior o en Uruguay |
| **Difusión** | Apoyo a giras, publicaciones, festivales y ciclos culturales |
| **Espacios culturales** | Apoyo a salas y centros culturales independientes |
| **Emergentes** | Apoyos especiales para artistas jóvenes o primeras obras |

### Disciplinas cubiertas

Teatro, danza, circo, música, artes visuales, literatura, fotografía, cine-video, diseño, artesanía, artes digitales.

### Convocatorias

El FEFCA convoca anualmente. Las postulaciones se realizan en línea a través del portal del MEC. Los montos varían según la línea y la categoría.

## INAE — Instituto Nacional de Artes Escénicas

El **INAE** es el organismo de la DNC/MEC que fomenta las artes escénicas uruguayas.

| Dato | Información |
|------|-------------|
| Áreas | Teatro, danza, circo y disciplinas afines |
| Actividades | Subsidios a grupos; gestión de espacios escénicos; formación |
| Relación con CFE | Articulación con la formación artística de ANEP |

## INBA — Instituto Nacional de Bellas Artes

El **INBA** promueve las artes visuales en Uruguay.

| Dato | Información |
|------|-------------|
| Áreas | Pintura, escultura, fotografía, artes gráficas, diseño |
| Actividades | Escuela Nacional de Bellas Artes (ENBA); exposiciones; concursos |

## Ley de Mecenazgo

Uruguay tiene una **Ley de Mecenazgo** que permite a empresas y personas físicas realizar aportes deducibles de impuestos a proyectos culturales aprobados por el MEC. Este instrumento busca diversificar el financiamiento de la cultura más allá del presupuesto público.

## Centros MEC como política de descentralización cultural

Los **Centros MEC** son nodos de acceso a la cultura y la educación en localidades del interior del país. Ofrecen actividades culturales (cine, teatro, música, talleres) en lugares sin acceso regular a estas expresiones, siendo un instrumento clave de la política de **equidad cultural territorial**.

## Palabras clave

Dirección Nacional de Cultura Uruguay, DNC MEC Uruguay, política cultural Uruguay, FEFCA fondo cultura Uruguay, INAE artes escénicas Uruguay, INBA bellas artes Uruguay, historia política cultural Uruguay, batllismo cultura Uruguay, dictadura censura cultura Uruguay, ICAU cine Uruguay, Ley Mecenazgo Uruguay, Centros MEC cultura Uruguay, descentralización cultural Uruguay, exilio cultural Uruguay dictadura, retorno democrático cultura Uruguay 1985
