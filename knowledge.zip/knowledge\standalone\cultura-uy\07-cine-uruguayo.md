# Cine Uruguayo

## Descripción

El **cine uruguayo** experimentó un desarrollo tardío pero acelerado desde fines de los años 90, alcanzando reconocimiento internacional a partir de los 2000. Uruguay es hoy uno de los países de América Latina con producción cinematográfica más activa en relación a su tamaño, con películas que han obtenido premios en los principales festivales del mundo.

## Historia

### Primeros registros y cine mudo (1898–1930)

Los primeros registros cinematográficos en Uruguay datan de **1898**, apenas tres años después de la invención del cinematógrafo. El cine mudo tuvo escasa producción local, aunque sí exhibición de filmes europeos y norteamericanos.

### Cine sonoro y primeras producciones (1930–1960)

El período sonoro vio algunas producciones locales pero sin industria consolidada. Los primeros documentales y cortos de tema nacional aparecieron en estas décadas. El **Instituto de Cinematografía de la Universidad de la República (ICUR)** —creado en 1949— fue el primer intento de institucionalizar el cine como arte y como estudio.

### Dictadura: represión y emigración (1973–1985)

La dictadura suprimió la libertad de expresión cinematográfica. Varios cineastas se exiliaron. La producción local se redujo al mínimo.

### Renacimiento: el nuevo cine uruguayo (1985–2000)

Con el retorno democrático comenzó un proceso lento de reconstrucción del cine. Aparecieron nuevos realizadores, festivales y espacios de exhibición independiente. El **Festival Cinematográfico Internacional del Uruguay** (organizado por la Cinemateca Uruguaya) fue un espacio central para la difusión del cine de arte.

### La explosión del cine uruguayo (2000–2026)

A partir de **2000**, el cine uruguayo experimentó un **boom** de calidad y proyección internacional:

- **"25 Watts" (2001)** de Juan Pablo Rebella y Pablo Stoll: primera película del nuevo cine uruguayo con repercusión internacional; Premio FIPRESCI en el Festival de Rotterdam
- **"Whisky" (2004)** de Juan Pablo Rebella y Pablo Stoll: ganó varios premios internacionales, incluyendo la Cámara de Oro del Festival de Cannes (sección Un Certain Regard)
- **"El Baño del Papa" (2007)** de César Charlone y Enrique Fernández: Oscar a la Mejor Película Extranjera (preselección)
- **"El Viaje al Mar" (2003)**
- **"La Demora" (2012)** de Rodrigo Plá: nominaciones internacionales
- **"El Lugar del Hijo" (2013)** de Manolo Nieto

## El ICAU — Instituto del Cine y Audiovisual del Uruguay

El **ICAU** es el organismo del Estado uruguayo responsable de apoyar, promover y regular la producción cinematográfica y audiovisual nacional.

| Dato | Información |
|------|-------------|
| Nombre completo | Instituto del Cine y Audiovisual del Uruguay |
| Sigla | ICAU |
| Creación | Ley 18.284 (2008) |
| Dependencia | Ministerio de Educación y Cultura (MEC) |
| Sitio web | www.icau.mec.gub.uy |
| Funciones | Financiamiento, promoción, regulación y preservación del audiovisual uruguayo |

### Instrumentos del ICAU

- **Fondo de Fomento del Cine y el Audiovisual:** principal mecanismo de financiamiento de largometrajes, cortometrajes y documentales nacionales
- **Fondo para Televisión:** apoyo a producciones para la TV pública y plataformas digitales
- **Apoyo a la participación en festivales:** financiamiento para presentar películas uruguayas en festivales internacionales
- **Regulación de cuotas:** cuotas de pantalla para cine uruguayo en salas comerciales

## Directores y figuras del cine uruguayo

| Director/a | Perfil / Obra |
|-----------|--------------|
| **Juan Pablo Rebella (1974–2006)** | Codirector de *25 Watts* y *Whisky*; murió trágicamente a los 32 años |
| **Pablo Stoll** | Codirector de *25 Watts* y *Whisky*; continúa su carrera |
| **César Charlone** | Director de fotografía y director; *El Baño del Papa*; director de fotografía de *Ciudad de Dios* (Brasil) |
| **Federico Veiroj** | *La Vida Útil*, *Acné*, *El Apóstata*; cine de autor con proyección internacional |
| **Beatriz Flores Silva** | Documentalista; pionera del cine de mujeres en Uruguay |
| **Gonzalo Arijón** | Documentalista; *Stranded: I've Come From a Plane That Crashed on the Andes* (sobre el accidente de los Andes) |
| **Álvaro Brechner** | *Mal Día para Pescar*, *Mr. Kaplan*, *La Noche de 12 Años* (2018 - sobre el encarcelamiento de los tupamaros; coproducción internacional) |
| **Germán Tejeira** | — |
| **Manolo Nieto** | *El Lugar del Hijo* |

### "La Noche de 12 Años" (2018)

**"La Noche de 12 Años"** de Álvaro Brechner es la película uruguaya de mayor repercusión internacional reciente. Narra el encarcelamiento en condiciones de aislamiento extremo durante 12 años de tres dirigentes del **Movimiento de Liberación Nacional-Tupamaros**, entre ellos **José Mujica** (futuro presidente de Uruguay). Fue seleccionada para los premios Oscar (preselección) y obtuvo reconocimiento en múltiples festivales.

## Cinemateca Uruguaya

La **Cinemateca Uruguaya** es la institución de preservación y difusión del patrimonio cinematográfico en Uruguay. Fundada en 1952, es una de las cinematecas más antiguas de América Latina. Gestiona el **Festival Cinematográfico Internacional del Uruguay** y conserva un acervo de miles de películas.

## Festivales de cine

| Festival | Descripción |
|----------|-------------|
| **Festival Cinematográfico Internacional del Uruguay** | El más importante del país; organizado por la Cinemateca |
| **Cinemateca Uruguay** | Programación regular de cine de arte y retrospectivas |
| **DocMontevideo** | Festival dedicado al documental |

## Cine y televisión

El **Canal 5 (TNU/SODRE)** produce y emite contenido audiovisual nacional. Con la proliferación de plataformas de streaming, la demanda de contenido uruguayo ha crecido, generando nuevas oportunidades para la producción local.

## Palabras clave

cine uruguayo, ICAU Uruguay, películas uruguayas, "Whisky" película Uruguay Cannes 2004, "25 Watts" cine Uruguay, "La Noche de 12 Años" Uruguay Álvaro Brechner, César Charlone Uruguay, Juan Pablo Rebella Uruguay, Pablo Stoll cine, Federico Veiroj Uruguay, Cinemateca Uruguaya, Festival Cinematográfico Internacional Uruguay, Ley 18284 ICAU, fondo fomento cine Uruguay, MEC audiovisual Uruguay, cine latinoamericano Uruguay
