# SODRE — Servicio Oficial de Difusión, Radiotelevisión y Espectáculos

## Descripción

El **SODRE** (Servicio Oficial de Difusión, Radiotelevisión y Espectáculos) es el organismo público de radiodifusión y espectáculos de Uruguay. Es uno de los pilares del sistema cultural público del país, gestionando la televisión pública, las radios públicas, la ópera, el ballet y la orquesta sinfónica nacionales. Está vinculado al **Ministerio de Educación y Cultura (MEC)**.

## Datos institucionales

| Dato | Información |
|------|-------------|
| Nombre completo | Servicio Oficial de Difusión, Radiotelevisión y Espectáculos |
| Sigla | SODRE |
| Tipo | Ente autónomo vinculado al MEC |
| Fundación | **1929** (como servicio de radiodifusión) |
| Sede | Montevideo (Auditorio Nacional del SODRE, Andes 1365) |
| Sitio web | www.sodre.gub.uy |

## Historia

### Fundación como radio pública (1929)

El SODRE fue creado el **14 de marzo de 1929** bajo la presidencia de Juan Campisteguy, como el primer servicio oficial de radiodifusión de Uruguay. La creación del SODRE refleja la política del Estado uruguayo de los años 20–30 de construir instituciones culturales públicas de carácter nacional.

La **Radio SODRE (CX6)** fue la primera radio pública del país y durante décadas fue la principal emisora de música clásica y cultura del Uruguay.

### Expansión a las artes escénicas (1930–1960)

En las décadas siguientes, el SODRE amplió su misión más allá de la radiodifusión:
- **1931:** creación del **Conjunto de Música de Cámara del SODRE**
- **1931:** creación del **Cuerpo de Baile del SODRE** (hoy Ballet Nacional del SODRE)
- **1931:** creación de la **Orquesta Sinfónica del SODRE** (OSSODRE)
- Producción de espectáculos de ópera y opereta

El SODRE se convirtió en el principal productor de espectáculos artísticos de alto nivel del Uruguay.

### La televisión pública: Canal 10/Canal 5

El SODRE inauguró la **televisión pública** de Uruguay. El **Canal 5** es el canal de televisión pública del Estado uruguayo, gestionado por el SODRE. Fue uno de los primeros canales de televisión de Uruguay al iniciarse la era televisiva en el país (1960s).

### El Auditorio Nacional del SODRE

El **Auditorio Nacional del SODRE** (inaugurado en su versión actual en 2009 tras la reconstrucción del edificio original destruido por un incendio en 1971) es el principal espacio de artes escénicas y música de Uruguay. Cuenta con:
- **Sala Zitarrosa:** sala principal con capacidad para ~1.900 personas
- **Sala Hugo Balzo:** sala de música de cámara
- **Sala Zavala Muniz:** sala de teatro y espectáculos menores
- **Sala Delmira Agustini:** sala experimental

### Dictadura e intervención (1973–1985)

Durante la dictadura, el SODRE fue intervenido y su programación fue sometida a censura. Muchos artistas vinculados al SODRE fueron destituidos o vetados.

## Componentes del SODRE

### Canal 5 — Televisión Nacional

El **Canal 5** es la señal de televisión pública del Uruguay, gestionada por el SODRE.

| Dato | Información |
|------|-------------|
| Nombre actual | Televisión Nacional Uruguay (TNU) / Canal 5 |
| Tipo | Televisión pública |
| Cobertura | Nacional (señal abierta y cable) |
| Programación | Noticias, cultura, deporte, entretenimiento, cine, series |
| Señal digital | TDT (Televisión Digital Terrestre) |

El Canal 5 es la alternativa pública a los canales privados (Canales 4, 10 y 12 de Montevideo).

### Radios del SODRE

El SODRE gestiona varias emisoras de radio pública:

| Emisora | Frecuencia | Perfil |
|---------|-----------|--------|
| **Radio Uruguay (CX6)** | AM 1050 | Noticias y contenidos generales |
| **Radio Clásica (CX26)** | FM 97.1 | Música clásica y cultural |
| **Radio Espectador (CX14)** | AM 810 | Noticias y entrevistas (asociada, no estrictamente SODRE) |
| Otras señales FM | Varias | Programación variada |

### Orquesta Filarmónica del SODRE (OSSODRE)

La **Orquesta Sinfónica del SODRE (OSSODRE)** es la principal orquesta sinfónica de Uruguay. Fundada en 1931, ofrece temporadas de conciertos en el Auditorio Nacional y en localidades del interior.

| Dato | Información |
|------|-------------|
| Fundación | 1931 |
| Sede | Auditorio Nacional del SODRE |
| Temporada | Programación anual con conciertos sinfónicos, de cámara y didácticos |
| Director titular | Varía; posición designada periódicamente |

### Ballet Nacional del SODRE (BNS)

El **Ballet Nacional del SODRE (BNS)** es la compañía de ballet clásico y contemporáneo del Estado uruguayo. Fundado en 1931, es la compañía de ballet más antigua y prestigiosa del país.

| Dato | Información |
|------|-------------|
| Fundación | 1931 |
| Repertorio | Ballet clásico (Swan Lake, Giselle) + contemporáneo |
| Director artístico | Varía por período |
| Actividades | Temporada en Montevideo; giras nacionales e internacionales |

### Cuerpo de Baile del SODRE

Además del Ballet Nacional, el SODRE tiene un **Cuerpo de Baile** para espectáculos de variedades y géneros populares.

### Ópera Nacional del SODRE

El SODRE produce temporadas de **ópera** en el Auditorio Nacional, con elencos nacionales e internacionales. Uruguay tiene una larga tradición operística vinculada al SODRE y al Teatro Solís.

### Archivo Nacional de la Imagen y la Palabra

El SODRE custodia el **Archivo Nacional de la Imagen y la Palabra**, repositorio de los materiales audiovisuales y sonoros producidos o conservados por el SODRE a lo largo de su historia.

## Palabras clave

SODRE Uruguay, Servicio Oficial Difusión Uruguay, Canal 5 Uruguay televisión pública, TNU Televisión Nacional Uruguay, Auditorio Nacional SODRE Montevideo, Orquesta Sinfónica SODRE OSSODRE, Ballet Nacional SODRE Uruguay, ópera SODRE Uruguay, Radio Uruguay CX6, Radio Clásica SODRE Uruguay, fundación SODRE 1929, historia radiodifusión pública Uruguay, Sala Zitarrosa Montevideo, Archivo Nacional Imagen Palabra Uruguay, MEC SODRE vinculación
