# Industrias Culturales y Creativas en Uruguay

## Descripción

Las **industrias culturales y creativas** comprenden el conjunto de actividades económicas que tienen como insumo principal la creatividad y generan productos o servicios con valor cultural. En Uruguay, este sector incluye el audiovisual, la música, la edición, el diseño, la publicidad, el software creativo, la gastronomía y las artes escénicas. El Estado apoya este sector a través del **MEC, el ICAU, la AGADU** y otros instrumentos.

## Definición y alcance

Las industrias creativas en Uruguay abarcan:

| Sector | Descripción |
|--------|-------------|
| **Audiovisual** | Cine, televisión, plataformas de streaming, publicidad audiovisual |
| **Música** | Producción discográfica, edición musical, espectáculos en vivo |
| **Editorial** | Edición de libros, revistas, periódicos, contenidos digitales |
| **Diseño** | Diseño gráfico, industrial, de moda, de interiores |
| **Publicidad** | Agencias de publicidad y comunicación |
| **Artes escénicas** | Teatro, danza, circo, espectáculos |
| **Software y videojuegos** | Desarrollo de videojuegos y contenidos digitales creativos |
| **Gastronomía** | Gastronomía creativa; restaurantes de autor |
| **Artesanía** | Artesanía tradicional y contemporánea |
| **Arquitectura** | Diseño arquitectónico como actividad creativa |

## Indicadores económicos

Las industrias creativas uruguayas representan aproximadamente el **2–3 % del PIB**, con crecimiento sostenido en los sectores digital y audiovisual.

| Sector | Aporte estimado al PIB |
|--------|----------------------|
| Publicidad y diseño | ~1 % |
| Audiovisual | ~0,5 % |
| Edición | ~0,3 % |
| Artes escénicas y música | ~0,3 % |
| Software creativo y videojuegos | En crecimiento |

*Cifras aproximadas; sector de medición compleja.*

## El sector audiovisual

### Cine y televisión

El **ICAU (Instituto del Cine y Audiovisual del Uruguay)** es el principal organismo de apoyo al sector audiovisual. El cine uruguayo ha crecido significativamente desde 2000 (ver `07-cine-uruguayo.md`).

La producción para **televisión** está creciendo con la demanda de contenidos de plataformas de streaming. Uruguay tiene productoras locales que trabajan para plataformas internacionales.

### Videojuegos

Uruguay tiene una escena emergente de **desarrollo de videojuegos**. Empresas como **Thanksyou!** y otras han desarrollado juegos con reconocimiento internacional. La **CUTI (Cámara Uruguaya de Tecnologías de la Información)** agrupa también a empresas del sector creativo digital.

## El sector musical

### Estructura económica de la música

La industria musical uruguaya está compuesta por:
- **Intérpretes y bandas:** artistas con o sin sello discográfico
- **Sellos discográficos:** principalmente independientes
- **Productores y estudios de grabación**
- **Promotores y organizadores de espectáculos**
- **Gestión colectiva:** AGADU (autores), SUGRA (intérpretes)

### AGADU

La **AGADU (Asociación General de Autores del Uruguay)** es la entidad de gestión colectiva de derechos de autor. Recauda y distribuye regalías por el uso de obras en radio, televisión, espacios públicos, espectáculos y plataformas digitales.

## El sector editorial

### Edición de libros

Uruguay tiene un sector editorial con editoriales independientes activas:
- **Ediciones de la Banda Oriental:** editorial histórica de referencia en Uruguay
- **HUM:** editorial de literatura y ensayo
- **Trilce:** — 
- **Criatura Editora:** literatura contemporánea
- **Fin de Siglo:** —

La **Cámara Uruguaya del Libro (CUL)** agrupa a editores y libreros.

La **Feria del Libro de Montevideo** es el evento anual del sector.

### Prensa y medios

Uruguay tiene un ecosistema de medios de comunicación con:
- **El País:** el diario de mayor circulación
- **La Diaria:** periódico cooperativo de referencia en el sector progresista
- **Brecha:** semanario de análisis político y cultural
- **Búsqueda:** semanario económico y político
- Múltiples portales digitales de noticias

## El sector del diseño

El **diseño** es uno de los sectores creativos con mayor desarrollo en Uruguay. Agencias de diseño gráfico y comunicación visual trabajan para mercados locales y regionales.

La **Asociación Uruguaya de Diseñadores Gráficos (AUDG)** y otras agrupaciones representan al sector.

## Publicidad

Uruguay tiene un sector publicitario activo con agencias locales y filiales de agencias internacionales. La publicidad genera una parte significativa de la demanda de producción audiovisual, diseño y fotografía.

## Instrumentos de política para las industrias creativas

| Instrumento | Organismo | Descripción |
|-------------|-----------|-------------|
| **FEFCA** | MEC/DNC | Fondo de apoyo a la creación artística |
| **ICAU** | MEC | Fondo de fomento del cine y el audiovisual |
| **Ley de Mecenazgo** | MEC | Incentivos fiscales para mecenazgo cultural privado |
| **AGADU** | Autores | Gestión colectiva de derechos de autor |
| **Uruguay XXI** | MIEM/MRREE | Promoción de exportaciones, incluidas las creativas |
| **ANDE** | — | Apoyo al emprendimiento, incluyendo creativo |

## Palabras clave

industrias culturales Uruguay, industrias creativas Uruguay, ICAU Uruguay audiovisual, AGADU Uruguay derechos autor, editorial Uruguay, Ediciones Banda Oriental Uruguay, videojuegos Uruguay, sector musical Uruguay, diseño Uruguay economía, publicidad Uruguay, Cámara Uruguaya Libro, El País Uruguay diario, La Diaria Uruguay, FEFCA industrias creativas, PIB cultural Uruguay, exportación creativa Uruguay, Uruguay XXI cultura
