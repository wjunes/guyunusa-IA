# Glosario de Cultura, Artes y Expresiones Culturales del Uruguay

## Uso

Este glosario define los términos técnicos, siglas e instituciones más frecuentes en el contexto de la cultura, las artes y las industrias culturales de Uruguay. Ordenado alfabéticamente.

---

**AGADU** — Asociación General de Autores del Uruguay. Sociedad de gestión colectiva de derechos de autor de compositores, autores y editores musicales.

**América Invertida** — Obra emblemática de Joaquín Torres García (1943). Mapa del continente americano dibujado con el sur hacia arriba, representando su filosofía de que el norte geográfico y cultural es el sur ("Nuestro norte es el sur").

**Auditorio Nacional del SODRE** — Complejo de salas musicales del SODRE en Montevideo, reconstruido en 2009 tras el incendio de 1971. Cuenta con la Sala Zitarrosa (~1.900 localidades), Sala Hugo Balzo, Sala Zavala Muniz y Sala Delmira Agustini.

**Ballet Nacional del SODRE (BNS)** — Compañía oficial de ballet del Uruguay, fundada en 1931. Dependiente del SODRE.

**Barradas, Rafael** (1890–1929) — Pintor uruguayo vanguardista. Vivió gran parte de su vida en España, donde fue amigo de García Lorca y Dalí. Creó el Vibrationismo, movimiento propio.

**Batllismo cultural** — Período de expansión de la institucionalidad cultural uruguaya durante las presidencias de José Batlle y Ordóñez (1903–1907 y 1911–1915). El SODRE (1929) y otras instituciones culturales públicas son parte de ese legado.

**Benedetti, Mario** (1920–2009) — Escritor y poeta uruguayo. Obras más importantes: *La tregua* (novela, 1960), *Poemas de la oficina*, *El cumpleaños de Juan Ángel*. Exiliado durante la dictadura. Una de las figuras literarias más conocidas del Uruguay en el exterior.

**Candombe** — Expresión musical y dancística de origen afro-uruguayo. Declarado Patrimonio Cultural Inmaterial de la Humanidad por la UNESCO en 2009. Sus instrumentos principales son el tambor chico, repique y piano. Es el fundamento rítmico del Carnaval de Montevideo.

**Carnaval de Montevideo** — El Carnaval más largo del mundo (~40 días). Organizado por DAECPU. Las categorías principales del concurso oficial son: murga, candombe-comparsa, parodistas, humoristas y revista.

**CdF** — Centro de Fotografía de Montevideo. Institución de la Intendencia de Montevideo dedicada a la fotografía y la imagen.

**Cinemateca Uruguaya** — Institución fundada en 1952 para la conservación y difusión del patrimonio cinematográfico en Uruguay. Una de las cinematecas más antiguas de América Latina.

**Cuplé** — Parte central de la actuación de una murga en el Carnaval. Sección de contenido crítico y político, generalmente humorístico, dirigida a la actualidad social y política.

**DAECPU** — Directores Asociados de Espectáculos Carnavaleros y Populares del Uruguay. Organiza el concurso oficial del Carnaval de Montevideo y gestiona el Teatro de Verano Ramón Collazo.

**DNC** — Dirección Nacional de Cultura del MEC. Organismo rector de la política cultural del Estado uruguayo.

**EAC** — Espacio de Arte Contemporáneo. Centro de arte contemporáneo de Uruguay, instalado en el antiguo edificio de la cárcel de Miguelete en Montevideo.

**Escobero** — Personaje de la comparsa de candombe en el Carnaval. Realiza acrobacias con una escoba. Es uno de los personajes rituales del candombe junto al gramillero, la mama vieja y la vedette.

**Fabini, Eduardo** (1882–1950) — Compositor uruguayo, considerado el fundador de la música académica nacional. Su obra más conocida es *Campo* (poema sinfónico, 1922).

**FEFCA** — Fondo de Estímulo a la Formación y Creación Artística. Principal fondo de apoyo a la creación cultural del MEC. Sus líneas de financiamiento son: creación artística, formación, difusión, espacios culturales y propuestas emergentes.

**Figari, Pedro** (1861–1938) — Pintor y abogado uruguayo. De estilo post-impresionista, sus obras más conocidas son series sobre el candombe, los ranchos y la vida cotidiana del Río de la Plata. Su obra tardía fue realizada principalmente en París.

**Galeano, Eduardo** (1940–2015) — Escritor y periodista uruguayo. Su obra más conocida es *Las venas abiertas de América Latina* (1971), referencia del pensamiento latinoamericano. Exiliado durante la dictadura. Otras obras: *Memoria del fuego*, *El libro de los abrazos*.

**Gramillero** — Personaje ritual de la comparsa de candombe. Representa al curandero o médico de la comunidad afro-uruguaya. Porta un bastón y hierbas medicinales.

**Ibarmourou, Juana de** (1892–1979) — Poeta uruguaya, conocida como "Juana de América". Premio Nacional de Literatura (1959). Su obra se caracteriza por temas del cuerpo, la naturaleza y el tiempo.

**Ibermedia** — Programa de coproducción cinematográfica iberoamericana del que Uruguay forma parte a través del ICAU.

**ICAU** — Instituto del Cine y Audiovisual del Uruguay. Creado por la Ley 18.284 (2008). Fomenta la producción y distribución del cine nacional. Gestiona el Fondo de Fomento.

**INAE** — Instituto Nacional de Artes Escénicas del MEC. Fomenta el teatro, la danza, el circo y las artes performáticas.

**INBA** — Instituto Nacional de Bellas Artes del MEC. Promueve las artes visuales y plásticas.

**La Cumparsita** — Tango compuesto por Gerardo Matos Rodríguez en Montevideo en 1917. Es el tango más conocido del mundo y símbolo musical de Uruguay y Argentina.

**La Vela Puerca** — Banda de rock uruguaya fundada en 1995 en Montevideo. Una de las más reconocidas del rock del Río de la Plata. Conocida por mezclar rock con candombe y murga.

**Ley Mecenazgo** — Mecanismo legal uruguayo que permite a empresas privadas financiar proyectos culturales a cambio de beneficios fiscales.

**Llamadas** — Desfile anual de comparsas de candombe en Montevideo, durante el Carnaval. Recorre los barrios Sur y Palermo (histórico asentamiento afro-uruguayo). Declarado Patrimonio Cultural de Montevideo.

**Mama Vieja** — Personaje de la comparsa de candombe. Representa a la mujer mayor de la comunidad afro-uruguaya.

**Matos Rodríguez, Gerardo** (1900–1948) — Compositor uruguayo, autor de La Cumparsita (1917).

**Murga** — Modalidad del Carnaval uruguayo. Conjunto de 14 a 17 personas (murguistas y percusionistas) que presentan un espectáculo de teatro musical con crítica social y política. Estructura: presentación, cuplés, retirada.

**No Te Va Gustar** — Banda de rock uruguaya fundada en 1994. Una de las más exitosas del rock latinoamericano en los 2000. Conocida por fusionar rock con candombe.

**Onetti, Juan Carlos** (1909–1994) — Escritor uruguayo. Creó el ciclo literario de "Santa María". Premio Cervantes de Literatura en 1980. Sus obras más importantes: *El astillero*, *Juntacadáveres*, *La vida breve*. Exiliado en España desde 1975.

**OSSODRE** — Orquesta Sinfónica del SODRE. Fundada en 1931. Principal orquesta sinfónica de Uruguay.

**OEI** — Organización de Estados Iberoamericanos. Organismo de cooperación educativa y cultural al que pertenece Uruguay. Gestiona programas como Ibercultura, Iberescena e Ibermedia.

**Payada** — Tradición oral gauchesca de improvisación poético-musical entre dos contendientes (payadores), que se desafían en versos sobre distintos temas.

**Rodó, José Enrique** (1871–1917) — Escritor y ensayista uruguayo. Su obra más conocida es *Ariel* (1900), ensayo emblemático del modernismo hispanoamericano. Influyó en generaciones de intelectuales latinoamericanos.

**SODRE** — Servicio Oficial de Difusión, Radiotelevisión y Espectáculos. Fundado el 14 de marzo de 1929. Ente público que gestiona Canal 5 (TNU), radios públicas (CX6 AM 1050, CX26 FM 97.1), OSSODRE, Ballet Nacional del SODRE y el Auditorio Nacional.

**Tablado** — Escenario popular del Carnaval montevideano, instalado en barrios de la ciudad. Los tablados barriales permiten que las comparsas y conjuntos actúen para el público local.

**Taller Torres García** — Movimiento artístico fundado por Joaquín Torres García en Montevideo en 1943 tras su regreso de Europa. Promovió el Universalismo Constructivo y formó una generación de artistas uruguayos.

**Tango** — Género musical y danzístico rioplatense compartido por Uruguay y Argentina. Inscrito en la lista de Patrimonio Cultural Inmaterial de la UNESCO en 2009 (inscripción conjunta AR+UY).

**Teatro de Verano Ramón Collazo** — Anfiteatro al aire libre en el Parque Rodó de Montevideo, sede principal del concurso oficial del Carnaval de Montevideo.

**Torres García, Joaquín** (1874–1949) — Pintor y teórico del arte uruguayo. Fundó el Universalismo Constructivo. Vivió gran parte de su vida en Europa y Estados Unidos. Retornó a Uruguay en 1934. Su obra más conocida: *América Invertida* (1943). El Museo Torres García en Montevideo (Sarandí 683) conserva su obra.

**Trías, Fernanda** (1976) — Escritora uruguaya contemporánea. Su novela *Mugre rosa* ganó el Premio Sor Juana Inés de la Cruz en 2021.

**TNU** — Televisión Nacional Uruguay. Canal 5 del SODRE, la televisión pública de Uruguay.

**Universalismo Constructivo** — Corriente artística creada por Joaquín Torres García que busca integrar el arte abstracto y constructivo con símbolos universales y americanos.

**Vibrationismo** — Movimiento artístico creado por el pintor uruguayo Rafael Barradas en España a principios del siglo XX, que busca capturar el dinamismo y la vibración de la vida urbana moderna.

**Zitarrosa, Alfredo** (1936–1989) — Cantor, compositor y poeta uruguayo. Uno de los grandes referentes de la música popular y el canto popular latinoamericano. Exiliado durante la dictadura. Sus obras más conocidas: *Adagio en mi país*, *Stefanie*, *Pa'l Norte*.

## Palabras clave

glosario cultura Uruguay, términos culturales Uruguay, siglas instituciones culturales Uruguay, SODRE definición, ICAU definición, FEFCA definición, DNC definición, candombe UNESCO Uruguay, tango UNESCO Uruguay, murga definición Uruguay, Torres García Universalismo Constructivo, Figari pintor Uruguay, Onetti escritor Uruguay, Benedetti escritor Uruguay, Galeano escritor Uruguay, La Cumparsita Uruguay, Carnaval Montevideo glosario, AGADU Uruguay, INAE Uruguay, candombe personajes gramillero mama vieja escobero
