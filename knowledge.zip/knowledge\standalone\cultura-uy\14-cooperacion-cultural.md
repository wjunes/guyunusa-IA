# Cooperación Internacional en Cultura — Uruguay

## Descripción

Uruguay mantiene una activa **cooperación cultural internacional** a través del **MEC/DNC**, el **SODRE**, el **ICAU** y la **red de embajadas y consulados**. La cooperación abarca intercambios artísticos, becas de formación, coproducción audiovisual y participación en organismos multilaterales de cultura.

## Organismos multilaterales

### UNESCO — Cultura

La **UNESCO** es el marco multilateral principal para la política cultural de Uruguay. Además de las convenciones de patrimonio (ver `patrimonio-uy`), la UNESCO gestiona la **Convención sobre la Diversidad de las Expresiones Culturales (2005)**, ratificada por Uruguay, que reconoce el derecho de los Estados a adoptar políticas culturales para proteger y promover la diversidad de expresiones.

### OEI — Organización de Estados Iberoamericanos

La **OEI** es el organismo de referencia para la cooperación cultural iberoamericana. Uruguay participa en programas como:
- **Ibercultura Viva:** apoyo a la cultura comunitaria
- **Iberescena:** apoyo a las artes escénicas iberoamericanas (coproducción, circulación, formación)
- **Ibermedia:** coproducción cinematográfica iberoamericana (Uruguay participa activamente)
- **IberOrquestas Juveniles:** programa de orquestas juveniles en el espacio iberoamericano

### Ibermedia

El programa **Ibermedia** (OEI) es uno de los más relevantes para el cine uruguayo. Financia la **coproducción** de películas entre países iberoamericanos, el **desarrollo de guiones** y la **distribución** de películas. El cine uruguayo ha accedido a fondos Ibermedia para varias coproducciones importantes.

### MERCOSUR Cultural

El **Sector Cultural del MERCOSUR** coordina políticas culturales entre los países del bloque. Actividades:
- **Rutas Culturales del MERCOSUR:** itinerarios de turismo cultural regional
- Cooperación en museos, archivos y bibliotecas
- Programas de coproducción y circulación artística

## Centros culturales extranjeros en Uruguay

| Centro | País | Descripción |
|--------|------|-------------|
| **Centro Cultural de España (CCE)** | España / AECID | Uno de los espacios culturales más activos de Montevideo; exposiciones, teatro, cine, música |
| **Alliance Française** | Francia | Cultura y lengua francesa; cursos, cine, música |
| **Instituto Goethe** | Alemania | Cultura y lengua alemana; programación cultural |
| **Instituto Cultural Italiano** | Italia | Cultura italiana; lengua; eventos |
| **Casa de la Cultura de México** | México | Programación cultural mexicana |
| **Embajada de Brasil** (eventos) | Brasil | Programación cultural brasileña |

El **Centro Cultural de España** (CCE) de Montevideo es uno de los centros culturales extranjeros más relevantes del país, con una programación de alta calidad en múltiples disciplinas artísticas.

## Cooperación bilateral

### España — AECID

La **Agencia Española de Cooperación Internacional para el Desarrollo (AECID)** financia proyectos culturales en Uruguay a través del CCE y de fondos específicos de cooperación cultural. España es el principal socio de cooperación cultural de Uruguay.

### Francia

La cooperación cultural con Francia se canaliza a través de la **Alliance Française** y la **Embajada de Francia**. El Instituto de Cine francés (Unifrance) colabora con el ICAU en distribución y circulación del cine uruguayo en Francia.

### Alemania

El **Instituto Goethe** promueve la cultura alemana y apoya proyectos de intercambio cultural Uruguay-Alemania.

### Brasil

La cooperación cultural con Brasil tiene dimensiones tanto institucionales (embajada, MINC) como de integración natural en los departamentos fronterizos.

### Argentina

La relación cultural con Argentina es la más intensa por razones geográficas, históricas y de identidad compartida. El tango, la murga, el cine y la literatura cruzan permanentemente la frontera. Los artistas uruguayos actúan regularmente en Argentina y viceversa.

## Circulación de artistas uruguayos en el exterior

| Artista / Expresión | Mercados principales |
|--------------------|---------------------|
| **Murga** | Argentina, España |
| **Candombe** | Argentina, España, Europa |
| **Cine** | Festivales internacionales (Cannes, San Sebastián, Rotterdam, Toronto) |
| **Teatro** | Argentina, España, festivales iberoamericanos |
| **Música popular** | Argentina, Chile, México, España |
| **Literatura** | España, Argentina, México (editoriales) |

## Becas de formación artística en el exterior

El **FEFCA** del MEC incluye una línea de **becas para formación artística en el exterior** que permite a artistas uruguayos perfeccionarse en instituciones de excelencia en España, Italia, Francia, Argentina y otros países.

## Palabras clave

cooperación cultural internacional Uruguay, OEI Uruguay cultura, Ibermedia cine Uruguay, Iberescena teatro Uruguay, MERCOSUR Cultural Uruguay, Centro Cultural España Montevideo, Alliance Française Uruguay, Goethe Uruguay, AECID cooperación cultural Uruguay, coproducción cine Uruguay, becas artísticas exterior Uruguay, Convención Diversidad Expresiones Culturales UNESCO Uruguay, circulación artistas uruguayos, cooperación cultural bilateral Uruguay, murga Uruguay internacional, cine uruguayo festivales internacionales
